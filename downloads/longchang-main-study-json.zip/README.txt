LongChang main-study JSON records

All 540 paper runs: 12 models x 15 scenes x 3 repeats, including failed
discoveries and the normal control. This package covers the main study;
controlled comparisons and evolved-scene experiments are separate studies.

session.json and evaluation.json are unmodified, byte-for-byte copies of the
frozen files used for the paper. Session files include the actual prompts,
scene programs, rules, rubrics, request settings, all recorded turns, final
reports, report attempts and apparatus reviews. Evaluation files include the
judge prompt, attempts, raw responses, normalization and final judgement.
These are the complete JSON records; binary physics replay files are separate.

manifest.json maps every run to its conditions, scores and original SHA-256
hashes. Machine-specific evaluation paths from the source index are replaced
by portable archive paths; the two original JSON files are not rewritten.
The source-index hash identifies the frozen CSV used to select the paper runs.

To verify file integrity, coverage and scores after extracting this archive:
    python3 verify.py
This uses only the Python standard library. It does not call any model API.
