# LongChang — Anonymous source bundle

Implementation accompanying 'Can LLMs Uncover Hidden Physical Laws through Free Exploration?'.

This archive contains the framework's Python sources, the base scenes and
dependency list. API credentials, machine-specific launchers and run logs
are not included. Sources are a snapshot of the current implementation;
paper results use the frozen evaluations documented on the project page.

## Getting started

Use Python 3.12 or later in a virtual environment:

```bash
python -m pip install -r requirements.txt
python longchang/run.py --help
python longchang/run.py list --benchmark scenes/base_15.json --ids-only
```

The list command does not call a model. For model-backed experiments,
provide your own BASE_URL, API_KEY, MODEL, JUDGE_MODEL and BUILD_REVIEW_MODEL
environment variables. See each command's --help for its options.

The MuJoCo environment, action interface, apparatus support, explorer,
evaluation and scene evolution code are in longchang/. Prompts are in
longchang/prompts/. The paper's 15 base worlds are in scenes/base_15.json.
