"""解析一个 NOTE/ACT 回复；空白归一化不改变动作，歧义和额外正文明确拒绝。"""

from dataclasses import dataclass
import json
import re

from engine import reply_json, unwrap_fence


_ACTIONS = {"PUSH", "THROW", "WAIT", "BUILD", "PLACE", "RELEASE", "GRASP", "MOVE", "ADJUST", "MARK", "DONE"}
_FIELDS = re.compile(r"NOTE:([^\r\n]*)\r?\n(?:[ \t]*\r?\n)*[ \t]*ACT:([\s\S]*)", re.I)


@dataclass
class ParsedReply:
    raw: str
    note: str = ""
    act: str = ""
    error: str | None = None


def extract_reply(text):
    reply = ParsedReply(text)
    match = _FIELDS.fullmatch(unwrap_fence(text)) if isinstance(text, str) else None
    if match is None:
        reply.error = "Return one NOTE line followed by one ACT field."
    else:
        reply.note, reply.act = (part.strip() for part in match.groups())
    return reply


def validate_reply(reply):
    """只接受一个动作；保留原文，BUILD 的纯 JSON 包装可无歧义地归一化。"""
    if reply.error or not reply.act:
        return
    action = reply.act
    try:
        operation = action.split(maxsplit=1)[0].upper()
        if operation not in _ACTIONS:
            raise ValueError("Unknown action. Use an advertised action or leave ACT empty.")
        if operation == "BUILD":
            design = reply_json(action[5:].strip())
            if not isinstance(design, dict):
                raise ValueError("BUILD requires a JSON object.")
            reply.act = "BUILD " + json.dumps(design, ensure_ascii=False, allow_nan=False)
        elif len(action.splitlines()) != 1 or re.search(r"\b(?:NOTE|ACT):", action, re.I):
            raise ValueError("Return exactly one action and no invented subsequent turns.")
        elif operation == "DONE" and len(action.split()) != 1:
            raise ValueError("DONE takes no arguments.")
    except ValueError as error:
        reply.act, reply.error = "", str(error)


def execute_reply(world, reply):
    if reply.error is not None:
        return reply.error, False
    if not reply.act:
        return "ok", False
    if reply.act.upper() == "DONE":
        return "ok", True
    try:
        world.act(reply.act)
    except ValueError as error:
        return str(error), False
    return "ok", False
