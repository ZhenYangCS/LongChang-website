"""单场实验：加载场景 -> 模型交互 -> 最终报告 -> 保存记录。"""

import argparse
import json
import sys
import time
import uuid
from functools import partial
from pathlib import Path

from engine import PermanentAPIError, ResponsesConversation, call_api, write_log, Settings
from eval import DEFAULT_PARAMETERS, trace_report
from scenes import load_scene
from tools import review_design
from protocol import extract_reply, validate_reply, execute_reply
from world import World, Recorder
from prompts import (AGENT_TELLS, COMPOSE_TASK_PROMPT, AGENT_BRIEF, AGENT_TURN_MESSAGE, ACTION_FORMAT,
                     ACTION_FAILURE_PROMPT, FINAL_OBSERVATION_PREFIX, REPORT_PROMPT, REPORT_REPAIR_PROMPT)


def run_episode(source, scene_id=None, *, tell="T0", budget=20, model=None, output=None,
                chat=None, record_fps=Recorder.DEFAULT_FPS, check_only=False, settings=None):
    """输入场景文件或定义，返回实验记录；output 是本场实验的存档目录。"""
    if type(budget) is not int or budget < 1:
        raise ValueError("budget 必须是正整数")
    settings = settings or Settings.from_env()
    model = model or settings.model
    threshold = settings.compact_threshold
    if threshold:
        threshold = ResponsesConversation.validate_threshold(threshold)
        if chat is None and model is not None and model != "gpt-6-astra":
            raise ValueError("COMPACT_THRESHOLD 目前仅支持 gpt-6-astra")
    scene = load_scene(source, scene_id)
    task = make_task(scene, tell)
    record_fps = Recorder.validate_fps(record_fps)
    world = World(scene, review=partial(review_design, settings=settings))
    if check_only:
        return
    directory = Path(output) if output is not None else None
    if directory is not None and directory.exists() and any(directory.iterdir()):
        raise FileExistsError("存档目录必须为空，请使用新目录")
    progress = {"done": 0, "total": budget + 1}
    label = f"{getattr(chat, 'model', model) or '?'} | {directory.name if directory else scene.scene_spec['id'] + '/' + tell}"
    log = partial(write_log, directory=directory, label=label, started=time.monotonic(), progress=progress)
    if chat is None:
        chat = (ResponsesConversation(model, threshold, log=log, settings=settings) if threshold else
                partial(call_api, model=model, log=log, settings=settings))
    record = {
        "episode_id": uuid.uuid4().hex, "scene": scene.scene_spec["id"],
        "tell": tell, "model": getattr(chat, "model", model), "budget": budget,
        "prompt": AGENT_BRIEF.format(task=task, ACTION_FORMAT=ACTION_FORMAT),
        "prompt_policy": "neutral_T0_v1" if tell == "T0" else "prompted_v1",
        "truth": scene.ground_truth(), "rubric": scene.rubric(),
        "scoring_parameters": dict(DEFAULT_PARAMETERS), "request_settings": settings.public(),
        "status": "running", "turns": [], "report": None,
    }
    if isinstance(chat, ResponsesConversation):
        record.update(api_policy=chat.policy, context_calls=chat.calls)
    recorder = Recorder(world, directory, record, fps=record_fps)
    messages = [{"role": "system", "content": record["prompt"]}]
    try:
        log(f"开始实验；存档={directory}")
        observation = run_interaction(chat, recorder, messages, log, progress)
        record["final_prompt"] = REPORT_PROMPT
        recorder.checkpoint()
        progress["total"] = len(record["turns"]) + 1
        log("生成最终报告")
        record["report"] = collect_report(chat, task, messages, observation, record,
                                           checkpoint=recorder.checkpoint, log=log, max_attempts=settings.report_attempts)
        record["status"] = "complete"
        progress["done"] += 1
        log("实验完成")
    except BaseException as error:
        record.update(status="interrupted" if isinstance(error, (KeyboardInterrupt, InterruptedError)) else "failed",
                      error=str(error), error_type=type(error).__name__)
        if isinstance(error, PermanentAPIError):
            record["api_failure"] = {"phase": "report" if "final_prompt" in record else "exploration",
                                     "raw_response": error.raw_response, **error.details}
        log(f"ERROR {type(error).__name__}: {error}")
        raise
    finally:
        try:
            recorder.capture("final")
            recorder.checkpoint()
        except Exception as error:
            log(f"ERROR 存档失败：{error}")
            if record["status"] == "complete":
                raise
    return {**record, **recorder.payload()}


def make_task(scene, tell):
    """T0 不依赖答案或元数据；T1/T2 才能获得任务提示及组合规律数。"""
    if tell not in AGENT_TELLS:
        raise ValueError("tell 必须是 T0、T1 或 T2")
    if tell == "T0":
        return AGENT_TELLS["T0"]
    metadata = scene.scene_spec.get("metadata") or {}
    if scene.scene_spec.get("provenance", {}).get("operation") == "compose":
        count = scene.scene_spec.get("oracle", {}).get("rule_count")
        if type(count) is not int or count < 0:
            raise ValueError("组合题需要有效的 oracle.rule_count")
        task = COMPOSE_TASK_PROMPT.format(rule_count=count)
    else:
        rules = "one hidden rule" if metadata.get("task_policy") == "single_rule" else "hidden rules"
        task = AGENT_TELLS["T1"].format(rules=rules)
    if tell == "T2":
        hint = (metadata.get("hints") or {}).get("T2")
        if not isinstance(hint, str) or not hint.strip():
            raise ValueError("T2 需要场景的 metadata.hints.T2 线索")
        task += "\n" + AGENT_TELLS["T2"].format(hint=hint.strip())
    return task


def run_interaction(chat, recorder, messages, log=write_log, progress=None):
    """观察 -> 请求动作 -> 执行 -> 记录，直到 DONE 或轮数用完。"""
    world, record = recorder.world, recorder.session
    budget = record["budget"]
    observation = world.observe()
    for turn in range(1, budget + 1):
        recorder.turn = turn
        started = time.monotonic()
        log(f"第{turn}/{budget}轮：等待模型")
        messages.append({"role": "user", "content": AGENT_TURN_MESSAGE.format(
            turn=turn, budget=budget, remaining=budget - turn + 1,
            observation_label=("Initial observation; no action has run." if turn == 1
                               else f"Result of turn {turn - 1}; cite turn {turn - 1} for this result."),
            observation_json=json.dumps(observation, ensure_ascii=False))})
        if isinstance(chat, ResponsesConversation):
            chat.turn = turn
        raw = chat(messages)
        messages.append({"role": "assistant", "content": raw})
        reply = extract_reply(raw)
        validate_reply(reply)
        row = {"turn": turn, "observation": observation, "raw": raw,
               "note": reply.note, "act": reply.act, "outcome": "pending"}
        record["turns"].append(row)
        recorder.capture("before")
        row["outcome"], done = execute_reply(world, reply)
        recorder.capture("after")
        observation = world.observe()
        row.update(result_observation=observation, time=float(world.data.time),
                   model_version=len(recorder.versions) - 1)
        if row["outcome"] != "ok":
            messages.append({"role": "user", "content": ACTION_FAILURE_PROMPT.format(outcome=row["outcome"])})
        if done or turn == budget:
            record["termination_reason"] = "model_done" if done else "budget_exhausted"
        recorder.checkpoint()
        if progress is not None:
            progress["done"] = turn
        action = reply.act.replace("\n", " ")[:160] or "(空动作)"
        log(f"第{turn}/{budget}轮：ACT={action}；耗时={time.monotonic() - started:.1f}s；"
            + ("ok" if row["outcome"] == "ok" else f"ERROR {row['outcome']}"))
        if done:
            break
    return observation


def collect_report(chat, task, messages, observation, record, *, checkpoint=None, log=write_log, max_attempts=3):
    """校验并修正报告格式和引用；保留每次原文，不向模型提供答案或评分。"""
    if type(max_attempts) is not int or max_attempts < 1:
        raise ValueError("report max_attempts must be a positive integer")
    turn = len(record["turns"])
    if isinstance(chat, ResponsesConversation):
        chat.turn, chat.phase = turn, "report"
    report_messages = [{"role": "system", "content": task + "\n\n" + REPORT_PROMPT},
                       *messages[1:],
                       {"role": "user", "content": FINAL_OBSERVATION_PREFIX.format(turn=turn)
                        + json.dumps(observation, ensure_ascii=False)}]
    attempts = record.setdefault("report_attempts", [])
    raw = record.get("report")  # 也允许依据原轨迹修正一份已保存的损坏报告。
    for number in range(1, max_attempts + 1):
        if raw is None:
            try:
                raw = chat(report_messages)
            except PermanentAPIError as error:
                if error.details.get('finish_reason') != 'length':
                    raise
                attempts.append({'attempt': len(attempts) + 1, 'raw': error.raw_response,
                                 'status': 'incomplete', 'error': str(error), 'api_failure': error.details})
                if checkpoint is not None:
                    checkpoint()
                if number == max_attempts:
                    raise
                log(f"报告第{number}次被截断，保留探索记录并请求精简报告")
                report_messages.append({'role': 'user', 'content': REPORT_REPAIR_PROMPT.format(
                    error='The previous response reached the output limit. Return concise JSON without repeating the transcript.')})
                continue
        if not isinstance(raw, str):
            raise TypeError("模型必须返回文本报告")
        record["report"] = raw
        attempt = {"attempt": len(attempts) + 1, "raw": raw}
        attempts.append(attempt)
        try:
            trace_report(raw, record["turns"])
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            attempt.update(status="invalid", error=str(error))
            if checkpoint is not None:
                checkpoint()
            if number == max_attempts:
                raise ValueError(f"报告连续{max_attempts}次格式或引用无效：{error}") from error
            log(f"报告第{attempt['attempt']}次格式或引用未通过，正在自动修正：{error}")
            # Responses 会话要求保留已消费的历史及上一条原始回复。
            report_messages.extend([
                {"role": "assistant", "content": raw},
                {"role": "user", "content": REPORT_REPAIR_PROMPT.format(error=str(error))},
            ])
            raw = None
            continue
        attempt["status"] = "valid"
        if checkpoint is not None:
            checkpoint()
        return raw


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--benchmark", type=Path, required=True, help="场景 JSON 文件")
    parser.add_argument("--scene", required=True, help="文件中的场景 ID")
    parser.add_argument("--tell", choices=tuple(AGENT_TELLS), default="T0")
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--model")
    parser.add_argument("--output", type=Path, help="本场实验的新存档目录")
    parser.add_argument("--record-fps", type=Recorder.validate_fps, default=Recorder.DEFAULT_FPS)
    parser.add_argument("--check-only", action="store_true", help="检查场景和配置，不调用模型或写文件")
    args = parser.parse_args(argv)
    if args.output is None and not args.check_only:
        parser.error("运行实验需要 --output")
    try:
        record = run_episode(args.benchmark, args.scene, tell=args.tell, budget=args.budget,
                             model=args.model, output=args.output, record_fps=args.record_fps,
                             check_only=args.check_only)
    except (KeyboardInterrupt, InterruptedError):
        return 130
    except Exception as error:
        parser.exit(1, f"{error}\n")
    print(f"Checked {args.scene}/{args.tell}" if args.check_only else f"Saved {args.output}; {len(record['turns'])} turns")
    return 0


if __name__ == "__main__":
    sys.exit(main())
