import base64
import copy
import gzip
import hashlib
import json
import math
import os
import platform
import tempfile
import time as _time
import xml.etree.ElementTree as ET
import zipfile
import zlib
from pathlib import Path
from contextlib import contextmanager

import mujoco
import numpy as np

from observation import MotionRecorder, MotionState

DT = 0.002
SEC = round(1 / DT)
COARSE = 0.1
STILL = 2e-2
STILL_ACC = 1.0
SNAP = 60  # 保留动作推进时长和器材读数采样节奏。
OBSERVATION_INTERVAL = 20
OBSERVATION_POINTS = 100  # 每个物体的默认返回上限；None 表示不设上限。
MAX_FRAMES = 20  # 仅用于旧动作协议的箭头轨迹。
SETTLE_MAX = 10 * SEC
SPEED_MAX = 10.0
BOUND = 6.0
TOP = 12.0
ACTION_PROTOCOL = "interactive_v1"
LEGACY_PROTOCOL = "legacy_settle"
OPS = ("PUSH", "THROW")
DIRS = {"east": 0.0, "north": 90.0, "west": 180.0, "south": 270.0}


def _num(tok):
    try:
        value = float(tok)
        if not math.isfinite(value):
            raise ValueError("nonfinite number")
        return value
    except ValueError:
        raise ValueError(f"expected a finite number, got {tok!r}")


COLORS = {"red": ".9 .1 .1 1", "blue": ".1 .1 .9 1", "green": ".1 .8 .2 1",
          "yellow": ".9 .9 .1 1", "brown": ".6 .4 .2 1", "gray": ".55 .55 .55 1"}
_RGB = {c: np.array([float(v) for v in spec.split()[:3]]) for c, spec in COLORS.items()}


def ball(name, pos, color, mass=1.0, size=0.1):
    return (f'<body name="{name}" pos="{pos[0]} {pos[1]} {pos[2]}"><freejoint/>'
            f'<geom type="sphere" size="{size}" rgba="{COLORS[color]}" mass="{mass}"/></body>')


def box(name, pos, color, mass=2.0, size=0.15):
    return (f'<body name="{name}" pos="{pos[0]} {pos[1]} {pos[2]}"><freejoint/>'
            f'<geom type="box" size="{size} {size} {size}" rgba="{COLORS[color]}" mass="{mass}"/></body>')


def patch(name, pos, half, color):
    return (f'<geom name="{name}" type="box" pos="{pos[0]} {pos[1]} 0.002" '
            f'size="{half} {half} 0.002" rgba="{COLORS[color]}" '
            f'contype="0" conaffinity="0"/>')


def orb(name, pos, color, size=0.25):
    return (f'<geom name="{name}" type="sphere" pos="{pos[0]} {pos[1]} {pos[2]}" '
            f'size="{size}" rgba="{COLORS[color]}"/>')


def dof(model, name):
    return model.body_dofadr[model.body(name).id]


BASE = """<mujoco>
<option timestep="0.002"/>
<visual><global offwidth="640" offheight="640"/></visual>
<default><geom condim="6" friction="1 0.02 0.012"/></default>
<worldbody>
<geom name="floor" type="plane" size="6 6 0.1"/>
<geom name="wall_n" type="box" pos="0 6.1 6" size="6.2 0.1 6" rgba="1 1 1 0"/>
<geom name="wall_s" type="box" pos="0 -6.1 6" size="6.2 0.1 6" rgba="1 1 1 0"/>
<geom name="wall_e" type="box" pos="6.1 0 6" size="0.1 6.2 6" rgba="1 1 1 0"/>
<geom name="wall_w" type="box" pos="-6.1 0 6" size="0.1 6.2 6" rgba="1 1 1 0"/>
<geom name="ceiling" type="box" pos="0 0 12.1" size="6.2 6.2 0.1" rgba="1 1 1 0"/>
{tools}
{scene}
</worldbody>
</mujoco>"""


def impulse(toks, bodies, model, *, legacy=False):
    op = toks[0].upper() if toks else ""
    expected = 4 if op == "PUSH" else 5 if op == "THROW" else 0
    if not expected or len(toks) < expected or (not legacy and len(toks) != expected):
        raise ValueError("PUSH obj heading force / THROW obj heading elevation force")
    obj = toks[1]
    if obj not in bodies:
        raise ValueError(f"no object named {obj}")
    ht = toks[2].lower()
    head = math.radians(DIRS[ht] if ht in DIRS else _num(toks[2]))
    if op == "PUSH":
        elev, force = 0.0, _num(toks[3])
    else:
        elev, force = math.radians(min(max(_num(toks[3]), 0.0), 90.0)), _num(toks[4])
    if not legacy and (force < 0 or (op == "THROW" and not 0 <= _num(toks[3]) <= 90)):
        raise ValueError("force must be nonnegative and elevation within 0-90")
    force = max(0.0, min(force, SPEED_MAX))
    v = force / float(model.body_mass[model.body(obj).id])
    ce, se = math.cos(elev), math.sin(elev)
    return bodies[obj][1], [math.cos(head) * ce * v, math.sin(head) * ce * v, se * v]


def _overlap(model, data, a, b):
    """补足凸体距离在完全重合时返回零的退化情况。"""
    pa, pb = data.geom_xpos[a], data.geom_xpos[b]
    sa, sb = model.geom_size[a], model.geom_size[b]
    ka, kb = model.geom_type[a], model.geom_type[b]
    if ka == kb == mujoco.mjtGeom.mjGEOM_BOX:
        ra, rb = data.geom_xmat[a].reshape(3, 3), data.geom_xmat[b].reshape(3, 3)
        axes = [*ra.T, *rb.T, *(np.cross(x, y) for x in ra.T for y in rb.T)]
        for axis in axes:
            norm = np.linalg.norm(axis)
            if norm < 1e-9:
                continue
            axis = axis / norm
            overlap = np.abs(ra.T @ axis) @ sa + np.abs(rb.T @ axis) @ sb - abs((pa - pb) @ axis)
            if overlap <= 0.003:
                return False
        return True
    if mujoco.mj_geomDistance(model, data, a, b, 0.01, None) < -0.003:
        return True
    if ka == mujoco.mjtGeom.mjGEOM_PLANE or kb == mujoco.mjtGeom.mjGEOM_PLANE:
        return False
    radius = lambda size, kind: min(size) if kind in (int(mujoco.mjtGeom.mjGEOM_BOX), int(mujoco.mjtGeom.mjGEOM_ELLIPSOID)) else (
        min(size[:2]) if kind == mujoco.mjtGeom.mjGEOM_CYLINDER else size[0])
    return np.linalg.norm(pa - pb) < radius(sa, ka) + radius(sb, kb) - 0.003


def contact_pairs(model, data, body_ids):
    """Return distinct contacting pairs among the selected bodies."""
    pairs = set()
    for contact in data.contact:
        a, b = (int(model.geom_bodyid[g]) for g in (contact.geom1, contact.geom2))
        if a != b and a in body_ids and b in body_ids:
            pairs.add(tuple(sorted((a, b))))
    return pairs


def material_contacts(model, data, body_ids):
    """返回器材与房间地面的接触及竖直雅可比；不将器材加入特殊对象名单。"""
    floor = model.geom("floor").id
    seen = set()
    for contact in data.contact:
        if floor not in (contact.geom1, contact.geom2):
            continue
        other = contact.geom2 if contact.geom1 == floor else contact.geom1
        bid = int(model.geom_bodyid[other])
        if bid not in body_ids or bid in seen:
            continue
        seen.add(bid)
        jac = np.zeros((3, model.nv))
        mujoco.mj_jac(model, data, jac, None, contact.pos, bid)
        vertical = jac[2]
        if np.linalg.norm(jac) > 1e-10:
            yield bid, contact.pos, float(vertical @ data.qvel), vertical


def new_floor_contacts(model, data, body_ids, previous):
    """Select contact-entry events rather than repeated samples of a sustained contact."""
    contacts = list(material_contacts(model, data, body_ids))
    touching = {body for body, _, _, _ in contacts}
    return [contact for contact in contacts if contact[0] not in previous], touching


def material_bounce(model, data, vertical, speed):
    """把接触法向速度变化通过惯性矩阵分配到自由/铰链/滑轨关节。"""
    response = np.zeros((1, model.nv))
    mujoco.mj_solveM(model, data, response, vertical.reshape(1, -1))
    effective = float(vertical @ response[0])
    if effective > 1e-12:
        data.qvel[:] += response[0] * ((speed - vertical @ data.qvel) / effective)


class World:
    def __init__(self, scene, tools=(), *, _legacy=False, action_protocol=ACTION_PROTOCOL,
                 observation_interval=OBSERVATION_INTERVAL, observation_points=OBSERVATION_POINTS, review=None):
        from tools import Workshop
        self.scene = scene
        if action_protocol not in (ACTION_PROTOCOL, LEGACY_PROTOCOL):
            raise ValueError("unknown action protocol")
        self.action_protocol = action_protocol
        self.markers = {}
        # tools 仅供旧日志重演注入历史仪器；新世界默认只有场景自身几何体。
        self.tools = tuple(tools)
        # 仅无精确状态的旧日志重演会关闭工坊；新实验始终可自行搭建。
        self.workshop = None if _legacy else Workshop(review=review)
        self.material_names = set()
        xml = BASE.format(tools="\n".join(t.xml() for t in self.tools), scene=scene.xml())
        root = ET.fromstring(xml)
        for tag in ("body", "geom", "joint", "freejoint", "site"):
            for i, element in enumerate(root.find("worldbody").iter(tag)):
                if "name" not in element.attrib:
                    element.set("name", f"lc_{tag}_{i}")
        self.spec = mujoco.MjSpec.from_string(ET.tostring(root, encoding="unicode"))
        self.model = self.spec.compile()
        self.data = mujoco.MjData(self.model)
        self._register()
        self.experiment_objects = set(self.bodies)
        mujoco.mj_forward(self.model, self.data)
        getattr(self.scene, "initial_hook", self.scene.hook)(self.model, self.data)
        mujoco.mj_forward(self.model, self.data)
        self.data.xfrc_applied[:] = 0
        self._tick = 0
        self._frames = []
        self.viewer = None
        self.wait_progress = None
        self.recorder = None
        self.revision = 0
        self._motion = None if action_protocol == LEGACY_PROTOCOL else MotionRecorder(
            interval=observation_interval, max_points=observation_points,
            steps_per_count=SEC, still_threshold=STILL)
        if self._motion is not None:
            self._motion.reset(self._motion_snapshot())

    def _register(self):
        self.material_ids = {self.model.body(n).id for n in self.material_names}
        self.bodies = {}
        for b in range(1, self.model.nbody):
            j = self.model.body_jntadr[b]
            if j >= 0 and self.model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE:
                name = self.model.body(b).name
                self.bodies[name] = (int(self.model.jnt_qposadr[j]), int(self.model.jnt_dofadr[j]))

    def model_xml(self):
        root = ET.fromstring(self.spec.to_xml())
        option = root.find("option")
        if option is None:
            option = ET.SubElement(root, "option")
        option.set("gravity", " ".join(map(str, self.model.opt.gravity)))
        for element in root.find("worldbody").iter("geom"):
            name = element.get("name")
            if name:
                g = self.model.geom(name).id
                for key in ("rgba", "friction", "solref", "solimp"):
                    element.set(key, " ".join(map(str, getattr(self.model, "geom_" + key)[g])))
        for element in root.iter("body"):
            b = self.model.body(element.get("name")).id
            if self.model.body_mass[b] > 0:
                inertial = element.find("inertial")
                if inertial is None:
                    inertial = ET.SubElement(element, "inertial")
                inertial.attrib.clear()
                inertial.set("mass", str(self.model.body_mass[b]))
                for key, field in (("pos", "body_ipos"), ("quat", "body_iquat"), ("diaginertia", "body_inertia")):
                    inertial.set(key, " ".join(map(str, getattr(self.model, field)[b])))
        old = root.find("keyframe")
        if old is not None:
            root.remove(old)
        return ET.tostring(root, encoding="unicode")

    def install(self, tool):
        from tools import _extent
        root = ET.fromstring(self.model_xml())
        body = root.find("worldbody")
        child = ET.fromstring(tool.xml)
        for element in child.find("worldbody"):
            body.append(copy.deepcopy(element))
        if child.find("tendon") is not None:
            tendons = root.find("tendon")
            if tendons is None:
                tendons = ET.SubElement(root, "tendon")
            tendons.extend(copy.deepcopy(list(child.find("tendon"))))
        candidate = mujoco.MjSpec.from_string(ET.tostring(root, encoding="unicode"))
        model = candidate.compile()
        data = mujoco.MjData(model)
        self._transfer(model, data)
        mujoco.mj_forward(model, data)
        new_ids = {model.body(name).id for name in tool.body_names}
        for bid in new_ids:
            pos = data.xpos[bid]
            if np.any(pos < [-BOUND, -BOUND, 0]) or np.any(pos > [BOUND, BOUND, TOP]):
                raise ValueError("tool joint or body origin extends beyond the room")
        for g in range(model.ngeom):
            if model.geom_bodyid[g] not in new_ids:
                continue
            extent = _extent(model, data, g)
            lo, hi = data.geom_xpos[g] - extent, data.geom_xpos[g] + extent
            if np.any(lo < [-BOUND, -BOUND, -1e-6]) or np.any(hi > [BOUND, BOUND, TOP]):
                raise ValueError("tool geometry extends beyond the room")
        # 同一新器材的刚性组合可由搭接的 geoms 表示；跨器材或可相对运动的部件仍检查。
        for a in range(model.ngeom):
            for b in range(a):
                ba, bb = int(model.geom_bodyid[a]), int(model.geom_bodyid[b])
                if not ({ba, bb} & new_ids):
                    continue
                if ba in new_ids and bb in new_ids and model.body_weldid[ba] == model.body_weldid[bb]:
                    continue
                if any(not (model.geom_contype[g] or model.geom_conaffinity[g]) for g in (a, b)):
                    continue
                if _overlap(model, data, a, b):
                    raise ValueError(f"initial overlap: {model.geom(a).name} / {model.geom(b).name}")
        for name in tool.ports.values():
            pos = data.site_xpos[model.site(name).id]
            if np.any(pos < [-BOUND, -BOUND, 0]) or np.any(pos > [BOUND, BOUND, TOP]):
                raise ValueError("port extends beyond the room")
        for i in range(model.ntendon):
            if data.ten_length[i] > model.tendon_range[i, 1] + 0.003:
                raise ValueError("cord is shorter than its initial span")
        self._commit_spec(candidate, tool.body_names)

    def _commit_spec(self, candidate, material_names=()):
        model, data = candidate.recompile(copy.copy(self.model), copy.copy(self.data))
        self._transfer(model, data)
        mujoco.mj_forward(model, data)
        self.spec, self.model, self.data = candidate, model, data
        self.material_names.update(material_names)
        self._register()
        for attr in ("_addr", "_ids", "_floor"):
            if hasattr(self.scene, attr):
                setattr(self.scene, attr, None)
        self.revision += 1

    def mark(self, name, x, y):
        from tools import ident, number
        name = ident(name)
        x, y = (round(number(v, -BOUND + 0.05, BOUND - 0.05) / COARSE) * COARSE for v in (x, y))
        if max(abs(x), abs(y)) > BOUND - 0.05:
            raise ValueError("marker too close to the wall")
        existing = {m["object"] for m in getattr(self.scene, "landmarks", lambda: [])()}
        existing.update(t.name for t in self.tools)
        if len(self.markers) >= 16 or name in existing or name in self.markers or name in self.bodies or name in self.workshop.instruments:
            raise ValueError("marker ID already exists or marker allowance exhausted")
        if self.workshop.hand is not None:
            raise ValueError("release the hand before marking")
        root = ET.fromstring(self.model_xml())
        ET.SubElement(root.find("worldbody"), "site", name=f"mark_{name}", type="cylinder",
                      pos=f"{x} {y} 0.006", size="0.05 0.002", rgba="0.9 0.8 0.1 1")
        self._commit_spec(mujoco.MjSpec.from_string(ET.tostring(root, encoding="unicode")))
        mark = {"object": name, "colour": "yellow", "state": "floor marker",
                "position": f"({x:.1f}, {y:.1f}, 0.0)"}
        self.markers[name] = mark
        self.workshop.pending[name] = {"marked": [round(x, 1), round(y, 1)]}
        if self.recorder:
            self.recorder.marked(mark)

    def _transfer(self, model, data):
        old = self.model
        # recompile 不保证新增自由关节的默认位姿；先初始化再按名称迁移旧关节。
        data.qpos[:] = model.qpos0
        data.qvel[:] = 0
        data.qacc_warmstart[:] = 0
        for b in range(1, old.nbody):
            name = old.body(b).name
            if model.body(name).id != b:
                raise ValueError("adding tools must preserve existing body IDs")
        for j in range(old.njnt):
            name = old.joint(j).name
            other = model.joint(name).id
            q, d = int(old.jnt_qposadr[j]), int(old.jnt_dofadr[j])
            nq = 7 if old.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE else 4 if old.jnt_type[j] == mujoco.mjtJoint.mjJNT_BALL else 1
            nv = 6 if nq == 7 else 3 if nq == 4 else 1
            q2, d2 = int(model.jnt_qposadr[other]), int(model.jnt_dofadr[other])
            if (q, d) != (q2, d2):
                raise ValueError("adding tools must preserve existing joint addresses")
            data.qpos[q2:q2 + nq] = self.data.qpos[q:q + nq]
            data.qvel[d2:d2 + nv] = self.data.qvel[d:d + nv]
            data.qacc_warmstart[d2:d2 + nv] = self.data.qacc_warmstart[d:d + nv]
        data.time = self.data.time
        data.ctrl[:old.nu] = self.data.ctrl
        data.act[:old.na] = self.data.act
        data.mocap_pos[:old.nmocap] = self.data.mocap_pos
        data.mocap_quat[:old.nmocap] = self.data.mocap_quat
        data.eq_active[:old.neq] = self.data.eq_active
        data.xfrc_applied[:old.nbody] = self.data.xfrc_applied
        data.qfrc_applied[:old.nv] = self.data.qfrc_applied
        data.userdata[:old.nuserdata] = self.data.userdata

    def _pos(self, name):
        q = self.bodies[name][0]
        return tuple(round(round(float(v) / COARSE) * COARSE, 2) for v in self.data.qpos[q:q + 3])

    def _motion_snapshot(self):
        """读取观测采样所需状态；不推进物理，也不暴露速度或接触编号。"""
        roots = {self.model.body(name).id: name for name in self.bodies}
        contacts = {name: set() for name in self.bodies}
        for contact in self.data.contact:
            a, b = int(contact.geom1), int(contact.geom2)
            pair = (min(a, b), max(a, b))
            for geom in (a, b):
                root = int(self.model.body_rootid[self.model.geom_bodyid[geom]])
                if root in roots:
                    contacts[roots[root]].add(pair)
        return {
            name: MotionState(self._pos(name), tuple(float(v) for v in self.data.qvel[d:d + 3]),
                              self._vel(name) >= STILL, frozenset(contacts[name]),
                              tuple(float(v) for v in self.data.qpos[q:q + 3]))
            for name, (q, d) in self.bodies.items()
        }

    def _vel(self, name):
        d = self.bodies[name][1]
        return float(np.linalg.norm(self.data.qvel[d:d + 6]))

    def _acc(self, name):
        d = self.bodies[name][1]
        return float(np.linalg.norm(self.data.qacc[d:d + 6]))

    def _still(self):
        return all(self._vel(n) < STILL and self._acc(n) < STILL_ACC for n in self.bodies)

    def _clip(self):
        for q, d in self.bodies.values():
            for i, lo, hi in ((0, -BOUND, BOUND), (1, -BOUND, BOUND), (2, 0.0, TOP)):
                v = self.data.qpos[q + i]
                if not lo <= v <= hi:
                    self.data.qpos[q + i] = min(max(v, lo), hi)
                    self.data.qvel[d + i] = 0.0

    def step(self, hold=None):
        """advance the world one physics tick: clear forces, re-apply any external hold
        (a mouse drag), let the scene inject its anomaly, integrate, then keep everything
        inside the box. Every path that moves time forward goes through here."""
        self.data.xfrc_applied[:] = 0
        self.data.qfrc_applied[:] = 0
        if hold is not None:
            self.data.xfrc_applied[:] += hold
        self.scene.hook(self.model, self.data)
        if self.workshop is not None:
            material_hook = getattr(self.scene, "material_hook", None)
            if material_hook is not None and self.material_ids:
                material_hook(self.model, self.data, self.material_ids)
            self.workshop.apply(self)
        mujoco.mj_step(self.model, self.data)
        self._clip()
        post_step = getattr(self.scene, "post_step", None)
        if post_step is not None:
            post_step(self.model, self.data)
        mujoco.mj_forward(self.model, self.data)
        self._tick += 1
        if self._motion is not None:
            self._motion.step(self._motion_snapshot())
        elif self._tick % SNAP == 0:
            self._frames.append({n: self._pos(n) for n in self.bodies})
            if len(self._frames) > 1024:
                self._frames = self._frames[::2]
        if self.recorder is not None:
            self.recorder.sample()
        if self.workshop is not None and self._tick % SNAP == 0:
            self.workshop.sample(self)
        if self.viewer is not None:
            self.viewer.sync()

    def _run(self, nsteps):
        for _ in range(nsteps):
            self.step()

    def _settle(self):
        for _ in range(0, SETTLE_MAX, SNAP):
            self._run(SNAP)
            if self._still():
                return

    def act(self, cmd):
        toks = cmd.split()
        if not toks:
            raise ValueError("empty command")
        op = toks[0].upper()
        if self._motion is not None:
            self._motion.reset(self._motion_snapshot())
        if op == "BUILD" and self.workshop is not None:
            self.workshop.act(cmd, self)
            return
        if op == "MARK" and self.workshop is not None and self.action_protocol == ACTION_PROTOCOL:
            if len(toks) != 4:
                raise ValueError("MARK <id> <x> <y>")
            self.mark(toks[1], _num(toks[2]), _num(toks[3]))
            return
        self._frames = [{n: self._pos(n) for n in self.bodies}]
        self._tick = 0
        if self.workshop is not None and self.workshop.act(cmd, self):
            return
        if op in OPS:
            if self.workshop is not None and len(toks) > 1 and toks[1] in self.workshop.holds:
                raise ValueError("RELEASE the held object before PUSH or THROW")
            try:
                d, vel = impulse(toks, self.bodies, self.model, legacy=self.action_protocol == LEGACY_PROTOCOL)
            except (IndexError, KeyError):
                raise ValueError(f"{op} format: PUSH obj heading force / THROW obj heading elevation force; cannot parse {cmd!r}")
            if self.action_protocol == LEGACY_PROTOCOL:
                self.data.qvel[d:d + 6] = vel + [0, 0, 0]
            else:
                self.data.qvel[d:d + 3] += vel
            on_launch = getattr(self.scene, "on_launch", None)
            if on_launch is not None and any(vel):
                on_launch(self.model, self.data, toks[1])
            if self.action_protocol == LEGACY_PROTOCOL:
                self._settle()
            else:
                self._run(SNAP)
        elif op == "WAIT":
            if len(toks) < 2 or not toks[1].isdigit():
                raise ValueError("WAIT needs a whole number of counts, e.g. WAIT 3")
            if self.action_protocol != LEGACY_PROTOCOL and (len(toks) != 2 or not 1 <= int(toks[1]) <= 30):
                raise ValueError("WAIT needs 1-30 whole counts")
            counts = min(int(toks[1]), 30)
            start = float(self.data.time)
            self.wait_progress = {"start": start, "end": start + counts * SEC * self.model.opt.timestep,
                                  "counts": counts}
            try:
                self._run(counts * SEC)
            finally:
                self.wait_progress = None
        else:
            for t in self.tools:
                steps = t.act(cmd, self.model, self.data)
                if steps is not None:
                    if steps > 0:
                        self._run(min(steps, SETTLE_MAX))
                    return
            raise ValueError(f"unknown action: {cmd}")

    def _colour(self, name):
        g = self.model.body_geomadr[self.model.body(name).id]
        rgba = np.asarray(self.model.geom_rgba[g][:3], dtype=float)
        return min(COLORS, key=lambda c: float(np.linalg.norm(_RGB[c] - rgba)))

    def observe(self):
        listing = []
        for n in self.bodies:
            x, y, z = self._pos(n)
            state = "moving" if self._vel(n) >= STILL else "still"
            listing.append({"object": n, "colour": self._colour(n),
                            "position": f"({x}, {y}, {z})", "state": state})
            if self.workshop is not None:
                listing[-1]["role"] = "experiment_object" if n in self.experiment_objects else (
                    "standard_weight" if any(n in t.weight_names for t in self.workshop.instruments.values())
                    else "apparatus_material")
        motion_state = self._motion_snapshot() if self._motion is not None else None
        events = self._motion.events(motion_state) if self._motion is not None else {}
        if self._motion is None:
            # 旧动作协议保留原来的箭头轨迹，历史存档无需改写。
            for n in self.bodies:
                track = [f[n] for f in self._frames if n in f]
                while len(track) > 1 and track[-1] == track[-2]:
                    track.pop()
                if len(set(track)) > 1:
                    if len(track) > MAX_FRAMES:
                        idx = np.linspace(0, len(track) - 1, MAX_FRAMES).round().astype(int)
                        track = [track[i] for i in idx]
                    tail = "still" if self._vel(n) < STILL else "moving"
                    events[n] = "->".join(f"({x},{y},{z})" for x, y, z in track) + "->" + tail
        for t in self.tools:
            r = t.readout(self.model, self.data)
            if r:
                events[t.name] = r
        obs = {"objects": listing, "events": events}
        if self.workshop is not None:
            events.update(self.workshop.readout())
            obs["workshop"] = self.workshop.inventory()
            obs["hand"] = {"holding": self.workshop.hand}
            obs["instruments"] = [
                {"id": t.id, "name": t.design["name"], "purpose": t.design["purpose"],
                 "ports": list(t.ports), "adjustable_joints": t.joint_options(self.model),
                 "state": t.readout(self.model, self.data),
                 "trace": self.workshop.traces.get(t.id, [])}
                for t in self.workshop.instruments.values()]
            self.workshop.traces = {}
        fixtures = list(getattr(self.scene, "landmarks", lambda: [])()) + list(self.markers.values())
        for t in self.tools:
            mark = getattr(t, "landmark", None)
            if mark:
                fixtures.append(mark())
        if fixtures:
            obs["fixtures"] = fixtures
        self._frames = [{n: self._pos(n) for n in self.bodies}]
        if self._motion is not None:
            self._motion.reset(motion_state)
        return obs


STATE_SPEC = mujoco.mjtState.mjSTATE_INTEGRATION
KEY_FIELDS = {"qpos": "qpos", "qvel": "qvel", "act": "act", "ctrl": "ctrl",
              "mpos": "mocap_pos", "mquat": "mocap_quat"}
MODEL_FIELDS = ("geom_rgba", "geom_friction", "geom_solref", "geom_solimp",
                "body_mass", "body_inertia", "body_ipos", "body_iquat")


REPLAY_TEXT = "longchang_replay"
REPLAY_FILES = ("replay.bin", "replay.xml", "replay.xml.gz", "replay.jsonl")
COMPRESSION_LEVEL = 6
BINARY_CHUNK_SIZE = 2048
BINARY_FIELDS = ("state", *KEY_FIELDS)


def replay_xml_stream(path):
    """普通 XML 读取；旧 gzip 只保留导入兼容，不再生成这种输出。"""
    path = Path(path)
    return gzip.open(path, "rb") if path.name.lower().endswith(".xml.gz") else path.open("rb")


def _xml_value(value):
    """带类型的 XML 值；数值数组紧凑保存，文本转义不丢失原始回复。"""
    node = ET.Element("value")
    if value is None:
        node.set("type", "null")
    elif isinstance(value, bool):
        node.set("type", "bool")
        node.text = "true" if value else "false"
    elif isinstance(value, (int, float)):
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("回放不能保存非有限数值")
        node.set("type", "int" if isinstance(value, int) else "float")
        node.text = repr(value)
    elif isinstance(value, str):
        node.set("type", "str")
        safe = all(c in "\t\n\r" or 0x20 <= ord(c) <= 0xD7FF or 0xE000 <= ord(c) <= 0xFFFD
                   or 0x10000 <= ord(c) <= 0x10FFFF for c in value)
        if not safe:
            node.set("encoding", "base64")
            value = base64.b64encode(value.encode("utf-8", errors="surrogatepass")).decode("ascii")
        node.set("data", value)
    elif isinstance(value, dict):
        node.set("type", "dict")
        for key, item in value.items():
            entry = ET.SubElement(node, "entry")
            entry.append(_xml_value(key))
            entry.append(_xml_value(item))
    elif isinstance(value, list):
        if value and all(type(v) is float for v in value):
            if not all(math.isfinite(v) for v in value):
                raise ValueError("回放状态含非有限数值")
            node.set("type", "floats")
            node.text = " ".join(map(repr, value))
        elif value and all(type(v) is int for v in value):
            node.set("type", "ints")
            node.text = " ".join(map(str, value))
        else:
            node.set("type", "list")
            node.extend(_xml_value(v) for v in value)
    else:
        raise ValueError(f"不支持的回放数据类型：{type(value).__name__}")
    return node


def _read_xml_value(node):
    kind = node.get("type")
    text = node.text or ""
    if kind == "null":
        return None
    if kind == "bool" and text in ("true", "false"):
        return text == "true"
    if kind == "int":
        return int(text)
    if kind == "float":
        result = float(text)
        if not math.isfinite(result):
            raise ValueError("回放含非有限数值")
        return result
    if kind == "str":
        result = node.get("data", "")
        encoding = node.get("encoding")
        if encoding == "base64":
            return base64.b64decode(result, validate=True).decode("utf-8", errors="surrogatepass")
        if encoding is not None:
            raise ValueError("不支持的回放文本编码")
        return result
    if kind in ("floats", "ints"):
        result = [float(v) if kind == "floats" else int(v) for v in text.split()]
        if kind == "floats" and not all(math.isfinite(v) for v in result):
            raise ValueError("回放状态含非有限数值")
        return result
    if kind == "list":
        return [_read_xml_value(child) for child in node]
    if kind == "dict":
        result = {}
        for entry in node:
            if entry.tag != "entry" or len(entry) != 2:
                raise ValueError("回放 XML 字典结构损坏")
            key, item = map(_read_xml_value, entry)
            if not isinstance(key, str) or key in result:
                raise ValueError("回放 XML 字段重名或不是字符串")
            result[key] = item
        return result
    raise ValueError(f"不支持的回放 XML 类型：{kind}")


def _replay_versions(record):
    if not isinstance(record, dict) or not record.get("model_versions") or not record.get("state_frames"):
        raise ValueError("记录缺少模型或精确状态，不能生成原始历史 replay.xml")
    versions = {v["version"]: v for v in record["model_versions"]}
    if len(versions) != len(record["model_versions"]):
        raise ValueError("回放模型编号重复")
    previous = -math.inf
    for frame in record["state_frames"]:
        version = versions.get(frame["version"])
        if version is None:
            raise ValueError("回放帧引用了不存在的模型")
        if not math.isfinite(frame["time"]) or frame["time"] < previous:
            raise ValueError("回放时间无效或倒退")
        if len(frame["qpos"]) != version["nq"] or len(frame["qvel"]) != version["nv"]:
            raise ValueError("回放帧与模型维度不匹配")
        previous = frame["time"]
    return versions


def replay_xml(record):
    """单个合法 MJCF：外层供预览，custom/text 内嵌完整 XML 历史供回放。"""
    versions = _replay_versions(record)
    last = record["state_frames"][-1]["version"]
    root = ET.fromstring(versions[last]["xml"])
    if root.tag != "mujoco":
        raise ValueError("回放模型不是 MJCF")
    for old in list(root.findall("keyframe")):
        root.remove(old)
    keys = ET.SubElement(root, "keyframe")
    for frame in record["state_frames"]:
        if frame["version"] != last:
            continue
        attrs = {"name": frame["key"], "time": repr(frame["time"])}
        attrs.update({k: " ".join(format(v, ".17g") for v in frame[k]) for k in KEY_FIELDS if frame[k]})
        ET.SubElement(keys, "key", **attrs)
    custom = root.find("custom")
    if custom is None:
        custom = ET.SubElement(root, "custom")
    for item in list(custom.findall("text")):
        if item.get("name") == REPLAY_TEXT:
            custom.remove(item)
    history = ET.Element("longchang_replay", format_version="1")
    history.append(_xml_value(record))
    ET.SubElement(custom, "text", name=REPLAY_TEXT, data=ET.tostring(history, encoding="unicode"))
    ET.indent(root)
    return ET.tostring(root, encoding="unicode", xml_declaration=True)


@contextmanager
def _atomic_output(path, *, overwrite):
    """Publish a complete file atomically; never expose a partially written artifact."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp",
                                         delete=False) as stream:
            temporary = Path(stream.name)
            yield stream
            stream.flush()
            os.fsync(stream.fileno())
        if overwrite:
            temporary.replace(path)
        else:
            os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def write_json_atomic(path, value, *, overwrite=True):
    content = json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2).encode("utf-8", errors="backslashreplace")
    with _atomic_output(path, overwrite=overwrite) as stream:
        stream.write(content)


def _json_digest(value):
    content = json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False, separators=(",", ":"))
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def write_replay_xml(path, record, *, overwrite=False):
    path = Path(path)
    if path.suffix.lower() != ".xml":
        raise ValueError("回放输出仅支持 .xml 或 .bin；旧 .gz 只支持读取转换")
    if not overwrite and path.exists():
        raise FileExistsError(path)
    content = replay_xml(record)
    with _atomic_output(path, overwrite=overwrite) as fh:
        # 分块编码避免额外生成一整份 bytes；失败不替换已有文件。
        for start in range(0, len(content), 1024 * 1024):
            fh.write(content[start:start + 1024 * 1024].encode("utf-8"))


def load_replay_xml(path):
    try:
        with replay_xml_stream(path) as fh:
            root = ET.parse(fh).getroot()
    except (gzip.BadGzipFile, EOFError) as err:
        raise ValueError(f"压缩回放损坏或不完整：{path}") from err
    element = root.find(f"custom/text[@name='{REPLAY_TEXT}']")
    if root.tag != "mujoco" or element is None:
        raise ValueError("这只是场景 XML，不含 LongChang 实验历史")
    history = ET.fromstring(element.get("data", ""))
    if history.tag != "longchang_replay" or history.get("format_version") != "1" or len(history) != 1:
        raise ValueError("不支持或已损坏的 LongChang 回放 XML")
    record = _read_xml_value(history[0])
    _replay_versions(record)
    return record


def _binary_layout(frame):
    return tuple((key, len(frame[key])) for key in BINARY_FIELDS
                 if isinstance(frame.get(key), list) and all(type(v) is float for v in frame[key]))


def _zip_member(archive, name, data):
    # 固定 ZIP 头时间，压缩结果不因写入路径或墙钟时间变化。
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=COMPRESSION_LEVEL)


def write_replay_binary(path, record, *, overwrite=False):
    """单文件 ZIP 容器：完整元数据＋去重的 float64 状态块，无 pickle、量化或降帧。"""
    path = Path(path)
    if path.suffix.lower() != ".bin":
        raise ValueError("二进制回放输出必须使用 .bin 后缀")
    if not overwrite and path.exists():
        raise FileExistsError(path)
    _replay_versions(record)
    metadata = {key: value for key, value in record.items() if key != "state_frames"}
    frames, blocks, start = record["state_frames"], [], 0
    with _atomic_output(path, overwrite=overwrite) as output, zipfile.ZipFile(output, "w") as archive:
        while start < len(frames):
            layout = _binary_layout(frames[start])
            end = start + 1
            while end < min(start + BINARY_CHUNK_SIZE, len(frames)):
                if frames[end]["version"] != frames[start]["version"] or _binary_layout(frames[end]) != layout:
                    break
                end += 1
            group = frames[start:end]
            keys = [key for key, _ in layout]
            sizes = [size for _, size in layout]
            values = np.asarray([[v for key in keys for v in frame[key]] for frame in group], dtype="<f8")
            if not np.all(np.isfinite(values)):
                raise ValueError("回放状态含非有限数值")
            bits = values.view("<u8")
            columns, indices, known = [], [], {}
            for i in range(bits.shape[1]):
                data = bits[:, i].tobytes()
                if data not in known:
                    known[data] = len(columns)
                    columns.append(bits[:, i])
                indices.append(known[data])
            packed = np.asarray(columns, dtype="<u8").reshape(len(columns), len(group))
            delta = packed.copy()
            delta[:, 1:] ^= packed[:, :-1]
            raw = delta.view(np.uint8).reshape(len(columns), len(group), 8).transpose(0, 2, 1).tobytes()
            member = f"states/{len(blocks):06d}.bin"
            _zip_member(archive, member, raw)
            blocks.append({"path": member, "count": len(group), "keys": keys, "sizes": sizes,
                           "columns": len(columns), "indices": indices,
                           "frames": [{k: v for k, v in frame.items() if k not in keys} for frame in group]})
            start = end
        envelope = {"format": "longchang-replay", "version": 1, "encoding": "f64le-xor-shuffle",
                    "record": metadata, "blocks": blocks}
        _zip_member(archive, "record.json", json.dumps(envelope, ensure_ascii=True, separators=(",", ":"), allow_nan=False))


def load_replay_binary(path):
    """还原全部原始字段和数值；只读取容器成员，不向磁盘解包。"""
    try:
        with zipfile.ZipFile(path) as archive:
            members = {info.filename: info for info in archive.infolist()}
            if len(members) != len(archive.infolist()):
                raise ValueError("二进制回放成员重复")
            envelope = json.loads(archive.read("record.json"))
            if (envelope.get("format") != "longchang-replay" or envelope.get("version") != 1
                    or envelope.get("encoding") != "f64le-xor-shuffle"):
                raise ValueError("不支持的二进制回放格式")
            record, blocks = envelope["record"], envelope["blocks"]
            if not isinstance(record, dict) or "state_frames" in record or not isinstance(blocks, list) or not blocks:
                raise ValueError("二进制回放缺少模型或状态块")
            if set(members) != {"record.json", *(f"states/{i:06d}.bin" for i in range(len(blocks)))}:
                raise ValueError("二进制回放成员与索引不匹配")
            frames = []
            for i, block in enumerate(blocks):
                count, columns = block["count"], block["columns"]
                keys, sizes, indices = block["keys"], block["sizes"], block["indices"]
                if (type(count) is not int or not 1 <= count <= BINARY_CHUNK_SIZE
                        or type(columns) is not int or columns < 0 or not isinstance(keys, list)
                        or not all(isinstance(k, str) and k in BINARY_FIELDS for k in keys)
                        or len(keys) != len(set(keys)) or not isinstance(sizes, list) or len(keys) != len(sizes)
                        or any(type(n) is not int or n < 0 for n in sizes)
                        or columns > sum(sizes) or not isinstance(indices, list) or len(indices) != sum(sizes)
                        or any(type(n) is not int or not 0 <= n < columns for n in indices)
                        or not isinstance(block["frames"], list) or len(block["frames"]) != count):
                    raise ValueError("二进制状态块维度或引用非法")
                name = f"states/{i:06d}.bin"
                if block["path"] != name or members[name].file_size != count * columns * 8:
                    raise ValueError("二进制状态块长度与索引不匹配")
                raw = archive.read(name)
                shuffled = np.frombuffer(raw, dtype=np.uint8).reshape(columns, 8, count)
                delta = shuffled.transpose(0, 2, 1).copy().view("<u8").reshape(columns, count)
                packed = np.bitwise_xor.accumulate(delta, axis=1, dtype=np.uint64).astype("<u8", copy=False)
                values = packed[indices].T.copy().view("<f8")
                if not np.all(np.isfinite(values)):
                    raise ValueError("二进制状态含非有限数值")
                for row, metadata in enumerate(block["frames"]):
                    if not isinstance(metadata, dict) or set(keys).intersection(metadata):
                        raise ValueError("二进制状态字段重复")
                    frame, cursor = dict(metadata), 0
                    for key, size in zip(keys, sizes):
                        frame[key] = values[row, cursor:cursor + size].tolist()
                        cursor += size
                    frames.append(frame)
            record["state_frames"] = frames
        _replay_versions(record)
        return record
    except (zipfile.BadZipFile, zlib.error, EOFError, KeyError, TypeError, AttributeError, IndexError) as err:
        raise ValueError(f"二进制回放损坏或不完整：{path}") from err


def write_replay(path, record, *, overwrite=False):
    writer = write_replay_binary if Path(path).suffix.lower() == ".bin" else write_replay_xml
    writer(path, record, overwrite=overwrite)


def load_replay(path):
    return load_replay_binary(path) if Path(path).suffix.lower() == ".bin" else load_replay_xml(path)


class Recorder:
    """研究者侧采样独立于模型可见的运动采样；不调用 observe 或场景 hook。"""

    DEFAULT_FPS = 30.0
    interval = 1 / DEFAULT_FPS
    CONFIG_FIELDS = ("episode_id", "scene", "tell", "repeat", "model", "budget", "tools_mode", "visual", "time_policy",
                     "random_policy", "action_protocol", "response_protocol", "report_format", "record_fps",
                     "resource_budget", "prompt_policy", "scoring_policy", "scoring_parameters", "implementation_id",
                     "model_settings", "task_hint", "actor_type", "participant_id", "request_settings", "api_policy",
                     "evaluation_requested", "seed")

    @staticmethod
    def validate_fps(value):
        try:
            fps = float(value)
        except (TypeError, ValueError):
            raise ValueError("record-fps 必须是 1-500 的有限数值") from None
        if isinstance(value, bool) or not math.isfinite(fps) or not 1 <= fps <= 1 / DT:
            raise ValueError("record-fps 必须是 1-500 的有限数值")
        return fps

    def __init__(self, world, directory=None, session=None, *, fps=DEFAULT_FPS):
        self.fps = self.validate_fps(fps)
        self.interval = 1 / self.fps
        self.world = world
        self.directory = Path(directory) if directory is not None else None
        if self.directory is not None:
            self.directory.mkdir(parents=True, exist_ok=True)
            if any((self.directory / p).exists() for p in ("config.json", "session.json", "eval.json", *REPLAY_FILES, "views", "tools", ".episode.claim")):
                raise FileExistsError("episode archive already exists; choose a new run directory")
            with (self.directory / ".episode.claim").open("x"):
                pass
        self.session = session if session is not None else {}
        if hasattr(world.scene, "scene_spec"):
            self.session.setdefault("scene_spec", copy.deepcopy(world.scene.scene_spec))
            self.session.setdefault("scene_source_hash", getattr(world.scene, "scene_source_hash", None)
                                    or _json_digest(world.scene.scene_spec))
            self.session.setdefault("scene", world.scene.scene_spec["id"])
        self.session.setdefault("runtime", {"python": platform.python_version(), "mujoco": mujoco.__version__,
                                            "numpy": np.__version__, "world_profile": "sealed_room_v1",
                                            "platform": platform.system(), "machine": platform.machine()})
        self.session.setdefault("action_protocol", world.action_protocol)
        self.session.setdefault("initial_model_xml", world.model_xml())
        self.turn = 0
        self.frames, self.versions, self.events, self.marker_events = [], [], [], []
        self._signature = None
        self._origin = float(world.data.time)
        self._sample_index = 1
        world.recorder = self
        self.capture("initial")
        self.checkpoint()

    def sample(self):
        w = self.world
        appearance = (w.revision, *(getattr(w.model, f).tobytes() for f in MODEL_FIELDS))
        previous = (self._signature[0], *self._signature[2:]) if self._signature else None
        elapsed = float(w.data.time) - self._origin
        due = elapsed >= self._sample_index * self.interval - 1e-9
        if appearance != previous or due:
            self.capture("sample")
        if due:
            # 使用固定仿真时间格点，额外的动作边界帧不推迟下一次采样。
            self._sample_index = max(self._sample_index + 1, math.floor((elapsed + 1e-9) / self.interval) + 1)

    def capture(self, phase):
        w, m, d = self.world, self.world.model, self.world.data
        signature = (w.revision, m.opt.gravity.tobytes(), *(getattr(m, f).tobytes() for f in MODEL_FIELDS))
        if signature != self._signature:
            version = len(self.versions)
            self.versions.append({"version": version, "label": f"turn_{self.turn}_{phase}",
                                  "time": float(d.time), "xml": w.model_xml(), "nq": m.nq, "nv": m.nv})
            self._signature = signature
        version = len(self.versions) - 1
        state = np.empty(mujoco.mj_stateSize(m, STATE_SPEC))
        mujoco.mj_getState(m, d, state, STATE_SPEC)
        frame = {"version": version, "time": float(d.time), "turn": self.turn, "phase": phase,
                 "key": f"frame_{len(self.frames):06d}_{phase}", "state": state.tolist(),
                 **{key: getattr(d, attr).ravel().tolist() for key, attr in KEY_FIELDS.items()}}
        self.frames.append(frame)
        return frame

    def created(self, tool, event):
        self.capture("build")
        event["version"] = len(self.versions) - 1
        event["xml"] = tool.xml
        self.events.append(copy.deepcopy(event))
        self.checkpoint()

    def marked(self, mark):
        self.capture("mark")
        self.marker_events.append({"type": "mark", **mark, "turn": self.turn,
                                   "time": float(self.world.data.time), "version": len(self.versions) - 1})
        self.checkpoint()

    def payload(self):
        return {"schema_version": 4, "state_spec": int(STATE_SPEC), "frame_interval": self.interval,
                "record_fps": self.fps,
                "resource_budget": None,
                "resource_usage": self.world.workshop.usage() if self.world.workshop else None,
                "model_versions": self.versions, "state_frames": self.frames, "tool_events": self.events,
                "marker_events": self.marker_events}

    def _write_config(self):
        """配置只取本次实验快照，不依赖场景题库或场景模块的辅助接口。"""
        from engine import decode_json
        record = {**self.session, "record_fps": self.fps,
                  "resource_budget": None}
        spec = copy.deepcopy(record.get("scene_spec"))
        config = {"schema_version": 1, **{k: copy.deepcopy(record[k]) for k in self.CONFIG_FIELDS if k in record},
                  "scene_spec": spec, "scene_hash": _json_digest(spec) if spec is not None else None,
                  "scene_source_hash": record.get("scene_source_hash"), "runtime": copy.deepcopy(record["runtime"]),
                  "scene_reproducibility": "definition_archived" if spec is not None else "legacy_definition_missing",
                  "initial_model_xml": record["initial_model_xml"],
                  "initial_model_hash": hashlib.sha256(record["initial_model_xml"].encode("utf-8")).hexdigest()}
        config["config_hash"] = _json_digest(config)
        path = self.directory / "config.json"
        existing = decode_json(path.read_text(encoding="utf-8")) if path.exists() else {}
        if not isinstance(existing, dict):
            raise ValueError(f"Invalid config.json: {path}")
        if existing.get("scene_spec") is not None and existing["scene_spec"] != spec:
            raise ValueError(f"config.json scene conflicts with the archived experiment: {path}")
        merged = {**existing, **config}
        if existing != merged:
            write_json_atomic(path, merged)

    def checkpoint(self):
        if self.directory is None:
            return
        self._write_config()
        write_replay_binary(self.directory / REPLAY_FILES[0], {**self.session, **self.payload()}, overwrite=True)
        manifest = {**self.session, "schema_version": 4,
                    "tools": [{k: v for k, v in event.items() if k != "xml"} for event in self.events], "markers": self.marker_events,
                    "resource_budget": None,
                    "resource_usage": self.world.workshop.usage() if self.world.workshop else None,
                    "model_versions": [{k: v for k, v in item.items() if k != "xml"} for item in self.versions],
                    "state_frames": len(self.frames), "frame_interval": self.interval, "record_fps": self.fps}
        write_json_atomic(self.directory / "session.json", manifest)


def recorded_states(record):
    """只还原记录帧；没有精确状态的旧日志不能据此生成历史 XML。"""
    if record.get("schema_version", 0) < 2 or not record.get("state_frames"):
        raise ValueError("legacy log has no exact recorded states")
    versions = {v["version"]: v for v in record["model_versions"]}
    model = data = current = None
    state_spec = mujoco.mjtState(record["state_spec"])
    for frame in record["state_frames"]:
        if frame["version"] != current:
            info = versions[frame["version"]]
            model = mujoco.MjModel.from_xml_string(info["xml"])
            data = mujoco.MjData(model)
            current = frame["version"]
        state = np.asarray(frame["state"], dtype=float)
        if state.shape != (mujoco.mj_stateSize(model, state_spec),) or not np.all(np.isfinite(state)):
            raise ValueError("recorded state is incompatible with its model version")
        mujoco.mj_setState(model, data, state, state_spec)
        mujoco.mj_forward(model, data)
        yield model, data, frame


class CompactStatusBar:
    """用现有 Pillow 绘制可换行的解说卡；只在可视化路径加载字体。"""

    def __init__(self):
        from PIL import ImageFont
        self.font_path = None
        self._fonts = {}
        candidates = [os.environ.get("LONGCHANG_FONT", ""),
                      "/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Light.ttc",
                      "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
                      "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
                      "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", "C:/Windows/Fonts/msyh.ttc"]
        for path in candidates:
            if not path:
                continue
            try:
                ImageFont.truetype(path, 18)
            except OSError:
                continue
            self.font_path = path
            break

    @staticmethod
    def layout(viewport):
        if viewport is None:
            return None
        scale = min(1.8, max(1.0, viewport.width / 1100))
        pad = round(8 * scale)
        width = min(round(800 * scale), viewport.width - pad * 2)
        height = min(round(224 * scale), viewport.height // 3)
        if width < 160 or height < 44:
            return None
        return mujoco.MjrRect(viewport.left + (viewport.width - width) // 2,
                              viewport.bottom + pad, width, height)

    @staticmethod
    def fit(text, font, width):
        text = " ".join(str(text).split())
        if font.getlength(text) <= width:
            return text
        lo, hi = 0, len(text)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if font.getlength(text[:mid] + "…") <= width:
                lo = mid
            else:
                hi = mid - 1
        return text[:lo] + "…"

    @classmethod
    def wrap(cls, text, font, width, max_lines):
        text = " ".join(str(text).split())
        lines = []
        for index in range(max_lines):
            fitted = cls.fit(text, font, width)
            if fitted == text or index == max_lines - 1:
                lines.append(fitted)
                break
            end = max(1, len(fitted) - 1)
            # 英文尽量在词间换行，中文按字换行。
            space = text.rfind(" ", 0, end + 1)
            if space > end // 2:
                end = space
            lines.append(text[:end].rstrip())
            text = text[end:].lstrip()
        return lines

    def render(self, lines, width, height):
        if self.font_path is None:
            return None
        from PIL import Image, ImageDraw, ImageFont
        scale = min(1.8, max(1.0, width / 800))
        if height < 120:
            scale = 0.78
        sizes = (max(12, round(15 * scale)), max(14, round(18 * scale)))
        fonts = []
        for size in sizes:
            if size not in self._fonts:
                self._fonts[size] = ImageFont.truetype(self.font_path, size)
            fonts.append(self._fonts[size])
        image = Image.new("RGB", (width, height), (21, 28, 36))
        draw = ImageDraw.Draw(image)
        draw.rectangle((0, 0, 3, height - 1), fill=(77, 190, 155))
        pad, gap = max(6, round(12 * scale)), max(2, round(5 * scale))
        line_height = round(24 * scale)
        draw.text((pad, pad), self.fit(lines[0], fonts[0], width - pad * 2),
                  font=fonts[0], fill=(167, 185, 199), anchor="lt")
        y = pad + sizes[0] + gap * 2
        draw.line((pad, y - gap, width - pad, y - gap), fill=(47, 60, 72))
        blocks = list(lines[1:])
        slots = max(1, (height - y - pad - gap * max(0, len(blocks) - 1)) // line_height)
        if slots < len(blocks):
            # 小窗口优先保留动作与反馈；不靠无限缩小字号塞下说明。
            labels = [text.split("：", 1)[0] for text in blocks]
            priority = sorted(range(len(blocks)), key=lambda i: (not labels[i].endswith("动作"),
                                                               not labels[i].endswith("反馈"), i))
            blocks = [blocks[i] for i in sorted(priority[:slots])]
        wrapped = [self.wrap(text, fonts[1], width - pad * 2, slots) for text in blocks]
        counts = [1] * len(blocks)
        for _ in range(slots - len(blocks)):
            candidates = [i for i in range(len(blocks)) if counts[i] < len(wrapped[i])]
            if not candidates:
                break
            index = min(candidates, key=lambda i: counts[i])
            counts[index] += 1
        for text, count in zip(blocks, counts):
            colour = ((244, 170, 153) if "失败：" in text and "反馈" in text.split("：", 1)[0] else
                      (181, 192, 209) if "AI 自述" in text.split("：", 1)[0] else
                      (143, 221, 187) if "反馈" in text.split("：", 1)[0] else (238, 244, 248))
            for line in self.wrap(text, fonts[1], width - pad * 2, count):
                draw.text((pad, y), line, font=fonts[1], fill=colour, anchor="lt")
                y += line_height
            y += gap
        # 内容短时收起空白，减少对场景的遮挡。
        return np.asarray(image)[:min(height, y - gap + pad)].copy()


def playback_speed(value):
    try:
        speed = float(value)
    except (TypeError, ValueError):
        raise ValueError("speed 必须是大于0的有限数值") from None
    if isinstance(value, bool) or not math.isfinite(speed) or speed <= 0:
        raise ValueError("speed 必须是大于0的有限数值")
    return speed


class LiveView:
    REOPEN_TIMEOUT = 5.0
    REOPEN_POLL = 0.01

    def __init__(self, world, title="LongChang", realtime=True, *, speed=1.0):
        self.speed = playback_speed(speed)
        self.world, self.title, self.realtime = world, title, realtime
        self.handle = None
        self._model = None
        self._data = None
        self._closed = False
        self._last_draw = 0.0
        self._details = "等待下一步操作"
        self._phase = "idle"
        self._hud = CompactStatusBar()
        self._last_hud = None
        self._font_warning = False
        self._status_started = _time.monotonic()
        self._last_status = -math.inf
        self._start_sim = float(world.data.time)
        self._start_wall = _time.monotonic()
        self._open()

    def _open(self):
        import mujoco.viewer
        if self._closed:
            raise InterruptedError("viewer closed")
        if self.handle is not None:
            self._reload_model()
            return
        deadline = _time.monotonic() + self.REOPEN_TIMEOUT
        while True:
            if self._closed:
                raise InterruptedError("viewer closed")
            try:
                handle = mujoco.viewer.launch_passive(self.world.model, self.world.data)
                break
            except RuntimeError as err:
                # close/is_running 只反映退出请求，不代表 mjpython 的 UI 槽位已释放。
                # 仅用于前一局关闭后新建窗口；一局内的模型变更不再重开窗口。
                if str(err) != "another MuJoCo viewer is already open":
                    raise
                remaining = deadline - _time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("MuJoCo 窗口入口仍被占用，等待释放超时；实验状态未重置") from err
                _time.sleep(min(self.REOPEN_POLL, remaining))
        self.handle = handle
        try:
            with handle.lock():
                cam = handle.cam
                cam.lookat[:] = [0, 0, 1.5]
                cam.distance, cam.elevation = 20, -20
            self.status(self.title)
        except BaseException:
            handle.close()
            self.handle = None
            raise
        self._model, self._data = self.world.model, self.world.data
        self._reset_clock()

    def _reset_clock(self):
        self._last_draw = -math.inf
        self._last_status = -math.inf
        self._last_hud = None
        # 加载开销不应造成下一段动画快速追赶墙钟。
        self._start_sim = float(self.world.data.time)
        self._start_wall = _time.monotonic()

    def _reload_model(self):
        if not self.is_running():
            raise InterruptedError("viewer closed")
        # MuJoCo 3.12 的 Handle 暂无公共 reload；集中适配其原生加载接口。
        # 原生 load 在渲染线程替换模型并等待完成，不销毁 GLFW 窗口。
        reference = getattr(self.handle, "_sim", None)
        native = reference() if callable(reference) else None
        if native is None or not callable(getattr(native, "load", None)):
            raise RuntimeError("当前 MuJoCo viewer 不支持原窗口模型更新，请使用 requirements.txt 锁定的版本")
        with self.handle.lock():
            cam, pert = self.handle.cam, self.handle.perturb
            camera = {name: getattr(cam, name) for name in
                      ("type", "fixedcamid", "trackbodyid", "orthographic", "distance", "azimuth", "elevation")}
            lookat, localpos = cam.lookat.copy(), pert.localpos.copy()
            selected = self._model.body(pert.select).name if 0 < pert.select < self._model.nbody else None
            tracked = self._model.body(cam.trackbodyid).name if 0 < cam.trackbodyid < self._model.nbody else None
            # 原生 load 也会清空 active；不继承跨模型的旧拖拽参考点。
            pert.active = 0
        # 不能持有 handle.lock 调用 load，否则渲染线程无法取得锁完成请求。
        native.load(self.world.model, self.world.data, "")
        if not self.is_running():
            raise InterruptedError("viewer closed during model update")
        with self.handle.lock():
            cam, pert = self.handle.cam, self.handle.perturb
            for name, value in camera.items():
                setattr(cam, name, value)
            cam.lookat[:] = lookat
            if cam.type == mujoco.mjtCamera.mjCAMERA_TRACKING:
                try:
                    cam.trackbodyid = self.world.model.body(tracked).id if tracked else -1
                except KeyError:
                    cam.trackbodyid = -1
                if cam.trackbodyid < 0:
                    cam.type = mujoco.mjtCamera.mjCAMERA_FREE
            if cam.type == mujoco.mjtCamera.mjCAMERA_FIXED and not 0 <= cam.fixedcamid < self.world.model.ncam:
                cam.type = mujoco.mjtCamera.mjCAMERA_FREE
            pert.active = 0
            if selected:
                try:
                    pert.select = self.world.model.body(selected).id
                    pert.localpos[:] = localpos
                except KeyError:
                    pert.select = 0
        self._model, self._data = self.world.model, self.world.data
        self._reset_clock()
        self.status(self.title)

    def is_running(self):
        return not self._closed and self.handle is not None and self.handle.is_running()

    def status(self, message, details=None, *, phase=None):
        now = _time.monotonic()
        if message != self.title or details is not None:
            self._status_started = now
        self.title = message
        if details is not None:
            self._details = details
        if phase is not None:
            self._phase = phase
        self._draw_status(now, force=True)

    def _status_lines(self, now):
        header = self.title
        details = [" ".join(line.split()) for line in self._details.splitlines() if line.strip()]
        if self._phase in ("thinking", "report"):
            header += f" · 已等待 {max(0, int(now - self._status_started))} 秒"
        waiting = getattr(self.world, "wait_progress", None)
        if waiting is not None:
            duration = waiting["end"] - waiting["start"]
            fraction = min(1.0, max(0.0, (float(self.world.data.time) - waiting["start"]) / duration)) if duration else 1.0
            header += f" · 剩余 {(1 - fraction) * waiting['counts']:.1f}/{waiting['counts']} 个计数"
            if not any(line.split("：", 1)[0].endswith("动作") for line in details):
                details = [f"动作：观察物体运动，持续 {waiting['counts']} 个计数", *details]
        return (" ".join(header.split()), *details)

    def _draw_status(self, now, force=False):
        if self.handle is None or (not force and now - self._last_status < 0.25):
            return
        self._last_status = now
        rect = self._hud.layout(self.handle.viewport)
        if rect is None:
            self.handle.clear_images()
            self.handle.clear_texts()
            self._last_hud = None
            return
        lines = self._status_lines(now)
        key = (*lines, rect.left, rect.bottom, rect.width, rect.height)
        if key == self._last_hud:
            return
        image = self._hud.render(lines, rect.width, rect.height)
        if image is not None:
            rect.height = image.shape[0]
            self.handle.clear_texts()
            self.handle.set_images((rect, image))
        else:
            self.handle.clear_images()
            if not self._font_warning:
                print("未找到中文字体，窗口使用简短英文提示；可用 LONGCHANG_FONT 指定中文字体，完整记录见终端。")
                self._font_warning = True
            fallback = f"AI status: {self._phase}\nSee terminal for action details"
            self.handle.set_texts((mujoco.mjtFontScale.mjFONTSCALE_100,
                                   mujoco.mjtGridPos.mjGRID_BOTTOMRIGHT, fallback, ""))
        self._last_hud = key

    def sync(self, *, force=False):
        if not self.is_running():
            raise InterruptedError("viewer closed")
        if self._model is not self.world.model or self._data is not self.world.data:
            self._reload_model()
        now = _time.monotonic()
        self._draw_status(now)
        if force or now - self._last_draw >= 1 / 60:
            self.handle.sync()
            self._last_draw = now
        if self.realtime:
            delay = self._start_wall + (float(self.world.data.time) - self._start_sim) / self.speed - _time.monotonic()
            if delay > 0:
                _time.sleep(min(delay, 0.02))

    def mouse_force(self):
        self.world.data.xfrc_applied[:] = 0
        if self.is_running() and (self._model is not self.world.model or self._data is not self.world.data):
            self._reload_model()
        if self.is_running():
            with self.handle.lock():
                mujoco.mjv_applyPerturbForce(self.world.model, self.world.data, self.handle.perturb)
        return self.world.data.xfrc_applied.copy()

    def close(self):
        self._closed = True
        if self.handle is not None:
            self.handle.close()
            self.handle = None
