"""模型可见的运动采样：相对 counts、关键点保留与可配置的轨迹压缩。

只输出取整位置和动静状态；速度、接触集合仅用于选择采样时机。
"""

from dataclasses import dataclass
import heapq

import numpy as np


@dataclass(frozen=True)
class MotionState:
    position: tuple
    velocity: tuple
    moving: bool
    contacts: frozenset = frozenset()
    raw_position: tuple | None = None


@dataclass
class _Point:
    tick: int
    position: tuple
    moving: bool
    key: bool = False


def _select(points, limit):
    """优先保留关键点，再按带时间的线性插值误差分配剩余名额。"""
    if limit is None or len(points) <= limit:
        return list(range(len(points)))
    ticks = np.asarray([p.tick for p in points], dtype=float)
    positions = np.asarray([p.position for p in points], dtype=float)
    moving = np.asarray([p.moving for p in points])
    keys = np.asarray([p.key for p in points])
    selected = {0, len(points) - 1}
    heap = []

    def segment(left, right):
        if right - left < 2:
            return
        candidates = np.arange(left + 1, right)
        key_candidates = candidates[keys[candidates]]
        priority = bool(len(key_candidates))
        if priority:
            candidates = key_candidates
        span = ticks[right] - ticks[left]
        fraction = (ticks[candidates] - ticks[left]) / span
        predicted = positions[left] + fraction[:, None] * (positions[right] - positions[left])
        errors = np.linalg.norm(positions[candidates] - predicted, axis=1)
        # 同位置的转动或短暂启停也需要保留，不能只看空间误差。
        errors += ((moving[candidates] != moving[left]) | (moving[candidates] != moving[right])) * 0.1
        midpoint = (ticks[left] + ticks[right]) / 2
        order = np.lexsort((np.abs(ticks[candidates] - midpoint), -errors))
        offset = int(order[0])
        index = int(candidates[offset])
        heapq.heappush(heap, (-int(priority), -float(errors[offset]), -span, index, left, right))

    segment(0, len(points) - 1)
    while heap and len(selected) < limit:
        _, _, _, index, left, right = heapq.heappop(heap)
        selected.add(index)
        segment(left, index)
        segment(index, right)
    return sorted(selected)


def _turn(vector, remembered, previous, tolerance):
    """记住非零方向；识别过零反向及突然的直角转向。"""
    signs = tuple(1 if value > tolerance else -1 if value < -tolerance else 0 for value in vector)
    if not any(signs):
        return False, remembered, previous
    reversed_axis = any(a * b < 0 for a, b in zip(signs, remembered))
    corner = any(previous) and sum(a * b for a, b in zip(signs, previous)) <= 0
    remembered = tuple(new if new else old for new, old in zip(signs, remembered))
    return reversed_axis or corner, remembered, signs


class _BodyTrace:
    BUFFER_LIMIT = 1024

    def __init__(self, tick, state, still_threshold, max_points):
        self.previous_tick, self.previous = tick, state
        self.points = [_Point(tick, state.position, state.moving, True)]
        self.sample_count = 1
        self.changed = False
        self.lost_keys = False
        self.still_threshold = still_threshold
        self.buffer_limit = None if max_points is None else max(self.BUFFER_LIMIT, 2 * max_points)
        self.velocity_signs = self.velocity_direction = (0, 0, 0)
        self.travel_signs = self.travel_direction = (0, 0, 0)
        _, self.velocity_signs, self.velocity_direction = _turn(
            state.velocity, self.velocity_signs, self.velocity_direction, still_threshold)

    def _store(self, tick, state, key=False):
        point = _Point(tick, state.position, state.moving, key)
        first = self.points[0]
        self.changed |= point.position != first.position or point.moving != first.moving
        if tick == self.points[-1].tick:
            point.key |= self.points[-1].key
            self.points[-1] = point
            return
        self.sample_count += 1
        # 相同位置/状态的连续平台只保留首尾，保留到达与离开平台的时间。
        if (len(self.points) >= 2 and not key and not self.points[-1].key
                and self.points[-2].position == self.points[-1].position == point.position
                and self.points[-2].moving == self.points[-1].moving == point.moving):
            self.points[-1] = point
        else:
            self.points.append(point)
        if self.buffer_limit is not None and len(self.points) > self.buffer_limit:
            chosen = _select(self.points, self.buffer_limit // 2)
            kept = set(chosen)
            self.lost_keys |= any(p.key and i not in kept for i, p in enumerate(self.points))
            self.points = [self.points[i] for i in chosen]

    def update(self, tick, state, *, regular=False, final=False):
        velocity_turn, self.velocity_signs, self.velocity_direction = _turn(
            state.velocity, self.velocity_signs, self.velocity_direction, self.still_threshold)
        previous_position = self.previous.raw_position or self.previous.position
        current_position = state.raw_position or state.position
        travel = tuple(b - a for a, b in zip(previous_position, current_position))
        travel_turn, self.travel_signs, self.travel_direction = _turn(
            travel, self.travel_signs, self.travel_direction, 1e-5)
        key = (velocity_turn or travel_turn or state.moving != self.previous.moving
               or state.contacts != self.previous.contacts)
        if key:
            self._store(self.previous_tick, self.previous, True)
        if key or regular or final:
            self._store(tick, state, key or final)
        self.previous_tick, self.previous = tick, state

    def observation(self, max_points, steps_per_count):
        if len(self.points) < 2 or not (self.changed or any(p.moving for p in self.points)):
            return None
        chosen = _select(self.points, max_points)
        kept = set(chosen)
        return {
            "trajectory": [
                {"count": round(p.tick / steps_per_count, 6),
                 "position": list(p.position), "state": "moving" if p.moving else "still"}
                for p in (self.points[i] for i in chosen)
            ],
            "omitted_samples": self.sample_count - len(chosen),
            "key_points_omitted": self.lost_keys or any(
                p.key and i not in kept for i, p in enumerate(self.points)),
        }


class MotionRecorder:
    """每个动作/观察区间独立计数；定期采样，并加采关键变化前后的点。"""

    def __init__(self, *, interval, max_points, steps_per_count, still_threshold):
        if (type(interval) is not int or interval < 1 or steps_per_count <= 0
                or (max_points is not None and (type(max_points) is not int or max_points < 2))):
            raise ValueError("invalid motion sampling configuration")
        self.interval = interval
        self.max_points = max_points
        self.steps_per_count = steps_per_count
        self.still_threshold = still_threshold
        self.tick = 0
        self.traces = {}

    def reset(self, states):
        self.tick = 0
        self.traces = {name: _BodyTrace(0, state, self.still_threshold, self.max_points)
                       for name, state in states.items()}

    def step(self, states):
        self.tick += 1
        for name, state in states.items():
            if name not in self.traces:
                self.traces[name] = _BodyTrace(self.tick, state, self.still_threshold, self.max_points)
            else:
                self.traces[name].update(self.tick, state, regular=self.tick % self.interval == 0)

    def events(self, states):
        events = {}
        for name, state in states.items():
            if name not in self.traces:
                self.traces[name] = _BodyTrace(self.tick, state, self.still_threshold, self.max_points)
            trace = self.traces[name]
            trace.update(self.tick, state, final=True)
            event = trace.observation(self.max_points, self.steps_per_count)
            if event is not None:
                events[name] = event
        return events
