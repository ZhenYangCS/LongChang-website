"""追溯报告引用与提取扣分 -> AI 核对 summary/原始观测/GT -> 简单规则算分。

grade(record, judge) 接收 agent 的实验记录，返回判定、扣分明细和总分。
"""

import argparse
import json
import math
from copy import deepcopy
from functools import partial
from hashlib import sha256
from pathlib import Path

from engine import PermanentAPIError, call_api, decode_json, reply_json, Settings
from world import write_json_atomic
from prompts import JUDGE, JUDGE_REPAIR_PROMPT

# 新实验的成功建造仅作统计；旧记录和显式参数仍保留原计分约定。
DEFAULT_PARAMETERS = {"discovery_points": 100.0, "build_success_cost": 0.0, "build_failure_cost": 1.0}


def normalize_report(summary):
    """兼容已有报告的字段错名，保留原文并记录转换，不补写实验结论。"""
    summary = reply_json(summary) if isinstance(summary, str) else deepcopy(summary)
    changes = []
    if not isinstance(summary, dict):
        return summary, changes
    for i, item in enumerate(summary.get("experiments", [])):
        if not isinstance(item, dict):
            continue
        for old, new in (("outcome:", "outcome"), ("execution", "outcome"), ("结果", "result")):
            if old in item:
                if new in item:
                    raise ValueError(f"experiment {i}: ambiguous fields {old}/{new}")
                item[new] = item.pop(old)
                changes.append(f"experiments[{i}]: {old} -> {new}")
        if "conditions" not in item:
            item["conditions"] = ""
            changes.append(f"experiments[{i}]: conditions left unspecified")
    for i, item in enumerate(summary.get("conclusions", [])):
        if isinstance(item, dict) and "result" in item and isinstance(item.get("reasoning"), str):
            if not isinstance(item["result"], str):
                raise ValueError("extra conclusion result must be text")
            item["reasoning"] += "\nAdditional result in original report: " + item.pop("result")
            changes.append(f"conclusions[{i}]: extra result preserved in reasoning")
    return summary, changes


def trace_report(summary, turns, *, complete=False):
    """检查 turn 引用，提取原始动作和观测供裁判核对。"""
    summary = reply_json(summary) if isinstance(summary, str) else summary
    if (not isinstance(summary, dict)
            or set(summary) != {"experiments", "conclusions"}
            or any(not isinstance(summary.get(key), list) for key in ("experiments", "conclusions"))
            or any(not isinstance(item, dict) for key in ("experiments", "conclusions") for item in summary[key])):
        raise ValueError("报告的 experiments/conclusions 必须是对象数组")
    for kind, fields in (("experiments", {"turn", "action", "conditions", "outcome", "result"}),
                         ("conclusions", {"claim", "preconditions", "evidence_turns", "reasoning"})):
        for item in summary[kind]:
            if set(item) != fields or any(not isinstance(item[key], str)
                                          for key in fields - {"turn", "evidence_turns"}):
                raise ValueError(f"{kind} requires fields {sorted(fields)} with text values")
            if kind == "conclusions" and not item["claim"].strip():
                raise ValueError("conclusion claim cannot be empty")
    actual = {t["turn"] for t in turns}
    reported = [e["turn"] for e in summary["experiments"]]
    if (any(type(n) is not int or n not in actual for n in reported)
            or len(set(reported)) != len(reported)):
        raise ValueError("experiments 必须引用不重复的真实 turn")
    for index, conclusion in enumerate(summary["conclusions"], 1):
        cited = conclusion.get("evidence_turns", [])
        if (not isinstance(cited, list) or not cited
                or any(type(n) is not int for n in cited)):
            raise ValueError("每条结论的 evidence_turns 必须非空，且引用 experiments 中记录的真实 turn")
        missing = [n for n in cited if n not in reported]
        if missing:
            raise ValueError(f"第{index}条结论的 evidence_turns 引用了未列入 experiments 的轮次：{missing}")
    selected = set(reported) | {t["turn"] for t in turns
                                if t["outcome"] != "ok" or t["act"].upper().split(maxsplit=1)[:1] == ["BUILD"]}
    evidence = [{**{k: t[k] for k in ("turn", "act", "outcome", "observation", "result_observation")},
                 **({"note": t.get("note"), "raw": t.get("raw")} if complete else {})}
                for t in turns if complete or t["turn"] in selected]
    return summary, evidence


def _parse_judgement(raw, control, evidence_ids, actions, decisions):
    """校验裁判输出；格式修正不得改变已经给出的合法布尔判定。"""
    judgement = reply_json(raw)
    if isinstance(judgement, dict):
        for key, kind in (("correct", bool), ("supported", type(None) if control else bool)):
            if key in judgement and type(judgement[key]) is kind:
                if key in decisions and judgement[key] is not decisions[key]:
                    raise ValueError(f"格式修正不得改变已有判定：{key} 必须保持 {decisions[key]!r}")
                decisions.setdefault(key, judgement[key])
    if not isinstance(judgement, dict) or set(judgement) != {"correct", "supported", "reason", "action_errors"}:
        raise ValueError("裁判必须且只能返回 correct/supported/reason/action_errors")
    if type(judgement["correct"]) is not bool or type(judgement["supported"]) is not (type(None) if control else bool):
        raise ValueError("correct 必须为布尔值；supported 在正常场景为 null，异常场景为布尔值")
    if not isinstance(judgement["reason"], str) or not judgement["reason"].strip() or not isinstance(judgement["action_errors"], list):
        raise ValueError("reason 必须为非空文字，action_errors 必须为列表")
    for index, error in enumerate(judgement["action_errors"]):
        if (not isinstance(error, dict) or set(error) != {"turn", "kind", "reason"}
                or type(error["turn"]) is not int or error["turn"] not in evidence_ids
                or actions[error["turn"]] in {"", "DONE", "WAIT", "MARK", "CLOCK", "WEIGH"}
                or error["kind"] not in {"physics_usage", "tool_design"}
                or not isinstance(error["reason"], str) or not error["reason"].strip()):
            raise ValueError(f"action_errors[{index}] 必须包含可扣分的真实 turn、kind 和非空 reason；"
                             f"收到 {error!r}")
    return judgement


def grade(record, judge=None, *, model=None, parameters=None, log=None, checkpoint=None, output=None, settings=None):
    """评一局；judge 接收 messages 并返回 JSON 文本，省略时使用 engine.call_api。"""
    settings = settings or Settings.from_env()
    model = model or (settings.judge_model or settings.model if judge is None else None)
    result = {"status": "running", "judge_model": model, "judge_prompt": JUDGE,
              "request_settings": settings.public(), "episode_id": record.get("episode_id")}
    if output is not None:
        if checkpoint is not None:
            raise ValueError("Use output or checkpoint, not both")
        write_json_atomic(output, result, overwrite=False)
        checkpoint = partial(write_json_atomic, output)
    try:
        inputs = {k: record.get(k) for k in ("status", "scene_spec", "report", "turns", "resource_usage", "scoring_parameters")}
        result["input_sha256"] = sha256(json.dumps(inputs, sort_keys=True, ensure_ascii=False,
                                                  allow_nan=False).encode()).hexdigest()
        # 1. 读取总结、GT 和 JSON 中的客观扣分项。
        summary, gt = record["report"], record["scene_spec"]["oracle"]
        if record["status"] != "complete" or not summary or isinstance(summary, str) and not summary.strip():
            raise ValueError("需要已完成的实验和非空 report")
        if type(gt["control"]) is not bool or not gt["ground_truth"]:
            raise ValueError("GT 必须包含 control 和 ground_truth")
        weights = dict(DEFAULT_PARAMETERS)
        for source in (record.get("scoring_parameters", {}), parameters or {}):
            source = dict(source)
            # 兼容已有记录中的旧名称；新记录和输出统一使用 build_*_cost。
            for old, new in (("apparatus_cost_points", "build_success_cost"),
                             ("action_error_cost_points", "build_failure_cost")):
                if old in source:
                    source.setdefault(new, source.pop(old))
            weights.update(source)
        if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in weights.values()):
            raise ValueError("计分参数必须是有限非负数")
        built = record["resource_usage"]["tools"]
        if type(built) is not int or built < 0:
            raise ValueError("器材数量必须是非负整数")
        turns = record["turns"]
        failed = {t["turn"] for t in turns if t["outcome"] != "ok"}
        actions = {t["turn"]: t["act"].split(maxsplit=1)[0].upper() if t["act"].strip() else "" for t in turns}
        if len(actions) != len(turns) or any(type(n) is not int or n < 1 for n in actions):
            raise ValueError("turn 编号必须是不重复的正整数")
        if any(not isinstance(t["outcome"], str) or t["outcome"] in {"", "pending"} for t in turns):
            raise ValueError("turn 必须有实际执行结果")

        # 2. 按报告引用回查真实轮次；裁判核对原始观测，不替作者补全论证。
        summary, result["report_normalization"] = normalize_report(summary)
        summary, evidence = trace_report(summary, turns, complete=True)
        evidence_ids = {t["turn"] for t in evidence}
        # 完全相同的观察只发送一次；引用首个原文位置，不删数值、不做语义总结。
        seen = {}
        for row in evidence:
            for field in ("observation", "result_observation"):
                key = json.dumps(row[field], sort_keys=True, ensure_ascii=False, allow_nan=False)
                if key in seen:
                    row[field] = {"same_as": seen[key]}
                else:
                    seen[key] = [row["turn"], field]
        # 指令与实际场景程序用于解释操作范围和答案，不作为模型亲自观察到的证据。
        context = {key: record.get(key) for key in
                   ("prompt", "final_prompt", "tools_mode", "action_protocol", "budget", "runtime")}
        implementation = {key: record["scene_spec"].get(key) for key in ("program", "state")}
        messages = [{"role": "system", "content": JUDGE},
                    {"role": "user", "content": json.dumps({"summary": summary, "gt": gt, "evidence": evidence,
                                                            "context": context, "implementation": implementation},
                                                           ensure_ascii=False, allow_nan=False, separators=(",", ":"))}]
        result["evaluation_version"] = "complete-evidence-2026-10-04"
        result["request_sha256"] = sha256(json.dumps(messages, ensure_ascii=False,
                                                    sort_keys=True).encode()).hexdigest()
        original, decisions = messages, {}
        result.update(status="running", judge_attempts=[])
        if checkpoint is not None:
            checkpoint(result)
        for number in range(1, settings.judge_attempts + 1):
            raw = judge(messages) if judge is not None else call_api(
                messages, model=model, log=log, settings=settings)
            result["raw_response"] = raw
            attempt = {"attempt": number, "raw_response": raw, "status": "received"}
            result["judge_attempts"].append(attempt)
            if not isinstance(raw, str):
                raise TypeError("裁判接口必须返回 JSON 文本")
            try:
                judgement = _parse_judgement(raw, gt["control"], evidence_ids, actions, decisions)
            except (ValueError, KeyError, TypeError) as error:
                attempt.update(status="invalid", error=str(error))
                if checkpoint is not None:
                    checkpoint(result)
                if number == settings.judge_attempts:
                    raise ValueError(f"裁判连续{number}次返回无效结果：{error}") from error
                if log is not None:
                    log(f"裁判第{number}次格式校验未通过，正在修正：{error}")
                messages = original + [{"role": "assistant", "content": raw},
                    {"role": "user", "content": JUDGE_REPAIR_PROMPT.format(error=error)}]
                continue
            attempt["status"] = "valid"
            break

        # 3. 正确且有实验论证得基础分；正常场景只看是否误报。同轮错误只扣一次。
        base = weights["discovery_points"] if judgement["correct"] and (gt["control"] or judgement["supported"]) else 0.0
        error_turns = sorted(failed | {error["turn"] for error in judgement["action_errors"]})
        failed_build_turns = sorted(n for n in failed if actions[n] == "BUILD")
        build_success_cost = built * weights["build_success_cost"]
        build_failure_cost = len(failed_build_turns) * weights["build_failure_cost"]
        action_error = len(error_turns) * weights["build_failure_cost"]
        if any(not math.isfinite(value) for value in
               (base, build_success_cost, build_failure_cost, action_error, base - build_success_cost - action_error)):
            raise ValueError("计分结果超出有限数值范围，请检查成本参数")
        result.update(status="complete", judgement=judgement, parameters=weights,
                      built_tools=built, failed_builds=len(failed_build_turns),
                      failed_build_turns=failed_build_turns, rejected_turns=sorted(failed),
                      scorecard={"base_score": base, "build_success_cost": build_success_cost,
                                 "build_failure_cost": build_failure_cost,  # 已包含在 action_error_penalty 中。
                                 "action_error_penalty": action_error, "error_turns": error_turns,
                                 "total_score": base - build_success_cost - action_error})
    except (KeyboardInterrupt, InterruptedError) as error:
        result.update(status="interrupted", error=type(error).__name__)
        if checkpoint is not None:
            checkpoint(result)
        raise
    except Exception as error:
        result.update(status="failed", error=str(error), error_type=type(error).__name__)
        if isinstance(error, PermanentAPIError):
            result["api_failure"] = error.details
        if isinstance(error, PermanentAPIError) and error.raw_response is not None:
            result["raw_response"] = error.raw_response
            attempts = result.setdefault("judge_attempts", [])
            attempts.append({"attempt": len(attempts) + 1, "raw_response": error.raw_response,
                             "status": "incomplete", "error": str(error)})
    if checkpoint is not None:
        checkpoint(result)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("source", type=Path, help="单局 session.json 或所在目录")
    parser.add_argument("--judge-model")
    parser.add_argument("--output", type=Path, help="新的评分文件；默认使用同目录 eval.json，已有文件不覆盖")
    args = parser.parse_args(argv)
    source = args.source / "session.json" if args.source.is_dir() else args.source
    output = args.output or source.with_name("eval.json")
    if source.resolve() == output.resolve():
        parser.error("输入应为 session.json，不能覆盖输入文件")
    try:
        result = grade(decode_json(source.read_text(encoding="utf-8")), model=args.judge_model,
                       output=output)
    except (KeyboardInterrupt, InterruptedError):
        return 130
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(f"{output}: " + (f"总分 {result['scorecard']['total_score']:g}" if result["status"] == "complete" else result["error"]))
    return int(result["status"] != "complete")


if __name__ == "__main__":
    raise SystemExit(main())
