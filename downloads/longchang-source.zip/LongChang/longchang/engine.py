"""模型 API 执行、用量读写与 JSON 解析。

API 执行：调用模型、失败重试，以及用进程池并行处理任务。
用量读写：从完整 API 响应提取 usage，并将数据保存为 JSON。
JSON 解析：供场景、动作和评审共用，拒绝重复字段与非有限常量。
"""

import json
import math
import os
from dataclasses import dataclass, field
from email.utils import parsedate_to_datetime
from random import SystemRandom
import re
import sys
from http.client import HTTPException
import time
from copy import deepcopy
import urllib.error
import urllib.request
from multiprocessing import Pool
from pathlib import Path

@dataclass(frozen=True)
class Settings:
    model: str | None = None
    judge_model: str | None = None
    generator_model: str | None = None
    review_model: str | None = None
    compact_threshold: int | None = None
    scene_compact_threshold: int | None = None
    reference_preprocess: bool = True
    reference_max_bytes: int = 65536
    report_attempts: int = 3
    judge_attempts: int = 3
    scene_attempts: int | None = None
    api: dict = field(default_factory=lambda: dict(base=None, key=None, extra={}, timeout=300.0, max_attempts=None))
    responses_extra: dict | None = None

    @classmethod
    def from_env(cls, env=None):
        env = os.environ if env is None else env

        def integer(name, default, minimum=1, optional=False):
            raw = str(env.get(name, default)).strip()
            if optional and not raw:
                return None
            if not raw.isdigit() or int(raw) < minimum:
                raise ValueError(f"{name} must be an integer >= {minimum}")
            return int(raw)

        def object_value(name):
            value = json.loads(env.get(name) or '{}')
            if not isinstance(value, dict):
                raise ValueError(f"{name} must be a JSON object")
            return value

        enabled = env.get('REFERENCE_PREPROCESS', '1')
        if enabled not in {'0', '1'}:
            raise ValueError('REFERENCE_PREPROCESS must be 0 or 1')
        timeout = float(env.get('API_TIMEOUT_SECONDS', 300))
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError('API_TIMEOUT_SECONDS must be positive and finite')
        judge = env.get('JUDGE_MODEL') or None
        return cls(model=env.get('MODEL') or None, judge_model=judge,
                   generator_model=env.get('GENERATOR_MODEL') or None,
                   review_model=env.get('BUILD_REVIEW_MODEL') or judge,
                   compact_threshold=integer('COMPACT_THRESHOLD', '', 1000, optional=True),
                   scene_compact_threshold=integer('SCENE_COMPACT_THRESHOLD', '', 1000, optional=True),
                   reference_preprocess=enabled == '1',
                   reference_max_bytes=integer('REFERENCE_MAX_BYTES', 65536, 8192) if enabled == '1' else 65536,
                   report_attempts=integer('REPORT_MAX_ATTEMPTS', 3),
                   judge_attempts=integer('JUDGE_MAX_ATTEMPTS', 3),
                   scene_attempts=integer('SCENE_MAX_ATTEMPTS', '', optional=True),
                   api=dict(base=env.get('BASE_URL'), key=env.get('API_KEY'), extra=object_value('EXTRA_BODY'),
                            timeout=timeout, max_attempts=integer('API_MAX_ATTEMPTS', '', optional=True)),
                   responses_extra=object_value('RESPONSES_EXTRA_BODY') if env.get('RESPONSES_EXTRA_BODY') else None)

    def public(self):
        """存档运行策略和模型参数，排除连接地址与凭证。"""
        return dict(judge_model=self.judge_model, generator_model=self.generator_model,
                    review_model=self.review_model, compact_threshold=self.compact_threshold,
                    scene_compact_threshold=self.scene_compact_threshold,
                    report_attempts=self.report_attempts, judge_attempts=self.judge_attempts, scene_attempts=self.scene_attempts,
                    reference_preprocess=self.reference_preprocess, reference_max_bytes=self.reference_max_bytes,
                    api=deepcopy({k: v for k, v in self.api.items() if k not in {'base', 'key'}}),
                    responses_extra=deepcopy(self.responses_extra))


def write_log(message, directory=None, *, label="", started=None, progress=None):
    """将一行日志追加到本局 run.log。"""
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} [{label or 'API'}]"
    if started is not None:
        elapsed = time.monotonic() - started
        line += f" 已运行={elapsed:.1f}s"
        if progress is not None:
            done, total = progress["done"], progress["total"]
            eta = f"{elapsed * max(0, total - done) / done:.1f}s" if done else "估算中"
            line += f" 预计剩余≈{eta}"
    line += f" | {message}"
    if directory is not None:
        with (Path(directory) / "run.log").open("a", encoding="utf-8") as output:
            output.write(line + "\n")
    else:
        print(line, file=sys.stderr, flush=True)


# 1. API 执行：失败重试、模型请求和并行任务。

class PermanentAPIError(RuntimeError):
    """接口响应错误；仅在显式限定的重试耗尽后传给调用方。"""

    def __init__(self, message, *, raw_response=None, response=None, finish_reason=None):
        super().__init__(message)
        self.raw_response = raw_response
        self.details = {key: response[key] for key in ("id", "status", "usage", "incomplete_details")
                        if response and key in response}
        if finish_reason is not None:
            self.details['finish_reason'] = finish_reason


def retry(func, *args, max_attempts=None, log=None, **kwargs):
    """API 失败默认等待后无限重试；max_attempts 可用于有限次接口测试。"""
    if max_attempts is not None and (type(max_attempts) is not int or max_attempts < 1):
        raise ValueError("max_attempts must be a positive integer or None")
    attempt, delay = 0, 2
    while True:
        try:
            return func(*args, **kwargs)
        except (urllib.error.URLError, TimeoutError, ConnectionError, HTTPException, PermanentAPIError) as error:
            wait = delay
            permanent_http = False
            if isinstance(error, urllib.error.HTTPError):
                try:
                    payload = decode_json(error.read())
                    detail = payload.get("error", payload)
                    if isinstance(detail, dict):
                        detail = detail.get("message") or detail.get("code")
                    if detail:
                        error.msg = " ".join(str(detail).split())[:800]
                except (ValueError, AttributeError, TypeError):
                    pass
                # The same invalid/oversized request cannot be repaired by sending it again.
                permanent_http = 400 <= error.code < 500 and error.code not in {408, 409, 425, 429}
                header = (error.headers or {}).get("Retry-After")
                try:
                    after = float(header)
                except (TypeError, ValueError):
                    try:
                        after = parsedate_to_datetime(header).timestamp() - time.time()
                    except (TypeError, ValueError, OverflowError):
                        after = None
                if after is not None and math.isfinite(after) and after >= 0:
                    wait = max(wait, after)
                elif error.code == 429:
                    wait = max(wait, 60)
            attempt += 1
            stop = permanent_http or max_attempts is not None and attempt >= max_attempts
            # 错峰使用系统随机源，不改变物理场景的随机数序列。
            if not stop:
                wait += SystemRandom().uniform(0, min(5, wait / 10))
            (log or write_log)(f"ERROR API第{attempt}/{max_attempts or '不限'}次失败：{type(error).__name__}: {error}；"
                               + ("停止重试" if stop else f"{wait:.1f}秒后重试"))
            if stop:
                if isinstance(error, urllib.error.HTTPError):
                    raise PermanentAPIError(f"HTTP {error.code}: {error.reason}") from error
                raise
            time.sleep(wait)
            delay = min(delay * 2, 120)


def _request(endpoint, body, options, log, parse=None):
    """Chat 与 Responses 共用连接、重试及响应解码。"""
    if not options['base'] or not options['key'] or not body.get('model'):
        raise ValueError("API calls require a model, BASE_URL and API_KEY")
    request = urllib.request.Request(
        options['base'].rstrip('/') + endpoint,
        data=json.dumps(body, allow_nan=False).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'Authorization': f"Bearer {options['key']}"})

    def send():
        with urllib.request.urlopen(request, timeout=options['timeout']) as response:
            raw = response.read().decode('utf-8')
        try:
            # 部分网关在非流式请求下返回仅含用量的空 SSE；按空回复重试，不执行流中的草稿。
            if endpoint == '/chat/completions' and raw.lstrip().startswith('data:'):
                lines = [line.strip() for line in raw.splitlines() if line.strip()]
                if all(line.startswith('data:') for line in lines):
                    packets = [line[5:].strip() for line in lines]
                    if packets[-1] == '[DONE]':
                        chunks = [decode_json(packet) for packet in packets[:-1]]
                        if chunks and all(isinstance(c, dict) and c.get('object') == 'chat.completion.chunk'
                                          and c.get('choices') == [] and 'error' not in c for c in chunks):
                            raise PermanentAPIError('API response contains no text', response=chunks[-1], raw_response=raw)
            response = decode_json(raw)
            if not isinstance(response, dict):
                raise ValueError("Expected an API response object")
        except ValueError as error:
            raise PermanentAPIError(f"Invalid API response: {error}", raw_response=raw) from error
        return parse(response) if parse is not None else response

    return retry(send, max_attempts=options['max_attempts'], log=log)


_DEFAULT = object()


def call_api(messages, model=None, base=None, key=None, extra=None, *,
             timeout=None, max_attempts=_DEFAULT, log=None, settings=None):
    """返回一条完整文本；接口错误或未完成回复进入统一重试。"""
    settings = settings or Settings.from_env()
    options = {**settings.api, **{k: v for k, v in dict(base=base, key=key, timeout=timeout).items() if v is not None}}
    if max_attempts is not _DEFAULT:
        options['max_attempts'] = max_attempts
    extra = options['extra'] if extra is None else (decode_json(extra) if isinstance(extra, str) else extra)

    def text_response(response):
        try:
            choice = response['choices'][0]
            content = choice['message']['content']
        except (KeyError, IndexError, TypeError) as error:
            raise PermanentAPIError(f"Invalid Chat response: {error}", response=response,
                                    raw_response=json.dumps(response, ensure_ascii=False)) from error
        finish = choice.get('finish_reason')
        if finish not in (None, 'stop'):
            raise PermanentAPIError(f"API response incomplete: finish_reason={finish}", finish_reason=finish,
                                    raw_response=content if isinstance(content, str) else json.dumps(response, ensure_ascii=False),
                                    response=response)
        if not isinstance(content, str) or not content.strip():
            raise PermanentAPIError('Invalid Chat response: API response contains no text', response=response,
                                    raw_response=json.dumps(response, ensure_ascii=False))
        return content

    return _request('/chat/completions', {**extra, 'model': model or settings.model,
                    'messages': messages, 'stream': False, 'n': 1}, options, log, parse=text_response)


class ResponsesConversation:
    """每局一个 Responses 工作上下文；接收原始 transcript，但只发送新增消息。

    transcript 只追加 user/assistant 消息；首条 system 可在最终报告时替换。
    calls 保存输入增量、完整 API output 和压缩边界，不重复存储每轮全历史。
    """

    @staticmethod
    def validate_threshold(value):
        if isinstance(value, str) and value.isdigit():
            value = int(value)
        if type(value) is not int or value < 1000:
            raise ValueError("COMPACT_THRESHOLD 必须是至少 1000 的整数 token 数；不设置时关闭压缩")
        return value

    def __init__(self, model, threshold, *, base=None, key=None, extra=None,
                 timeout=None, max_attempts=_DEFAULT, log=None, settings=None):
        if model != "gpt-6-astra":
            raise ValueError("原生上下文压缩目前仅支持已验证的 gpt-6-astra")
        self.model = model
        self.threshold = self.validate_threshold(threshold)
        settings = settings or Settings.from_env()
        self.api = {**settings.api, **{k: v for k, v in dict(base=base, key=key, timeout=timeout).items() if v is not None}}
        if max_attempts is not _DEFAULT:
            self.api['max_attempts'] = max_attempts
        if extra is None:
            extra = settings.responses_extra if settings.responses_extra is not None else settings.api['extra']
        self.extra = decode_json(extra) if isinstance(extra, str) else deepcopy(extra)
        if not isinstance(self.extra, dict):
            raise ValueError("RESPONSES_EXTRA_BODY 必须是 JSON 对象")
        for name in ("conversation", "previous_response_id", "response_format"):
            if name in self.extra:
                raise ValueError(f"独立压缩会话不接受 {name}；请用 RESPONSES_EXTRA_BODY 配置 Responses 参数")
        for name in ("max_tokens", "max_completion_tokens"):
            if name in self.extra:
                if "max_output_tokens" in self.extra:
                    raise ValueError("请只设置一种输出 token 上限")
                self.extra["max_output_tokens"] = self.extra.pop(name)
        if "reasoning_effort" in self.extra:
            self.extra["reasoning"] = {**self.extra.get("reasoning", {}),
                                       "effort": self.extra.pop("reasoning_effort")}
        self.log = log or write_log
        self.policy = {"endpoint": "/responses", "store": False, "truncation": "disabled",
                       "context_management": [{"type": "compaction", "compact_threshold": self.threshold}]}
        self.calls = []
        self.turn, self.phase = 0, "exploration"
        self._context, self._consumed, self._reply, self._instructions = [], 1, None, None

    def __call__(self, messages):
        if not messages or messages[0].get("role") != "system":
            raise ValueError("Responses 会话需要首条 system 指令")
        start = self._consumed
        if self._reply is not None:
            if len(messages) <= start or messages[start] != {"role": "assistant", "content": self._reply}:
                raise ValueError("Responses transcript 必须保留上一条原始 assistant 回复")
            start += 1
        fresh = deepcopy(messages[start:])
        # A fresh session may reconstruct saved visible history after encrypted state is rejected.
        allowed_roles = {'user', 'assistant'} if not self._context and self._reply is None else {'user'}
        if (not fresh or fresh[-1].get('role') != 'user'
                or any(item.get("role") not in allowed_roles for item in fresh)):
            raise ValueError("Responses 会话需要新增的 user 观测或反馈")
        instructions = messages[0]["content"]
        # 原生压缩状态可携带旧指令；任务切换时在该状态之后明确加入新的 system 指令。
        if self._instructions is not None and instructions != self._instructions:
            fresh.insert(0, {"role": "system", "content": instructions})
        body = {**self.extra, **self.policy, "model": self.model, "instructions": instructions,
                "input": self._context + fresh, "stream": False,
                "include": list(dict.fromkeys([*self.extra.get("include", []), "reasoning.encrypted_content"]))}
        body.pop("endpoint")
        body.pop("messages", None)
        body.pop("n", None)
        def text_response(response):
            output = response.get("output", [])
            event = {"call": len(self.calls) + 1, "turn": self.turn, "phase": self.phase,
                     "response_id": response.get("id"), "status": response.get("status"),
                     "usage": deepcopy(get_usage(response)), "input": fresh, "output": deepcopy(output)}
            if instructions != self._instructions:
                event["instructions"] = instructions
            self.calls.append(event)
            if response.get("status") != "completed":
                incomplete = response.get('incomplete_details') or {}
                raise PermanentAPIError(f"Responses 未完成：{response.get('status')}；{response.get('incomplete_details')}",
                                        raw_response=json.dumps(output, ensure_ascii=False), response=response,
                                        finish_reason='length' if isinstance(incomplete, dict) and
                                        incomplete.get('reason') == 'max_output_tokens' else None)
            if not isinstance(output, list) or any(not isinstance(item, dict) for item in output):
                raise PermanentAPIError("Responses output 格式错误")
            replies = [item for item in output if item.get("type") == "message" and item.get("role") == "assistant"]
            content = "\n".join(part["text"] for part in (replies[-1].get("content", []) if replies else [])
                                if part.get("type") == "output_text" and isinstance(part.get("text"), str))
            if not content.strip():
                raise PermanentAPIError("Responses 未返回可解析的文本回复")
            compact = [index for index, item in enumerate(output) if item.get("type") == "compaction"]
            if any(not isinstance(output[index].get("encrypted_content"), str)
                   or not output[index]["encrypted_content"] for index in compact):
                raise PermanentAPIError("Responses 压缩项缺少 encrypted_content")
            # 压缩项已经覆盖此前输入及该项之前的输出；只保留最后一个压缩项及后续输出。
            self._context = output[compact[-1]:] if compact else body["input"] + output
            event["compaction_count"] = len(compact)
            if compact:
                event["retained_output_start"] = compact[-1]
                self.log(f"上下文压缩：阶段={self.phase}；轮次={self.turn}；阈值={self.threshold} tokens")
            self._consumed, self._reply, self._instructions = len(messages), content, instructions
            return content

        return _request('/responses', body, self.api, self.log, parse=text_response)


def run_pool(func, jobs, workers=4):
    """用进程池执行任务，按输入顺序返回结果。"""
    with Pool(processes=workers) as pool:
        return pool.map(func, jobs, chunksize=1)


# 2. 用量读写：提取 API 响应里的 usage，并保存为 JSON。

def get_usage(response):
    """取出 API 响应中的 usage 字段，保留原始内容。"""
    return response.get("usage", {})


def save_usage(path, data):
    """把 data 写入指定的 JSON 文件，返回文件路径。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2), encoding="utf-8")
    return path


# 3. JSON 解析：共用同一组检查，避免重复字段被静默覆盖。

def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON field: {key}")
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError(f"Non-finite JSON value: {value}")


def decode_json(text):
    """将完整文本解析为 JSON，拒绝重复字段和 NaN/Infinity 常量。"""
    return json.loads(text, object_pairs_hook=_unique_object, parse_constant=_invalid_constant)


def unwrap_fence(text):
    """仅移除包住全部回复的一层代码围栏，不猜测或截取正文里的 JSON。"""
    text = text.strip()
    match = re.fullmatch(r"```(?:json|text)?[ \t]*\r?\n([\s\S]*?)\r?\n```", text, re.I)
    return match[1].strip() if match else text


def reply_json(text):
    """模型回复允许完整代码围栏；文件读取继续使用严格 decode_json。"""
    return decode_json(unwrap_fence(text))
