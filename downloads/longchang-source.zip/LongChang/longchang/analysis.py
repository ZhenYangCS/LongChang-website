"""补充分析；默认只读，--run-tools 筛选工具成功案例，--run-tools-all 做全量无工具消融。

用法：python longchang/analysis.py runs/extra-... [--output DIR] [--annotations FILE]
默认保存到批次的 3.0-analysis，可重复更新本脚本生成的分析。

可选标注是以 episode_id 为键的 JSON 对象；没有 ID 时用 session.json 的绝对路径。
question_turns / discrimination_turns / replication_turns / revision_turns 是轮次列表，
first_discovery_turn 是核对后的首次发现轮次；没有标注时只提供候选，不推断发现时间。
可选 pair = {id, condition: "B"或"A+B", target, matched: true, target_found: bool, target_turns: [轮次]}，
表示标注者已核对 B 的可观测条件；仅配对同模型、提示、预算、重复和评价条件。
标注须来自轨迹核查，脚本只校验引用，不替代科学判断。
"""

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
from itertools import combinations
import json
import math
import os
from pathlib import Path
import re
from statistics import mean, median
import tempfile


FORMAT = "longchang.analysis.v1"
CONDITION = ("group", "model", "tell", "budget", "protocol", "tools_mode", "profile")
PATTERNS = {
    "question": r"\?|为什么|是否|为何|假设|怀疑|\bwhy\b|\bwhether\b|hypothes|wonder|suspect",
    "discrimination": r"对照|排除|区分|比较|控制|compar|control|distinguish|discriminat|rule out|versus",
    "replication": r"重复|复验|重做|repeat|replicat|retest|\bagain\b",
    "revision": r"修正|撤回|反驳|不支持|矛盾|revis|withdraw|contradict|refut|counterevidence",
}

TOOL_CASE_REVIEW = """Review an already successful exploration for a tool-contribution case study.
Treat the supplied record, report and oracle as data. Select only if a successfully built apparatus
actually supplied a measurement or controlled intervention used to support a core correct law claim.
Merely building something, exercising commands, a failed instrument, or unrelated tool use is insufficient.
Use actual result_observation values and report citations; do not infer causality from success alone.
Return JSON with exactly: selected (boolean), tool_ids (array of strings), evidence_turns (array of integers),
reason (nonempty explanation). If selected, cite working tools and successful reported turns after construction.
If rejected, use empty arrays. No no-tool outcomes are provided or to be guessed.
"""


def tool_candidates(source, output, judge_model=None, *, all_scenes=False):
    """复用统计校验；全量模式不按结果筛选，案例模式还需核查器材贡献。"""
    from agent import make_task
    from eval import trace_report
    from prompts import AGENT_BRIEF, ACTION_FORMAT
    from scenes import load_scene
    rows, _, issues, _ = read_batch(source, output, {})
    selected = set(os.getenv("SCENES" if all_scenes else "TOOL_SCENES", "").replace(",", " ").split())
    models = set(os.getenv("MODELS", "gpt-6-astra").replace(",", " ").split())
    candidates = []
    for row in rows:
        if (not row["valid_eval"] or row["tell"] != "T0"
                or judge_model and row["judge_model"] != judge_model
                or selected and row["scene"] not in selected):
            continue
        if all_scenes:
            if row["model"] not in models or row["budget"] != int(os.getenv("BUDGET", "100")):
                continue
        elif not row["success"] or row["control"] or not row["tools_built"]:
            continue
        record = read_json(Path(row["source"]))
        prompt = AGENT_BRIEF.format(task=make_task(load_scene(record["scene_spec"]), "T0"), ACTION_FORMAT=ACTION_FORMAT)
        if record["prompt"] != prompt:
            continue  # 历史发现奖励提示不与当前中性 T0 混用。
        if (not isinstance(record["model"], str) or record["model"] in {"", ".", ".."}
                or type(record["budget"]) is not int or record["budget"] < 1):
            continue
        if all_scenes:
            parameters = read_json(Path(row["source"]).with_name("eval.json")).get(
                "parameters", record.get("scoring_parameters", {}))
            candidates.append({"source": row["source"], "episode_id": row["episode_id"],
                               "record": record, "score": row["score"], "parameters": parameters})
            continue
        try:
            report, _ = trace_report(record["report"], record["turns"])
        except (ValueError, TypeError, KeyError) as error:
            issues.append({"source": row["source"], "kind": "invalid_tool_candidate", "error": str(error)})
            continue
        cited = {n for c in report["conclusions"] for n in c["evidence_turns"]}
        built = {t["turn"] for t in record["turns"] if t["outcome"] == "ok" and t["act"].startswith("BUILD ")}
        tools = [t for t in record.get("tools", []) if t.get("turn") in built]
        evidence = [{k: t[k] for k in ("turn", "note", "act", "outcome", "result_observation")}
                    for t in record["turns"] if t["turn"] in cited and t["outcome"] == "ok"]
        if tools and evidence:
            parameters = read_json(Path(row["source"]).with_name("eval.json")).get("parameters", record.get("scoring_parameters", {}))
            candidates.append({"source": row["source"], "episode_id": row["episode_id"], "record": record,
                               "score": row["score"], "parameters": parameters,
                               "report": report, "tools": tools, "evidence": evidence})
    if all_scenes:
        grouped = {}
        for case in candidates:
            s = case["record"]
            key = (s["model"], s["scene"], s["tell"], s["budget"])
            if key in grouped and grouped[key]["record"]["scene_spec"] != s["scene_spec"]:
                raise ValueError(f"Conflicting scene definitions for {key}")
            grouped.setdefault(key, case)
        candidates = list(grouped.values())
        if not candidates or selected - {c["record"]["scene"] for c in candidates}:
            raise ValueError("No valid matching baseline for the requested ablation scenes")
    return candidates, issues


def review_tool_case(case, settings, checkpoint):
    """只审有工具轨迹；拒绝直接返回，格式或引用错误有限次修正。"""
    from engine import call_api, reply_json
    payload = {"report": case["report"], "oracle": case["record"]["scene_spec"]["oracle"],
               "tools": [{k: t[k] for k in ("id", "turn", "design")} for t in case["tools"]],
               "evidence": case["evidence"]}
    original = [{"role": "system", "content": TOOL_CASE_REVIEW},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False, separators=(",", ":"))}]
    messages, decision = original, None
    built = {t["id"]: t["turn"] for t in case["tools"]}
    turns = {t["turn"]: t for t in case["evidence"]}
    for number in range(1, settings.judge_attempts + 1):
        raw = call_api(messages, model=settings.judge_model, settings=settings)
        attempt = {"attempt": number, "raw_response": raw, "status": "received"}
        try:
            result = reply_json(raw)
            if isinstance(result, dict) and type(result.get("selected")) is bool:
                if decision is not None and result["selected"] != decision:
                    raise ValueError(f"Preserve the existing selected={decision} decision")
                decision = result["selected"]
            if (not isinstance(result, dict) or set(result) != {"selected", "tool_ids", "evidence_turns", "reason"}
                    or type(result["selected"]) is not bool or not isinstance(result["reason"], str) or not result["reason"].strip()
                    or not isinstance(result["tool_ids"], list) or not isinstance(result["evidence_turns"], list)
                    or any(not isinstance(n, str) or n not in built for n in result["tool_ids"])
                    or any(type(n) is not int or n not in turns for n in result["evidence_turns"])):
                raise ValueError("Return selected, reason and real tool_ids/evidence_turns in the required types")
            if result["selected"]:
                if not result["tool_ids"] or not result["evidence_turns"]:
                    raise ValueError("Selection needs a working tool and reported evidence")
                for tool in result["tool_ids"]:
                    if not any(n > built[tool] and any(i.get("id") == tool for i in
                               turns[n]["result_observation"].get("instruments", [])) for n in result["evidence_turns"]):
                        raise ValueError(f"No observed post-build evidence for {tool}")
            elif result["tool_ids"] or result["evidence_turns"]:
                raise ValueError("Rejected cases must use empty tool/evidence arrays")
        except (ValueError, KeyError, TypeError) as error:
            attempt.update(status="invalid", error=str(error)); checkpoint(attempt)
            if number == settings.judge_attempts:
                raise ValueError(f"Tool case review failed after {number} responses: {error}") from error
            messages = original + [{"role": "assistant", "content": raw},
                {"role": "user", "content": f"Repair only the output format and citations using the original record: {error}"}]
            continue
        attempt.update(status="valid", **result); checkpoint(attempt)
        return result


def run_tool_episode(job):
    """补充实验复用现有交互、报告、记录和评分函数，限制仅作用于本局。"""
    from functools import partial
    import time
    import uuid
    from agent import make_task, run_interaction, collect_report
    from engine import call_api, ResponsesConversation, PermanentAPIError, write_log
    from eval import DEFAULT_PARAMETERS
    from prompts import AGENT_BRIEF, ACTION_FORMAT, REPORT_PROMPT
    from run import run_and_evaluate
    from scenes import load_scene
    from tools import review_design
    from world import World, Recorder

    mode, settings, output = job["tools_mode"], job["settings"], Path(job["output"])
    class ExperimentWorld(World):
        def act(self, command):
            operation = command.split(maxsplit=1)[:1]
            if mode == "disabled" and operation and operation[0].upper() in {"BUILD", "PLACE", "ADJUST"}:
                raise ValueError("Construction commands are unavailable; use the listed basic actions.")
            return super().act(command)
    scene = load_scene(job["scene"])
    task = make_task(scene, job["tell"])
    prompt = AGENT_BRIEF.format(task=task, ACTION_FORMAT=ACTION_FORMAT)
    if mode == "disabled":
        prompt = prompt.split("\n## Optional construction", 1)[0].rstrip() + "\n\nConstruction commands are unavailable."
        prompt = prompt.replace("; multiline only for BUILD JSON", "")
    record = {"episode_id": uuid.uuid4().hex,
              "scene": scene.scene_spec["id"], "model": job["model"], "tell": job["tell"], "budget": job["budget"],
              "repeat": job["repeat"], "tools_mode": mode, "implementation_id": job["implementation_id"],
              "prompt": prompt, "prompt_policy": "neutral_T0_v1" if job["tell"] == "T0" else "prompted_v1",
              "truth": scene.ground_truth(), "rubric": scene.rubric(),
              "scoring_parameters": dict(job.get("scoring_parameters", DEFAULT_PARAMETERS)),
              "request_settings": settings.public(), "status": "running", "turns": [], "report": None}
    if job.get("tool_case"):
        record["tool_case"] = job["tool_case"]
    if job.get("ablation_source"):
        record["ablation_source"] = job["ablation_source"]
    recorder = None
    output.mkdir(parents=True, exist_ok=False)
    log = partial(write_log, directory=output, label=f"{mode}/{job['model']}", started=time.monotonic())
    try:
        world = ExperimentWorld(scene, review=partial(review_design, settings=settings))
        chat = (ResponsesConversation(job["model"], settings.compact_threshold, settings=settings, log=log)
                if settings.compact_threshold else partial(call_api, model=job["model"], settings=settings, log=log))
        if isinstance(chat, ResponsesConversation):
            record.update(api_policy=chat.policy, context_calls=chat.calls)
        recorder = Recorder(world, output, record, fps=job["fps"])
        messages = [{"role": "system", "content": prompt}]
        observation = run_interaction(chat, recorder, messages, log)
        record["final_prompt"] = REPORT_PROMPT
        recorder.checkpoint()
        record["report"] = collect_report(chat, task, messages, observation, record,
                                          checkpoint=recorder.checkpoint, log=log,
                                          max_attempts=settings.report_attempts)
        record["status"] = "complete"
    except BaseException as error:
        record.update(status="interrupted" if isinstance(error, (KeyboardInterrupt, InterruptedError)) else "failed",
                      error=str(error), error_type=type(error).__name__)
        log(f"ERROR {type(error).__name__}: {error}")
        if isinstance(error, PermanentAPIError):
            record["api_failure"] = {"phase": "report" if "final_prompt" in record else "exploration",
                                     "raw_response": error.raw_response, **error.details}
        if isinstance(error, (KeyboardInterrupt, InterruptedError, SystemExit)):
            raise
    finally:
        if recorder is not None:
            recorder.capture("final")
            recorder.checkpoint()
    if recorder is not None:
        record = read_json(output / "session.json")
    return run_and_evaluate({"source": output / "session.json", "record": record,
                             "evaluation_output": output / "eval.json", "settings": settings,
                             "execution_failed": record["status"] != "complete"})


def run_tools(args):
    """按原条件补跑无工具组；全量模式跳过成功筛选和器材贡献审核。"""
    from dataclasses import replace
    from engine import Settings, run_pool
    from run import save_results
    from scenes import load_scene
    from world import World, Recorder, write_json_atomic
    from types import SimpleNamespace
    from urllib.parse import quote

    settings = Settings.from_env()
    repeats, workers = (int(os.getenv(k, default)) for k, default in (("REPEATS", "1"), ("CONCURRENCY", "10")))
    if min(repeats, workers) < 1:
        raise ValueError("Repeats and concurrency must be positive")
    output = (args.output or args.source / "3.1-tools").resolve()
    source = (args.tool_source or args.source).resolve()
    dry = args.dry_run or os.getenv("DRY_RUN", "1") != "0"
    if not source.is_dir():
        if dry:
            print(f"工具案例预览：等待 {source} 的实验记录，随后筛选并补跑无工具组；输出 {output}")
            return 0
        raise FileNotFoundError(source)
    if output.exists():
        raise FileExistsError(f"Use a new tools experiment output: {output}")
    all_scenes = getattr(args, "run_tools_all", False)
    candidates, issues = tool_candidates(source, output, settings.judge_model, all_scenes=all_scenes)
    label = "全量器材消融（不按成功/建造筛选）" if all_scenes else "工具成功案例筛选"
    print(f"{label}：{len(candidates)}个场景，补跑{len(candidates) * repeats}局无工具组；来源 {source}", flush=True)
    if dry:
        for case in candidates:
            print(f"  {case['source']}；原模型 {case['record']['model']}，原预算 {case['record']['budget']}")
        return 0
    if os.getenv("ALLOW_PAID_API") != "1":
        raise ValueError("Paid execution needs DRY_RUN=0 ALLOW_PAID_API=1")
    if not settings.judge_model:
        raise ValueError("Tool case selection requires JUDGE_MODEL")
    output.mkdir(parents=True)
    selection = {"source": str(source), "selector_model": None if all_scenes else settings.judge_model,
                 "selector_prompt": None if all_scenes else TOOL_CASE_REVIEW,
                 "selection_policy": "all_scenes" if all_scenes else "successful_tool_cases",
                 "source_issues": issues, "candidates": []}
    jobs, chosen = [], []
    code_root = Path(__file__).parent
    implementation = digest({str(p.relative_to(code_root)): p.read_text() for p in code_root.rglob("*.py")})
    for case in candidates:
        s = case["record"]
        entry = {"source": case["source"], "episode_id": case["episode_id"], "attempts": []}
        selection["candidates"].append(entry)
        def checkpoint(attempt):
            entry["attempts"].append(attempt)
            write_json_atomic(output / "tool_selection.json", selection)
        try:
            verdict = ({"selected": True, "tool_ids": [], "evidence_turns": [],
                        "reason": "Full-suite ablation; no success or apparatus-use selection."}
                       if all_scenes else review_tool_case(case, settings, checkpoint))
            entry.update(verdict)
            if not verdict["selected"]:
                continue
            World(load_scene(s["scene_spec"]))
            saved = s.get("request_settings", {})
            public = {k: v for k, v in saved.items() if k in Settings.__dataclass_fields__ and k not in {"api", "judge_model"}}
            # 复用原模型参数；连接超时和重试策略沿用本次配置。
            policy = replace(settings, **public, api={**settings.api, **{k: v for k, v in saved.get("api", {}).items()
                                                                        if k not in {"base", "key", "timeout", "max_attempts"}}})
            if policy.compact_threshold and s["model"] != "gpt-6-astra":
                raise ValueError("Original compaction policy is unsupported for this model")
            meta = {"id": digest([case["source"], case["episode_id"]]), "source": case["source"],
                    "source_hash": digest(s), "episode_id": case["episode_id"], "scene": s["scene"],
                    "model": s["model"], "tell": s["tell"], "budget": s["budget"], "score": case["score"],
                    "implementation_id": s.get("implementation_id"), "selection": verdict}
            chosen.append(meta)
            for repeat in range(1, repeats + 1):
                jobs.append(dict(scene=s["scene_spec"], model=s["model"], tell=s["tell"], budget=s["budget"],
                    repeat=repeat, tools_mode="disabled", settings=policy,
                    **({"ablation_source": meta} if all_scenes else {"tool_case": meta}),
                    scoring_parameters=case["parameters"], implementation_id=implementation,
                    fps=Recorder.validate_fps(s.get("record_fps", 30)),
                    output=output / "disabled" / (quote(s["scene"], safe="-_.") if all_scenes
                                                else f"{quote(s['scene'], safe='-_.')}@{meta['id']}") /
                           quote(s["model"], safe="-_.") / f"r{repeat}" / s["tell"]))
        except Exception as error:
            entry.update(status="failed", error=str(error), raw_response=getattr(error, "raw_response", None),
                         api_failure=getattr(error, "details", None))
            write_json_atomic(output / "run_errors.json", [{"stage": "tool_selection", "source": case["source"],
                              "error": str(error)}], overwrite=False)
            print(f"工具案例筛选失败：{case['source']} | {error}；详见 {output / 'run_errors.json'}", flush=True)
            return 1
        finally:
            write_json_atomic(output / "tool_selection.json", selection)
    write_json_atomic(output / "tool_selection.json", selection)
    write_json_atomic(output / "plan.json", {"command": "tools_ablation" if all_scenes else "tool_cases",
        "expected_scenes": len(chosen),
        "expected_episodes": len(jobs), "source": str(source), "tool_cases": chosen, "repeats": repeats,
        "tools_modes": ["disabled"], "implementation_id": implementation}, overwrite=False)
    print(f"补跑{len(jobs)}局无工具对照；原记录直接复用", flush=True)
    results = run_pool(run_tool_episode, jobs, workers=workers) if jobs else []
    status = save_results(SimpleNamespace(command="models", dry=False, prepare_only=False, paid=True, output=output), results)
    report_root = args.source.resolve() if output.is_relative_to(args.source.resolve()) else output
    report_output = report_root / "3.0-analysis"
    save_outputs(report_output, build_analysis(report_root, report_output, {}, []))
    print(f"工具案例分析：{report_output / 'report.md'}", flush=True)
    return status


def read_json(path):
    def invalid_number(value):
        raise ValueError(f"Invalid JSON number: {value}")
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=invalid_number)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]


def fraction(numerator, denominator):
    return numerator / denominator if denominator else None


def average(values):
    return mean(values) if values else None


def read_batch(root, output, annotations):
    """只以单局 session/eval 为统计单位，计划和错误清单用于检查遗漏。"""
    plans, issues, rows, cases, seen = {}, [], [], [], {}
    paths = lambda name: sorted(p for p in root.rglob(name) if not p.is_relative_to(output))
    for path in paths("plan.json"):
        try:
            plan = read_json(path)
            if not isinstance(plan, dict):
                raise ValueError("Expected a plan object")
            plans[path.parent] = plan
        except (OSError, ValueError) as error:
            issues.append({"source": str(path), "kind": "invalid_plan", "error": str(error)})
    for path in paths("run_errors.json"):
        try:
            for error in read_json(path):
                issues.append({"source": str(path), "kind": "run_error", "detail": error})
        except (OSError, ValueError, TypeError) as error:
            issues.append({"source": str(path), "kind": "invalid_error_manifest", "error": str(error)})
    for path in paths("session.json"):
        try:
            record = read_json(path)
            if not isinstance(record, dict) or not isinstance(record.get("turns"), list) or "status" not in record:
                raise ValueError("Expected an episode with status and turns")
        except (OSError, ValueError) as error:
            issues.append({"source": str(path), "kind": "invalid_session", "error": str(error)})
            continue
        evaluation = {}
        try:
            if path.with_name("eval.json").exists():
                evaluation = read_json(path.with_name("eval.json"))
                if not isinstance(evaluation, dict):
                    raise ValueError("Expected a single-episode evaluation object")
        except (OSError, ValueError) as error:
            issues.append({"source": str(path), "kind": "invalid_evaluation", "error": str(error)})
            evaluation = {}
        identity = record.get("episode_id") or str(path)
        signature = digest([record, evaluation])
        if identity in seen:
            old_signature, old_path = seen[identity]
            if signature != old_signature:
                raise ValueError(f"Conflicting versions of {identity}: {old_path} and {path}; select one version")
            issues.append({"source": str(path), "kind": "duplicate_skipped", "original": str(old_path)})
            continue
        seen[identity] = signature, path
        plan_root = next((p for p in path.parents if p in plans), None)
        group = str(plan_root.relative_to(root)) if plan_root and plan_root != root else root.name
        if not plan_root and len(path.relative_to(root).parts) > 4:
            group = path.relative_to(root).parts[0]
        turns = record["turns"]
        ids = [t.get("turn") for t in turns]
        if any(type(n) is not int or n < 1 for n in ids) or len(set(ids)) != len(ids):
            raise ValueError(f"Invalid turn IDs: {path}")
        annotation = annotations.get(identity, {})
        for name in PATTERNS:
            values = annotation.get(name + "_turns", [])
            if not isinstance(values, list) or any(type(n) is not int or n not in ids for n in values):
                raise ValueError(f"Invalid annotation {name}_turns for {identity}")
        discovery = annotation.get("first_discovery_turn")
        if discovery is not None and (type(discovery) is not int or discovery not in ids):
            raise ValueError(f"Invalid first_discovery_turn for {identity}")
        spec = record.get("scene_spec") or {}
        control = (spec.get("oracle") or {}).get("control")
        judgement = evaluation.get("judgement") or {}
        scorecard = evaluation.get("scorecard") or {}
        if not isinstance(judgement, dict) or not isinstance(scorecard, dict):
            issues.append({"source": str(path), "kind": "invalid_evaluation_fields"})
            judgement, scorecard = {}, {}
        score = scorecard.get("total_score")
        valid = (record["status"] == evaluation.get("status") == "complete"
                 and type(control) is bool and type(judgement.get("correct")) is bool
                 and (judgement.get("supported") is None if control else type(judgement.get("supported")) is bool)
                 and type(score) in (float, int) and math.isfinite(score))
        if evaluation.get("episode_id") and record.get("episode_id") != evaluation["episode_id"]:
            valid = False
        if evaluation.get("input_sha256"):
            inputs = {k: record.get(k) for k in ("status", "scene_spec", "report", "turns",
                                               "resource_usage", "scoring_parameters")}
            actual = hashlib.sha256(json.dumps(inputs, sort_keys=True, ensure_ascii=False,
                                               allow_nan=False).encode()).hexdigest()
            valid = valid and actual == evaluation["input_sha256"]
        if evaluation.get("status") == "complete" and not valid:
            issues.append({"source": str(path), "kind": "unusable_complete_evaluation",
                           "error": "Incomplete experiment, invalid score/labels, or mismatched episode ID/input hash"})
        failures = [t for t in turns if t.get("outcome") not in ("ok", "pending", None)]
        operations = Counter((t.get("act") or "").split(maxsplit=1)[0].upper()
                             if (t.get("act") or "").strip() else "EMPTY" for t in turns)
        finished = (record.get("termination_reason") in {"model_done", "budget_exhausted"}
                    and all(t.get("outcome") not in ("pending", None) for t in turns))
        budget = record.get("budget")
        prompt = record.get("prompt", "")
        disclosed = record.get("tell") == "T0" and bool(re.search(
            r"Discovery score|base points|independent hidden physical laws|Use this clue:|Identify and verify",
            prompt, re.I))
        protocol = "T0_disclosed_goal" if disclosed else record.get("prompt_policy", "unverified")
        settings = record.get("request_settings") or {}
        task, _, interface = prompt.partition("\n\n## ")
        execution_profile = digest([record.get("scoring_parameters"), settings, record.get("implementation_id"),
                                    record.get("runtime")])
        profile = digest([interface or prompt, execution_profile])
        repeat = record.get("repeat")
        if repeat is None and re.fullmatch(r"r\d+", path.parent.parent.name):
            repeat = int(path.parent.parent.name[1:])
        tools = (record.get("resource_usage") or {}).get("tools")
        if type(tools) is not int or tools < 0:
            tools = None
        row = dict(source=str(path), episode_id=identity, group=group, model=record.get("model"),
                   judge_model=evaluation.get("judge_model"), tool_case_id=(record.get("tool_case") or {}).get("id"),
                   scene=record.get("scene"), tell=record.get("tell"), budget=budget, repeat=repeat,
                   protocol=protocol, tools_mode=record.get("tools_mode", "unspecified"), profile=profile,
                   execution_profile=execution_profile, task_hash=digest(task),
                   implementation_id=record.get("implementation_id"),
                   scene_hash=digest(spec), judge_profile=digest([evaluation.get("judge_model"),
                       evaluation.get("judge_prompt"), evaluation.get("parameters")]) if valid else None,
                   status=record["status"], eval_status=evaluation.get("status", "missing"), control=control,
                   valid_eval=valid, score=score if valid else None,
                   correct=judgement.get("correct") if valid else None,
                   supported=judgement.get("supported") if valid else None,
                   success=bool(judgement["correct"] and (control or judgement["supported"])) if valid else None,
                   turns_used=len(turns), exploration_finished=finished,
                   early_done=finished and record.get("termination_reason") == "model_done"
                       and type(budget) is int and len(turns) < budget,
                   tools_built=tools, build_turns=operations["BUILD"], action_failure_turns=len(failures),
                   judged_action_errors=len(judgement.get("action_errors", []))
                       if isinstance(judgement.get("action_errors", []), list) else None,
                   build_failure_turns=sum((t.get("act") or "").upper().startswith("BUILD ") for t in failures),
                   report_attempts=len(record.get("report_attempts", [])),
                   first_discovery_turn=discovery,
                   turns_after_discovery=sum(n > discovery for n in ids) if discovery is not None and finished else None,
                   error=record.get("error") or evaluation.get("error"))
        rows.append(row)
        candidates = {name: [t["turn"] for t in turns if re.search(pattern, t.get("note") or "", re.I)]
                      for name, pattern in PATTERNS.items()}
        repeated = defaultdict(list)
        for turn in turns:
            act = (turn.get("act") or "").strip()
            if turn.get("outcome") == "ok" and act and act.split()[0].upper() not in {"WAIT", "DONE", "BUILD", "MARK"}:
                repeated[act].append(turn["turn"])
        compact_turns = [{k: t.get(k) for k in ("turn", "note", "act", "outcome")} for t in turns]
        report = record.get("report")
        try:
            report = json.loads(report) if isinstance(report, str) else report
        except ValueError:
            pass
        cases.append({"source": str(path), "episode_id": identity, "group": group, "scene": row["scene"],
                      "model": row["model"], "tell": row["tell"], "budget": budget, "protocol": protocol, "judgement": judgement,
                      "candidates": candidates, "annotations": annotation, "turns": compact_turns,
                      "repeated_commands": {k: v for k, v in repeated.items() if len(v) > 1}, "report": report})
    for key in annotations.keys() - seen.keys():
        issues.append({"kind": "unused_annotation", "episode_id": key})
    plan_rows = []
    for parent, plan in plans.items():
        selected = [r for r in rows if Path(r["source"]).is_relative_to(parent)]
        expected = plan.get("expected_episodes")
        plan_rows.append({"source": str(parent / "plan.json"), "expected_episodes": expected,
                          "recorded_episodes": len(selected),
                          "tool_cases": [] if plan.get("command") == "tools_ablation" else plan.get("tool_cases", []),
                          "repeats": plan.get("repeats")})
        if type(expected) is int and expected != len(selected):
            issues.append({"source": str(parent), "kind": "plan_count_mismatch",
                           "expected": expected, "recorded": len(selected)})
    return rows, cases, issues, plan_rows


def statistics(rows):
    valid = [r for r in rows if r["valid_eval"]]
    altered = [r for r in valid if r["control"] is False]
    controls = [r for r in valid if r["control"] is True]
    finished = [r for r in rows if r["exploration_finished"]]
    totals = sum(r["turns_used"] for r in rows)
    return dict(recorded=len(rows), graded=len(valid), run_failed=sum(r["status"] == "failed" for r in rows),
                running=sum(r["status"] == "running" for r in rows),
                eval_failed=sum(r["eval_status"] == "failed" for r in rows),
                mean_eval=average([r["score"] for r in valid]),
                correct=sum(r["correct"] for r in valid), acc=fraction(sum(r["correct"] for r in valid), len(valid)),
                success=sum(r["success"] for r in valid), success_rate=fraction(sum(r["success"] for r in valid), len(valid)),
                altered_graded=len(altered), altered_correct=sum(r["correct"] for r in altered),
                altered_mean_eval=average([r["score"] for r in altered]),
                altered_acc=fraction(sum(r["correct"] for r in altered), len(altered)),
                altered_supported=sum(r["supported"] for r in altered),
                altered_supported_rate=fraction(sum(r["supported"] for r in altered), len(altered)),
                altered_success=sum(r["success"] for r in altered),
                altered_discovery_rate=fraction(sum(r["success"] for r in altered), len(altered)),
                control_graded=len(controls), control_rejections=sum(not r["correct"] for r in controls),
                control_mean_eval=average([r["score"] for r in controls]),
                control_rejection_rate=fraction(sum(not r["correct"] for r in controls), len(controls)),
                finished_explorations=len(finished), mean_turns=average([r["turns_used"] for r in finished]),
                median_turns=median([r["turns_used"] for r in finished]) if finished else None,
                early_done=sum(r["early_done"] for r in finished),
                early_done_rate=fraction(sum(r["early_done"] for r in finished), len(finished)),
                build_turn_fraction=fraction(sum(r["build_turns"] for r in rows), totals),
                failure_turn_fraction=fraction(sum(r["action_failure_turns"] for r in rows), totals),
                tool_using_episodes=sum(r["tools_built"] is not None and r["tools_built"] > 0 for r in rows),
                annotated_discoveries=sum(r["first_discovery_turn"] is not None for r in rows),
                mean_turns_after_discovery=average([r["turns_after_discovery"] for r in rows
                                                  if r["turns_after_discovery"] is not None]))


def compare_conditions(groups):
    """匹配同一场景、重复和评价配置；工具实际使用情况不作为干预条件。"""
    results = []
    for (ka, a), (kb, b) in combinations(groups.items(), 2):
        if any(r.get("tool_case_id") for r in a + b):
            continue  # 按成功筛选的历史案例单独展示，不混入总体配对增益。
        ca, cb = dict(zip(CONDITION, ka)), dict(zip(CONDITION, kb))
        if ca["model"] != cb["model"]:
            continue
        changed = [k for k in ("tell", "budget", "tools_mode") if ca[k] != cb[k]]
        if len(changed) != 1:
            continue
        axis = changed[0]
        if axis == "tools_mode" and {ca[axis], cb[axis]} != {"enabled", "disabled"}:
            continue
        if axis != "tools_mode" and ca["profile"] != cb["profile"]:
            continue
        def index(items):
            indexed = defaultdict(list)
            for row in items:
                indexed[(row["scene_hash"], row["repeat"])].append(row)
            return indexed
        ia, ib = index(a), index(b)
        common = ia.keys() & ib.keys()
        pairs = [(ia[k][0], ib[k][0]) for k in common if len(ia[k]) == len(ib[k]) == 1
                 and ia[k][0]["valid_eval"] and ib[k][0]["valid_eval"]
                 and ia[k][0]["execution_profile"] == ib[k][0]["execution_profile"]
                 and (axis == "tell" or ia[k][0]["task_hash"] == ib[k][0]["task_hash"])
                 and ia[k][0]["judge_profile"] == ib[k][0]["judge_profile"]]
        if not pairs:
            continue
        results.append({"axis": axis, "a": ca, "b": cb, "matched": len(pairs),
                        "unmatched_or_ungraded_a": len(a) - len(pairs), "unmatched_or_ungraded_b": len(b) - len(pairs),
                        "a_metrics": statistics([x for x, _ in pairs]), "b_metrics": statistics([y for _, y in pairs]),
                        "success_gains": sum(not x["success"] and y["success"] for x, y in pairs),
                        "success_losses": sum(x["success"] and not y["success"] for x, y in pairs),
                        "sources": [[x["source"], y["source"]] for x, y in pairs]})
    return results


def behavior_pairs(rows, cases):
    indexed, result = defaultdict(dict), []
    for row, case in zip(rows, cases):
        pair = case["annotations"].get("pair", {})
        if not isinstance(pair, dict):
            raise ValueError(f"Invalid pair annotation: {row['episode_id']}")
        if not pair or pair.get("matched") is not True:
            continue
        if (not pair.get("id") or not pair.get("target") or pair.get("condition") not in {"B", "A+B"}
                or type(pair.get("target_found")) is not bool):
            raise ValueError(f"Invalid controlled-pair annotation: {row['episode_id']}")
        evidence = pair.get("target_turns", [])
        actual = {t["turn"] for t in case["turns"]}
        if (not isinstance(evidence, list) or pair["target_found"] and not evidence
                or any(type(n) is not int or n not in actual for n in evidence)):
            raise ValueError(f"Invalid target evidence in pair: {row['episode_id']}")
        if not row["valid_eval"]:
            continue
        key = (pair["id"], pair["target"], row["model"], row["tell"], row["budget"], row["repeat"],
               row["profile"], row["judge_profile"])
        if pair["condition"] in indexed[key]:
            raise ValueError(f"Ambiguous controlled pair: {pair['id']}")
        indexed[key][pair["condition"]] = (row, pair["target_found"])
    for key, sides in indexed.items():
        if set(sides) == {"B", "A+B"}:
            result.append({"pair_id": key[0], "target": key[1], "model": key[2], "tell": key[3],
                           "budget": key[4], "repeat": key[5], "B_source": sides["B"][0]["source"],
                           "AB_source": sides["A+B"][0]["source"], "B_found": sides["B"][1],
                           "AB_found": sides["A+B"][1], "B_early_done": sides["B"][0]["early_done"],
                           "AB_early_done": sides["A+B"][0]["early_done"]})
    return result


def build_analysis(root, output, annotations, expected_groups):
    rows, cases, issues, plans = read_batch(root, output, annotations)
    for name in expected_groups:
        if not (root / name).is_dir():
            issues.append({"source": str(root / name), "kind": "missing_experiment_group"})
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[k] for k in CONDITION)].append(row)
    summaries = [{**dict(zip(CONDITION, key)), **statistics(items)} for key, items in groups.items()]
    tools = [{**dict(zip(CONDITION, key)), "actually_built_tools": used, **statistics(selected)}
             for key, items in groups.items() for used in (False, True)
             if (selected := [r for r in items if r["tools_built"] is not None and (r["tools_built"] > 0) == used])]
    failures = []
    for row in rows:
        reasons = []
        if row["status"] != "complete":
            reasons.append("experiment_" + str(row["status"]))
        if not row["valid_eval"]:
            reasons.append("no_valid_evaluation")
        if row["action_failure_turns"]:
            reasons.append("action_failures")
        if row["judged_action_errors"]:
            reasons.append("judged_action_errors")
        if row["correct"] is False:
            reasons.append("incorrect")
        if row["supported"] is False:
            reasons.append("unsupported")
        if reasons:
            failures.append({**row, "reasons": reasons})
    tool_cases = [{**case, "planned_without": plan["repeats"],
                   "without": statistics([r for r in rows if r["tool_case_id"] == case["id"]
                                           and Path(r["source"]).is_relative_to(Path(plan["source"]).parent)])}
                  for plan in plans for case in plan["tool_cases"]]
    return {"format": FORMAT, "source": str(root), "generated_at": datetime.now(timezone.utc).isoformat(),
            "plans": plans, "summary": summaries, "episodes": rows, "case_studies": cases,
            "failures": failures, "issues": issues, "comparisons": compare_conditions(groups),
            "tool_usage_descriptive": tools, "selected_tool_cases": tool_cases,
            "controlled_B_pairs": behavior_pairs(rows, cases)}


def display(value, percent=False):
    if value is None:
        return "—"
    if percent:
        return f"{value * 100:.2f}%"
    return f"{value:.2f}" if type(value) is float else str(value).replace("|", r"\|").replace("\n", " ")


def render_report(result):
    lines = ["# LongChang 批次分析", "", f"来源：{result['source']}", f"生成时间：{result['generated_at']}", "",
             "统计直接读取单局存档；没有重新请求模型、重新评分或修改原记录。", "",
             "## 1. 结果与轮数", "",
             "平均分和 ACC 只使用已完成且评分有效的记录；未评分不按零分处理。ACC 只看 correct；达标率还要求异常题 supported=true。",
             "平均轮数使用已结束的探索，包含报告失败但探索已结束的局；API重试和报告补正不计入探索轮数。", "",
             "| 实验组 | 模型 | 提示/预算 | 记录/有效评分 | eval均分 | ACC | 达标率 | 实际轮数均值/中位数 | 提前结束 |",
             "|---|---|---|---:|---:|---:|---:|---:|---:|"]
    for s in result["summary"]:
        lines.append(f"| {display(s['group'])} | {display(s['model'])} | {s['tell']}/{s['budget']} | "
                     f"{s['recorded']}/{s['graded']} | {display(s['mean_eval'])} | {display(s['acc'], True)} | "
                     f"{display(s['success_rate'], True)} | {display(s['mean_turns'])}/{display(s['median_turns'])} | "
                     f"{s['early_done']}/{s['finished_explorations']} |")
    lines += ["", "异常题正确率、证据支持数、达标率及正常题裁判拒绝数见 summary.csv。",
              "正常题 correct=false 暂记为裁判拒绝，需核查理由后才能等同于异常误报。不同 profile 不合并；无版本标记的旧协议保留为 unverified。"]
    if any(r["protocol"] == "T0_disclosed_goal" for r in result["episodes"]):
        lines += ["", "**本批存在向T0透露发现目标、奖励或线索的旧提示，不能将其解释为无任务提示的自发探索。**"]
    lines += ["", "## 2. 同条件配对比较", "",
              "按已记录的场景定义、模型、重复、请求参数及裁判配置匹配；两边均须有有效评分，配对样本不会自动代表全部计划任务。",
              "工具开关允许可用动作菜单不同；需核对提示的其他部分一致。缺少 implementation_id 时不能验证运行代码版本一致。"]
    for c in result["comparisons"]:
        a, b = c["a_metrics"], c["b_metrics"]
        lines += ["", f"- {c['axis']}：{c['a']['group']} ({c['a']['tell']}/{c['a']['budget']}/{c['a']['tools_mode']}) → "
                  f"{c['b']['group']} ({c['b']['tell']}/{c['b']['budget']}/{c['b']['tools_mode']})，匹配{c['matched']}局；"
                  f"均分 {display(a['mean_eval'])} → {display(b['mean_eval'])}，"
                  f"ACC {display(a['acc'], True)} → {display(b['acc'], True)}，"
                  f"达标 {a['success']} → {b['success']}，改善{c['success_gains']}、退步{c['success_losses']}。"]
    if not result["comparisons"]:
        lines += ["", "没有可直接配对的完整对照数据。"]
    lines += ["", "## 3. 工具构造", "",
              "实际构造/未构造器材的分组是描述性统计，受模型选择和场景难度影响，不能据此证明工具提高成功率。",
              "只有显式 tools_mode=enabled/disabled 且满足上述匹配条件的数据才作为工具开关对照。", "",
              "| 实验组 | 提示/预算 | 实际构造器材 | 记录/有效评分 | eval均分 | ACC |",
              "|---|---|---|---:|---:|---:|"]
    for s in result["tool_usage_descriptive"]:
        lines.append(f"| {display(s['group'])} | {s['tell']}/{s['budget']} | {'是' if s['actually_built_tools'] else '否'} | "
                     f"{s['recorded']}/{s['graded']} | {display(s['mean_eval'])} | {display(s['acc'], True)} |")
    if result.get("selected_tool_cases"):
        lines += ["", "### 已筛选成功案例的无工具复跑", "",
                  "原有工具记录按成功和证据贡献筛选，此处只展示案例，不估计总体平均工具增益。",
                  "新实验使用原场景、模型、预算和请求参数；历史代码与裁判提示的版本仍需核对。", "",
                  "| 场景 | 原模型/预算 | 原有工具分数 | 新无工具记录/有效/计划 | 新均分 | 新达标 |",
                  "|---|---|---:|---:|---:|---:|"]
        for case in result["selected_tool_cases"]:
            s = case["without"]
            lines.append(f"| [{case['scene']}]({case['source']}) | {case['model']}/{case['budget']} | "
                         f"{display(case['score'])} | {s['recorded']}/{s['graded']}/{case['planned_without']} | "
                         f"{display(s['mean_eval'])} | {s['success']} |")
        for case in result["selected_tool_cases"]:
            lines.append(f"\n{case['scene']} 的器材证据：{case['selection']['tool_ids']}，轮次 {case['selection']['evidence_turns']}；"
                         f"{display(case['selection']['reason'])}\n")
    elif not any(c["axis"] == "tools_mode" for c in result["comparisons"]):
        lines += ["", "**工具因果效果：数据不足，缺少匹配的允许/禁用BUILD对照。**"]
    lines += ["", "## 4. 自发提问、机制辨识与复验", "",
              "以下是探索 NOTE 中的关键词候选，不是已确认行为；提出要重复实验不等于完成复验，相同命令也不保证实验条件相同。",
              "case_studies 保留全局的逐轮 NOTE/ACT/反馈、报告及原始路径，便于核查；只有外部标注才用于首次发现时间。"]
    for kind, label in [("question", "自发提问"), ("discrimination", "机制辨识"),
                        ("replication", "复验"), ("revision", "反例与修正")]:
        candidates = [c for c in result["case_studies"]
                      if (c["candidates"][kind] or c["annotations"].get(kind + "_turns"))
                      and (kind != "question" or str(c["protocol"]).startswith("neutral_T0_"))]
        lines += ["", f"### {label}候选", "", f"有线索的记录：{len(candidates)}局；详见 analysis.json 的 case_studies。"]
        for case in candidates[:3]:
            turns = case["annotations"].get(kind + "_turns", case["candidates"][kind])
            if not turns:
                continue
            turn = next(t for t in case["turns"] if t["turn"] == turns[0])
            note = display(turn.get("note") or "")[:300].replace("<", "&lt;").replace(">", "&gt;")
            lines += [f"- [{case['scene']}/{case['tell']}/{case['budget']}]({case['source']})，turn {turns[0]}：{note}"]
    lines += ["", "## 5. 发现后探索", ""]
    marked = [r for r in result["episodes"] if r["first_discovery_turn"] is not None]
    lines.append(f"有首次发现标注的记录：{len(marked)}局；不以最终报告的最早引用轮次替代首次发现时间。")
    for r in marked:
        lines.append(f"- {r['scene']}/{r['model']}/{r['tell']}：首次发现turn {r['first_discovery_turn']}，"
                     f"之后探索{display(r['turns_after_discovery'])}轮，提前结束={r['early_done']}。")
    pairs = result["controlled_B_pairs"]
    if pairs:
        lines += [f"经标注确认可比的B/A+B配对：{len(pairs)}对。",
                  "这是所提供标注下的结果，可观测性一致仍须由场景检查与轨迹核查支持。"]
        for p in pairs:
            lines.append(f"- {p['pair_id']}/{p['model']}/{p['tell']}/{p['budget']}/r{p['repeat']}："
                         f"目标 {p['target']} 发现={p['B_found']} → {p['AB_found']}。")
    else:
        lines += ["**尚无已核对的B/A+B配对和目标B发现标注，不能判断发现A是否妨碍继续发现B。**"]
    lines += ["", "## 6. 失败与待核查项", "",
              f"有问题或尚未完成的记录：{len(result['failures'])}局；完整清单在 analysis.json 的 failures。",
              "运行失败、无有效评分、答错、证据不足、动作失败分别保留；答对但有失败动作的局也会收录。"]
    for row in result["failures"]:
        lines.append(f"- [{row['scene']}/{row['tell']}/{row['budget']}]({row['source']})："
                     f"{', '.join(row['reasons'])}；{display(row['error'] or '')[:350]}")
    lines += ["", f"计划、文件或来源问题：{len(result['issues'])}项，详见 analysis.json 的 issues。", ""]
    for issue in result["issues"]:
        if issue["kind"] != "run_error":
            lines.append("- " + display(json.dumps(issue, ensure_ascii=False)))
    return "\n".join(lines) + "\n"


def save_outputs(output, result):
    if output.exists() and any(output.iterdir()):
        marker = output / "analysis.json"
        if not marker.is_file() or read_json(marker).get("format") != FORMAT or read_json(marker).get("source") != result["source"]:
            raise FileExistsError(f"Choose an empty analysis directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    def write(name, content):
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=output, delete=False) as stream:
            stream.write(content)
            temporary = Path(stream.name)
        os.replace(temporary, output / name)
    import io
    for name, rows in (("summary.csv", result["summary"]), ("episodes.csv", result["episodes"])):
        stream = io.StringIO()
        fields = list(rows[0]) if rows else ["recorded", "graded", "mean_eval", "acc"]
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
        write(name, stream.getvalue())
    write("report.md", render_report(result))
    write("analysis.json", json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("source", type=Path, help="一个实验批次目录")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--annotations", type=Path, help="已核对行为的轮次标注 JSON")
    parser.add_argument("--expect-groups", nargs="*", default=[])
    parser.add_argument("--dry-run", action="store_true", help="仅显示实验结束后的分析安排")
    parser.add_argument("--run-tools", action="store_true", help="筛选已有工具成功案例并仅补跑无工具组；受DRY_RUN保护")
    parser.add_argument("--run-tools-all", action="store_true", help="按MODELS/SCENES/BUDGET补跑全部基线场景的无工具组，不按成功或建造筛选")
    parser.add_argument("--tool-source", type=Path, help="搜索已有成功案例的目录，默认同source")
    args = parser.parse_args(argv)
    if args.run_tools and args.run_tools_all:
        parser.error("Choose --run-tools or --run-tools-all")
    if args.tool_source and not (args.run_tools or args.run_tools_all):
        parser.error("--tool-source requires --run-tools or --run-tools-all")
    root = args.source.resolve()
    output = (args.output or root / "3.0-analysis").resolve()
    try:
        if args.run_tools or args.run_tools_all:
            return run_tools(args)
        if output == root or root.is_relative_to(output):
            raise ValueError("Analysis output must be a separate directory, not the source or its parent")
        if args.dry_run:
            print(f"分析预览：实验结束后读取 {root}，保存到 {output}；不调用API。")
            return 0
        if not root.is_dir() and not args.expect_groups:
            raise FileNotFoundError(root)
        annotations = read_json(args.annotations) if args.annotations else {}
        if not isinstance(annotations, dict) or any(not isinstance(v, dict) for v in annotations.values()):
            raise ValueError("Annotations must map episode IDs to objects")
        result = build_analysis(root, output, annotations, args.expect_groups)
        save_outputs(output, result)
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f"分析失败：{error}\n")
    print(f"分析完成：{len(result['episodes'])}局，{sum(r['valid_eval'] for r in result['episodes'])}局有效评分；"
          f"输出 {output / 'report.md'}；API调用0次。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
