"""读取配置 → 准备场景 → 执行实验 → 评分 → 保存结果。"""

import argparse
from collections import Counter
from datetime import datetime
from itertools import product
import os
from pathlib import Path
import sys
import time
from functools import partial
import uuid
from urllib.parse import quote

from agent import run_episode
from engine import decode_json, run_pool, write_log, Settings
from eval import grade, normalize_report, trace_report
from scenes import generate_scene, read_json, read_sessions, save_json
from references import prepare_references
from world import Recorder, load_replay, write_json_atomic

ROOT = Path(__file__).resolve().parents[1]


def load_config(argv=None):
    """1. 读取命令行和环境变量，校验本次任务的配置。"""
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("models", "budget", "generate", "composition", "case", "failures", "list"):
        sub = commands.add_parser(name, allow_abbrev=False)
        if name == "case":
            sub.add_argument("mode", choices=("analyze", "eval"), nargs="?", default="analyze")
        if name not in {"composition", "list"}:
            sub.add_argument("inputs", nargs="*")
        if name in {"generate", "composition"}:
            sub.add_argument("--reference-session", action="append", dest="reference_sessions", default=[],
                             help="参考 session.json 或单局目录；可重复，不传则不引用")
        if name == "generate":
            sub.add_argument("--reference", action="append", default=[])
            sub.add_argument("--mutate-source", default="A1")
            sub.add_argument("--compose-source", action="append")
            for operation in ("new", "mutate", "compose"):
                sub.add_argument(f"--{operation}-prompt", default="")
        if name == "composition":
            sub.add_argument("--source", action="append")
            sub.add_argument("--parent", default=os.getenv("PARENT"))
            sub.add_argument("--prompt", default="")
        if name == "list":
            sub.add_argument("--benchmark", default=str(ROOT / "scenes/base.json"))
            sub.add_argument("--ids-only", action="store_true")
    config = parser.parse_args(argv)
    config.settings = Settings.from_env()
    config.selection = os.getenv("SCENES", "").replace(",", " ").split()
    config.allow_paid = os.getenv("ALLOW_PAID_API", "0") == "1"
    config.workers, config.prepare_only, config.paid = 1, False, False
    if config.command == "list":
        config.dry = True
        return config

    folder = {"models": "01", "generate": "02a", "composition": "02b",
              "budget": "03", "case": "04", "failures": "05"}[config.command]
    if config.command == "models" and config.inputs and config.inputs[0] in {"run", "analyze"}:
        if config.inputs.pop(0) == "analyze":
            config.command, config.mode = "case", "analyze"
    if config.command in {"case", "failures"} and not config.inputs:
        parser.print_help()
        raise SystemExit(0)
    dry = os.getenv("DRY_RUN", "1")
    if dry not in {"0", "1"}:
        raise ValueError("DRY_RUN must be 0 or 1")
    config.dry = dry == "1"
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
    config.output = Path(os.getenv("OUT_ROOT") or ROOT / "runs" / f"{folder}-{stamp}").resolve()
    if config.output.exists():
        raise FileExistsError(f"Use a new OUT_ROOT: {config.output}")

    if config.command in {"case", "failures"}:
        config.paid = config.command == "case" and config.mode == "eval"
        if not config.paid:
            return config
    else:
        config.models = os.getenv("MODELS", "deepseek-flash").replace(",", " ").split()
        config.tells = os.getenv("TELLS", "T1").replace(",", " ").split()
        budgets = os.getenv("BUDGETS", "5 20") if config.command == "budget" else os.getenv("BUDGET", "20")
        budgets = budgets.replace(",", " ").split()
        if not config.models or not config.tells or set(config.tells) - {"T0", "T1", "T2"} or not budgets:
            raise ValueError("Models/tells/budgets cannot be empty; TELLS accepts T0,T1,T2")
        if any(not value.isdigit() or int(value) < 1 for value in budgets):
            raise ValueError("Budgets must be positive integers")
        config.budgets = list(map(int, budgets))
        if any(len(set(values)) != len(values) for values in (config.models, config.tells, config.budgets)):
            raise ValueError("Models/tells/budgets cannot contain duplicates")
        config.fps = Recorder.validate_fps(os.getenv("RECORD_FPS", "30"))
        config.paid = True
        if config.settings.compact_threshold and any(m != "gpt-6-astra" for m in config.models):
            raise ValueError("COMPACT_THRESHOLD 目前仅支持 gpt-6-astra")
    numbers = [("workers", "CONCURRENCY", "2")]
    if config.command != "case":
        numbers.append(("repeats", "REPEATS", "1"))
    for field, variable, default in numbers:
        value = os.getenv(variable, default)
        if not value.isdigit() or int(value) < 1:
            raise ValueError(f"{variable} must be a positive integer")
        setattr(config, field, int(value))
    if config.command in {"generate", "composition"}:
        mode = os.getenv("MODE", "all")
        if mode not in {"all", "prepare"}:
            raise ValueError("MODE must be all or prepare")
        config.prepare_only = mode == "prepare"
        config.paid = not (config.command == "composition" and config.parent and config.prepare_only)
    if config.command == "generate":
        counts = [os.getenv(name, "1") for name in ("NEW_COUNT", "MUTATE_COUNT", "COMPOSE_COUNT")]
        if any(not value.isdigit() for value in counts) or not sum(map(int, counts)):
            raise ValueError("Generation counts must be nonnegative and at least one must be positive")
        config.counts = list(map(int, counts))
    return config


def prepare_scenes(config):
    """2. 加载或生成场景、完成预检并安排实验；分析模式读取已有记录。"""
    output = getattr(config, "output", None)
    definitions, plans, jobs = [], [], []
    references = read_sessions(getattr(config, "reference_sessions", ()))
    if references:
        print(f"Reference sessions: {[s['source'] for s in references]}", flush=True)
    if config.command in {"case", "failures"}:
        records = {}
        skipped = 0
        for value in config.inputs:
            path = Path(value).resolve()
            if not path.exists():
                raise FileNotFoundError(path)
            for file in sorted(path.rglob("session.json")) if path.is_dir() else [path]:
                record = decode_json(file.read_text()) if file.suffix == ".json" else load_replay(file)
                if not isinstance(record, dict) or "turns" not in record or "status" not in record:
                    raise ValueError(f"Not an episode record: {file}")
                if config.paid:
                    if record["status"] != "complete" or not record.get("report"):
                        skipped += 1
                        continue
                    trace_report(normalize_report(record["report"])[0], record["turns"])
                identity = record.get("episode_id") or str(file)
                if identity in records:
                    previous = records[identity][1]
                    fields = ("scene", "model", "tell", "budget", "status", "termination_reason",
                              "scene_spec", "prompt", "final_prompt", "report", "turns",
                              "scoring_parameters", "resource_usage")
                    if any(previous.get(key) != record.get(key) for key in fields):
                        raise ValueError(f"Conflicting records for episode_id {identity}; select one version explicitly")
                    if not config.paid:
                        evaluations = []
                        for source in (records[identity][0], file):
                            evaluation = source.with_name("eval.json")
                            evaluations.append(decode_json(evaluation.read_text()) if evaluation.exists() else None)
                        if evaluations[0] != evaluations[1]:
                            raise ValueError(f"Conflicting evaluations for episode_id {identity}; select one version explicitly")
                records.setdefault(identity, (file, record))
        if skipped:
            print(f"Skipped {skipped} unfinished explorations; only complete saved reports will be evaluated.")
        if not records:
            raise ValueError("No session.json or replay records found")
        jobs = [{"source": path, "record": record,
                 "settings": config.settings, "evaluation_output": output / f"eval-{index}.json" if config.paid else None}
                for index, (path, record) in enumerate(records.values(), 1)]
    else:
        # 统一读取各组输入；只有生成任务需要 operation/count/prompt。
        if config.command == "generate":
            groups = [("generate", config.inputs + config.reference, config.counts[0], config.new_prompt),
                      ("mutate", [config.mutate_source] if config.counts[1] else [], config.counts[1], config.mutate_prompt),
                      ("compose", config.compose_source or ["A1", "B2"] if config.counts[2] else [],
                       config.counts[2], config.compose_prompt)]
        elif config.command == "composition":
            if config.parent and (config.source or config.reference_sessions):
                raise ValueError("--parent cannot be combined with --source or --reference-session")
            groups = [("parent", [config.parent], 1, "")] if config.parent else [
                ("compose", config.source or ["A1", "B2"], 1, config.prompt)]
        else:
            inputs = [config.benchmark] if config.command == "list" else config.inputs or [str(ROOT / "scenes/base.json")]
            groups = [("load", inputs, 1, "")]
        for operation, inputs, count, prompt in groups:
            selected = []
            for value in inputs:
                if Path(value).is_file():
                    path, selector = value, ""
                elif "#" in value:
                    path, selector = value.rsplit("#", 1)
                    if not selector:
                        raise ValueError(f"Missing scene ID: {value}")
                else:
                    path, selector = ROOT / "scenes/base.json", value
                scenes = [scene for scene in read_json([path]) if not selector or scene["id"] == selector]
                if not scenes:
                    raise ValueError(f"Unknown scene source: {value}")
                selected.extend(scenes)
            if count and (operation in {"mutate", "parent"} and len(selected) != 1 or operation == "compose" and len(selected) < 2):
                raise ValueError("parent/mutate need one scene; compose needs at least two")
            if operation in {"load", "parent"}:
                definitions.extend(selected)
            else:
                plans.extend([(operation, selected, prompt)] * count)
        if config.command == "list":
            for scene in definitions:
                print(scene["id"] if config.ids_only else f"{scene['id']}\t{scene.get('metadata', {}).get('title', '')}")
            return []
        if config.command in {"models", "budget"}:
            selection = config.selection or ([] if config.inputs else ["C0", "A1"])
            if set(selection) - {scene["id"] for scene in definitions}:
                raise ValueError("SCENES contains an unknown scene ID")
            definitions = [scene for scene in definitions if not selection or scene["id"] in selection]
        for scene, tell in product(definitions, config.tells if not config.prepare_only else ["T0"]):
            run_episode(scene, tell=tell, model=config.models[0], settings=config.settings,
                        record_fps=config.fps, check_only=True)
        for operation, sources, prompt in plans:
            for scene in sources:
                run_episode(scene, model=config.models[0], settings=config.settings, check_only=True)
            print(f"{operation}: {[scene['id'] for scene in sources]}, generator={config.settings.generator_model}", flush=True)

    if not config.dry:
        if config.paid and not config.allow_paid:
            raise ValueError("Paid execution needs DRY_RUN=0 ALLOW_PAID_API=1")
        output.mkdir(parents=True)
        if config.command not in {"case", "failures"}:
            scene_count = len(definitions) + len(plans)
            write_json_atomic(output / "plan.json", {
                "command": config.command, "request_settings": config.settings.public(), "expected_scenes": scene_count,
                "expected_episodes": (0 if config.prepare_only else
                    scene_count * len(config.models) * len(config.tells) * len(config.budgets) * config.repeats),
                "models": config.models, "tells": config.tells, "budgets": config.budgets,
                "repeats": config.repeats, "scene_ids": [s["id"] for s in definitions],
                "generation": [{"operation": op, "source_ids": [s["id"] for s in sources]}
                               for op, sources, _ in plans],
                "reference_sessions": [s["source"] for s in references],
            }, overwrite=False)
        if plans and references:
            references = prepare_references(references, model=config.settings.generator_model, settings=config.settings,
                                            log_path=output / "reference_preprocess.jsonl")
            write_json_atomic(output / "reference_sessions.json", references, overwrite=False)
        for index, (operation, sources, prompt) in enumerate(plans, 1):
            scene = generate_scene(operation, sources, prompt=prompt, model=config.settings.generator_model, settings=config.settings,
                                   reference_sessions=references,
                                   log_path=output / "data" / f"{operation}-{index}.attempts.jsonl")
            save_json(output / "data" / f"{operation}-{index}.json", scene)
            if not config.prepare_only:
                for tell in config.tells:
                    run_episode(scene, tell=tell, model=config.models[0], settings=config.settings,
                                record_fps=config.fps, check_only=True)
            definitions.append(scene)
        if config.command == "composition" and config.parent:
            save_json(output / "data" / "parent.json", definitions[0])
    if config.command not in {"case", "failures"} and not config.prepare_only:
        counts = Counter(scene["id"] for scene in definitions)
        for repeat, (si, scene), tell, budget, model in product(
                range(1, config.repeats + 1), enumerate(definitions, 1), config.tells,
                config.budgets, config.models):
            if model in {".", ".."}:
                raise ValueError("Invalid model directory name")
            if scene["id"] in {".", ".."}:
                raise ValueError("Invalid scene directory name")
            name = quote(scene["id"], safe="-_.") + (f"@{si}" if counts[scene["id"]] > 1 else "")
            batch = output / f"budget-{budget}" if len(config.budgets) > 1 else output
            folder = batch / name / quote(model, safe="-_.") / f"r{repeat}" / tell
            jobs.append({"source": folder / "session.json", "evaluation_output": folder / "eval.json", "settings": config.settings,
                         "episode": dict(source=scene, tell=tell, budget=budget, model=model, output=folder,
                                         record_fps=config.fps, settings=config.settings)})
    if config.prepare_only or config.dry and plans:
        print(f"{'Preview' if config.dry else 'Prepared'} {len(definitions) + (len(plans) if config.dry else 0)} scenes; output: {output}", flush=True)
    else:
        print(f"{'Preview' if config.dry else 'Prepared'} {len(jobs)} episodes; output: {output}", flush=True)
    if config.dry:
        for job in jobs:
            print(f"  {job['source']}")
    return jobs


def run_experiments(job):
    """3. 执行一局实验并读取其存档；已有记录直接进入下一步。"""
    episode = job.pop("episode", None)
    if episode is not None:
        print(f"Run {episode['source']['id']}/{episode['tell']}/{episode['model']}, budget={episode['budget']}", flush=True)
        try:
            run_episode(**episode)
            job["record"] = decode_json(job["source"].read_text())
        except Exception as error:
            try:
                saved = decode_json(job["source"].read_text())
            except (OSError, ValueError):
                saved = {}
            job["record"] = saved if isinstance(saved, dict) else {}
            for key, value in {"scene": episode["source"]["id"], "model": episode["model"],
                               "tell": episode["tell"], "budget": episode["budget"]}.items():
                job["record"].setdefault(key, value)
            job["record"].update(status="failed", error=f"{type(error).__name__}: {error}")
            job["execution_failed"] = True
    return job


def evaluate_results(job):
    """4. 调用现有裁判并保存单局评分；本地分析只读取已有评分。"""
    if job.get("execution_failed"):
        job["evaluation"] = None
    elif job["evaluation_output"] is not None:
        label = f"{job['record'].get('model', '?')} | {job['source'].parent.name}"
        log = partial(write_log, directory=job["evaluation_output"].parent, label=label, started=time.monotonic())
        log("评分开始")
        job["evaluation"] = grade(job["record"], settings=job.get("settings"), log=log,
                                  output=job["evaluation_output"])
        result = job["evaluation"]
        log(f"评分完成，总分={result['scorecard']['total_score']}" if result["status"] == "complete"
            else f"ERROR 评分失败：{result.get('error')}")
    else:
        path = job["source"].with_name("eval.json")
        job["evaluation"] = decode_json(path.read_text()) if path.exists() else None
    return job


def run_and_evaluate(job):
    """跑完一局立即评分：eval.json 与 session.json 同步落盘，可随时获取已完成局的结果。"""
    executing = "episode" in job or job["evaluation_output"] is not None
    try:
        result = evaluate_results(run_experiments(job))
    except Exception as error:
        print(f"[任务异常] {job['source']} | {type(error).__name__}: {error}", file=sys.stderr, flush=True)
        raise
    record, evaluation = result["record"], result["evaluation"] or {}
    if executing and (record.get("status") != "complete" or evaluation.get("status") != "complete"):
        stage = "实验" if record.get("status") != "complete" else "评分"
        reason = record.get("error") or evaluation.get("error") or "未完成"
        print(f"[{stage}失败，无有效评分] {record.get('scene')} / {record.get('model')} / "
              f"{record.get('tell')} / {record.get('budget')}轮 | {reason}\n输出位置：{job['source']}",
              file=sys.stderr, flush=True)
    return result


def save_results(config, results):
    """5. 整理单局结果，保存汇总或失败列表，并返回本次退出状态。"""
    if config.command == "list" or config.dry or config.prepare_only:
        return 0
    rows = []
    for job in results:
        record, evaluation = job["record"], job["evaluation"]
        errors = [{"turn": turn["turn"], "act": turn["act"], "outcome": turn["outcome"]}
                  for turn in record.get("turns", []) if turn.get("outcome") != "ok"]
        row = {"source": str(job["source"]), **{key: record.get(key) for key in ("scene", "model", "tell", "budget", "status", "error")},
               "turn_count": len(record.get("turns", [])), "action_failures": errors, "evaluation": evaluation}
        if config.command == "failures":
            judgement = (evaluation or {}).get("judgement", {})
            if (row["status"] == "complete" and not errors and (evaluation or {}).get("status") == "complete"
                    and judgement.get("correct") is True and judgement.get("supported") is not False
                    and not judgement.get("action_errors")):
                continue
        elif config.command == "case" and config.mode == "analyze":
            row.update(turns=record["turns"], report=record.get("report"))
        rows.append(row)
    filename = "failures.json" if config.command == "failures" else "summary.json"
    write_json_atomic(config.output / filename, rows, overwrite=False)
    if config.command != "failures":
        evaluations = []
        for row in rows:
            repeat = Path(row["source"]).parents[1].name
            evaluations.append({**(row["evaluation"] if row["evaluation"] is not None else
                                    {"status": "not_evaluated", "error": row["error"]}),
                                **{key: row[key] for key in ("scene", "model", "tell", "budget", "source")},
                                "repeat": int(repeat[1:]) if repeat.startswith("r") and repeat[1:].isdigit() else None})
        write_json_atomic(config.output / "eval.json", evaluations, overwrite=False)
    run_errors = [{**{key: row[key] for key in ("scene", "model", "tell", "budget", "source")},
                   "stage": "experiment" if row["status"] != "complete" else "evaluation",
                   "error": row["error"] or (row["evaluation"] or {}).get("error") or "未完成"}
                  for row in rows if row["status"] != "complete" or (row["evaluation"] or {}).get("status") != "complete"]
    if config.paid:
        write_json_atomic(config.output / "run_errors.json", run_errors, overwrite=False)
        print(f"批次结束：共{len(rows)}局，完成评分{len(rows) - len(run_errors)}局，"
              f"运行或评分失败{len(run_errors)}局。输出：{config.output}", flush=True)
        for error in run_errors:
            print(f"[失败汇总] {error['scene']} / {error['model']} / {error['tell']} / {error['budget']}轮"
                  f" | {error['stage']}: {error['error']}\n输出位置：{error['source']}", file=sys.stderr, flush=True)
        if run_errors:
            print(f"失败清单：{config.output / 'run_errors.json'}", file=sys.stderr, flush=True)
    return int(config.paid and bool(run_errors))


def main(argv=None):
    config, stage = None, "preparation"
    try:
        config = load_config(argv)
        jobs = prepare_scenes(config)
        stage = "execution"
        results = run_pool(run_and_evaluate, jobs, workers=config.workers) if jobs and not config.dry else []
        return save_results(config, results)
    except (KeyboardInterrupt, ValueError, OSError, KeyError, TypeError, SyntaxError, RuntimeError) as error:
        detail = f"{type(error).__name__}: {error}"
        print(f"[批次未完成] {stage}: {detail}", file=sys.stderr, flush=True)
        if config is not None and not config.dry and config.output.is_dir():
            target = config.output / "run_errors.json"
            if not target.exists():
                try:
                    write_json_atomic(target, [{"scene": None, "model": None, "tell": None, "budget": None,
                                               "source": str(config.output), "stage": stage,
                                               "error": detail}], overwrite=False)
                    print(f"失败清单：{target}", file=sys.stderr, flush=True)
                except OSError as save_error:
                    print(f"保存失败清单失败：{save_error}", file=sys.stderr, flush=True)
        return 130 if isinstance(error, KeyboardInterrupt) else 1


if __name__ == "__main__":
    sys.exit(main())
