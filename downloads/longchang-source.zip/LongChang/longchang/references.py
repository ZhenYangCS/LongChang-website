"""按 turn 分块阅读参考记录，滚动总结关键实验、发现和局限。"""

import json
from pathlib import Path

from engine import call_api, Settings
from prompts.scenes import SESSION_SUMMARY_PROMPT


def _json(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def _size(value):
    return len(_json(value).encode("utf-8"))


def _chunks(session, budget):
    """按完整轮次分块；单条记录过长时再拆分，所有片段都会读入。"""
    rows = [(None, {k: v for k, v in session.items() if k != "turns"})]
    rows.extend((row["turn"], row) for row in session["turns"])
    batch = []
    for turn, row in rows:
        text = _json(row)
        whole = {"turn": turn, "offset": 0, "text": text}
        step = len(text) if _size([whole]) <= budget else budget // 8
        for offset in range(0, len(text), step):
            item = {"turn": turn, "offset": offset, "text": text[offset:offset + step]}
            if batch and _size([*batch, item]) > budget:
                yield batch
                batch = []
            batch.append(item)
    if batch:
        yield batch


def prepare_references(sessions, *, model=None, log_path=None, settings=None):
    if not sessions:
        return []
    settings = settings or Settings.from_env()
    if not settings.reference_preprocess:
        return sessions
    model = model or settings.generator_model
    limit = settings.reference_max_bytes
    prepared = []
    for original in sessions:
        # raw 已包含 NOTE/ACT；保留每轮前后观测。
        session = {**original, "turns": [{k: v for k, v in row.items()
                    if k not in {"note", "act"} or "raw" not in row} for row in original["turns"]]}
        summary = ""
        for index, fragments in enumerate(_chunks(session, limit), 1):
            print(f"Reference {session['id']}: update exploration summary, chunk {index}", flush=True)
            task = {"session_id": session["id"], "previous": summary, "fragments": fragments}
            summary = call_api([{"role": "system", "content": SESSION_SUMMARY_PROMPT},
                                {"role": "user", "content": _json(task)}], model=model, settings=settings)
            if log_path is not None:
                path = Path(log_path)
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("a", encoding="utf-8") as output:
                    output.write(_json({"session_id": session["id"], "chunk": index,
                                        "summary_kind": "exploration_summary", "summary": summary}) + "\n")
        identity = {k: session[k] for k in ("id", "source", "episode_id", "scene", "model", "tell", "budget",
                                           "status", "termination_reason") if k in session}
        prepared.append({**identity, "summarized": True, "summary_kind": "exploration_summary", "summary": summary,
                         "oracle": session["scene_spec"]["oracle"],
                         "original_turn_count": len(session["turns"]),
                         "turns": [{"turn": row["turn"]} for row in session["turns"]]})
    return prepared
