"""场景构建与生成。JSON -> geometry XML + compiled callbacks + initial state.

    scene = load_scene("scenes/base.json", "A1")
    world = World(scene)
    # Already decoded JSON: scene = load_scene(definition)

A scene has id, entities and program; state/seed/gravity/metadata/oracle/landmarks
are optional. program maps init/step/post_step/launch/material to Python bodies.
Bodies receive model, data, state; launch also receives name, material body_ids.
They may use np, mujoco, math, random, G, colours, inside, dof and contact helpers.
init may call step(model, data); post_step may do the same. Programs are trusted
Python code, compiled once when loaded. No rule language or scene-specific logic.
"""

import argparse
import builtins
import copy
import json
from functools import partial
import math
from pathlib import Path
import random
import sys
from textwrap import indent
import traceback
from types import SimpleNamespace
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

from engine import PermanentAPIError, ResponsesConversation, call_api, decode_json, reply_json, Settings
from references import prepare_references
from prompts import (DESIGN_PROMPT, REVIEW_PROMPT, SCENE_OPERATION_PROMPTS, SCENE_REPAIR_PROMPT,
                     SESSION_DESIGN_PROMPT, SESSION_REVIEW_PROMPT)
from world import (COLORS, World, contact_pairs, dof, material_bounce,
                   material_contacts, new_floor_contacts, write_json_atomic)

# 1. 场景构建：JSON → XML、规则函数和初始状态。

FORMAT = "longchang.scenes"
PALETTE = {name: np.fromstring(rgba, sep=" ") for name, rgba in COLORS.items()}


def free_bodies(model):
    """每次查询当前模型的自由物体，自动包含后来安装的器材。"""
    return [bid for bid in range(1, model.nbody)
            if model.body_jntadr[bid] >= 0
            and model.jnt_type[model.body_jntadr[bid]] == mujoco.mjtJoint.mjJNT_FREE]


def body_colour(model, bid):
    """与公开观察使用同一颜色归类；没有几何体的根节点没有颜色。"""
    if not model.body_geomnum[bid]:
        return None
    rgb = model.geom_rgba[model.body_geomadr[bid], :3]
    return min(PALETTE, key=lambda name: float(np.linalg.norm(rgb - PALETTE[name][:3])))


ARGUMENTS = {"init": "", "step": "", "post_step": "", "launch": ", name", "material": ", body_ids"}
API = dict(np=np, mujoco=mujoco, math=math, random=random, G=9.81, dof=dof,
           free_bodies=free_bodies, body_colour=body_colour,
           contact_pairs=contact_pairs, material_bounce=material_bounce,
           material_contacts=material_contacts, new_floor_contacts=new_floor_contacts,
           colours=PALETTE,
           inside=lambda pos, centre, half: abs(pos[0]-centre[0]) < half and abs(pos[1]-centre[1]) < half)
BUILTINS = {name: getattr(builtins, name) for name in (
    "abs", "all", "any", "bool", "dict", "enumerate", "float", "int", "len",
    "list", "max", "min", "range", "set", "sorted", "str", "sum", "tuple", "zip")}


def load_scene(source, scene_id=None, *, seed=None):
    """读取场景 JSON，然后构建 XML、规则回调和初始状态。"""
    # 1. 取得场景定义：文件中的指定场景，或生成器已解析的 JSON 字典。
    if isinstance(source, dict):
        definition = source
    else:
        definitions = read_json([source])
        definition = next((item for item in definitions if item["id"] == scene_id), None)
        if definition is None:
            raise ValueError(f"Unknown scene ID: {scene_id}")
    if scene_id is not None and definition.get("id") != scene_id:
        raise ValueError(f"Unknown scene ID: {scene_id}")
    # 2. 一次构建好 MuJoCo 所需的场景材料。
    return Scene(definition, seed=seed)


class Scene:
    def __init__(self, definition, *, seed=None):
        if not isinstance(definition, dict) or not {"id", "entities", "program"} <= definition.keys():
            raise ValueError("A scene needs id, entities and program")
        self.scene_spec = copy.deepcopy(definition)
        self.scene_spec["seed"] = definition.get("seed", 0) if seed is None else seed
        if type(self.scene_spec["seed"]) is not int or self.scene_spec["seed"] < 0:
            raise ValueError("seed must be a nonnegative integer")
        self.state = SimpleNamespace(**copy.deepcopy(definition.get("state", {})))
        self.state.seed = self.scene_spec["seed"]
        self._xml = self._geometry()
        callbacks = self._compile()
        self._init = callbacks.get("init", lambda *args: None)
        self.hook = callbacks.get("step", lambda *args: None)
        self.post_step = callbacks.get("post_step")
        self.on_launch = callbacks.get("launch")
        self.material_hook = callbacks.get("material")
        self._initialised = False

    def xml(self):
        return self._xml

    def initial_hook(self, model, data):
        if not self._initialised:
            model.opt.gravity[:] = self.scene_spec.get("gravity", [0, 0, -9.81])
            self._init(model, data)
            self._initialised = True

    def ground_truth(self):
        return self.scene_spec.get("oracle", {}).get("ground_truth", "")

    def rubric(self):
        return copy.deepcopy(self.scene_spec.get("oracle", {}).get("rubric", []))

    def landmarks(self):
        """固定物的公开描述只取几何；作者的自由文本不能成为额外提示。"""
        fixtures = []
        for entity in self.scene_spec["entities"]:
            if entity["kind"] != "fixture":
                continue
            colour = min(PALETTE, key=lambda c: float(np.linalg.norm(
                PALETTE[c][:3] - np.asarray(entity["rgba"][:3]))))
            size = " x ".join(f"{2 * v:g}" for v in entity["size"]) + " bricks"
            fixtures.append({"object": entity["name"], "colour": colour, "state": "fixed",
                             "position": str(tuple(round(float(v), 1) for v in entity["position"])),
                             "size": size})
        return fixtures

    def _geometry(self):
        entities = self.scene_spec["entities"]
        root = ET.Element("worldbody")
        numbers = lambda values: " ".join(map(str, values))
        if not isinstance(entities, list) or not entities:
            raise ValueError("A scene needs entities")
        names = set()
        for e in entities:
            if e["name"] in names or e["kind"] not in ("body", "fixture") or e["shape"] not in ("sphere", "box"):
                raise ValueError("Invalid or duplicate scene entity")
            names.add(e["name"])
            attrs = dict(type=e["shape"], size=numbers(e["size"]), rgba=numbers(e["rgba"]))
            if e["kind"] == "body":
                node = ET.SubElement(root, "body", name=e["name"], pos=numbers(e["position"]))
                ET.SubElement(node, "freejoint")
                ET.SubElement(node, "geom", **attrs, mass=str(e["mass"]))
            else:
                ET.SubElement(root, "geom", **attrs, name=e["name"], pos=numbers(e["position"]),
                              contype=str(e.get("contype", 0)), conaffinity=str(e.get("conaffinity", 0)))
        return "\n".join(ET.tostring(child, encoding="unicode") for child in root)

    def _compile(self):
        program, scene_id = self.scene_spec["program"], self.scene_spec["id"]
        if not isinstance(program, dict) or program.keys() - ARGUMENTS.keys():
            raise ValueError("program supports init, step, post_step, launch and material")
        namespace, callbacks = {"__builtins__": BUILTINS, **API}, {}
        for event, body in program.items():
            if not isinstance(body, str):
                raise ValueError(f"{scene_id}.{event} must contain Python code")
            source = f"def {event}(state, model, data{ARGUMENTS[event]}):\n{indent(body.strip() or 'pass', '    ')}\n"
            exec(compile(source, f"<{scene_id}.{event}>", "exec"), namespace)
            callbacks[event] = partial(namespace[event], self.state)
        namespace.update(callbacks)
        return callbacks


# 2. 场景生成：需求／参考场景 → LLM 生成 → 执行检查 → 评审并保存 JSON。

def read_json(files):
    """1. 读取指定的 JSON 题库文件，只接受当前场景格式。"""
    definitions = []
    for filename in files:
        document = decode_json(Path(filename).read_text(encoding="utf-8"))
        if not isinstance(document, dict) or document.get("format") != FORMAT or not isinstance(document.get("scenes"), list):
            raise ValueError(f"Expected a scene catalogue: {filename}")
        entries = document["scenes"]
        ids = [s.get("id") for s in entries if isinstance(s, dict)]
        if not ids or len(ids) != len(entries) or any(not isinstance(i, str) or not i for i in ids) or len(set(ids)) != len(ids):
            raise ValueError(f"Invalid or duplicate scene IDs: {filename}")
        suites = document.get("suites", {})
        if not isinstance(suites, dict) or any(not isinstance(v, list) or any(i not in ids for i in v) for v in suites.values()):
            raise ValueError(f"Suites must list existing scene IDs: {filename}")
        definitions.extend(entries)
    return definitions


def read_sessions(files):
    """读取可选参考 session，保留诊断所需记录，不加载回放帧。"""
    sessions, seen = [], set()
    for filename in files:
        path = Path(filename)
        path = (path / "session.json" if path.is_dir() else path).resolve()
        if path in seen:
            continue
        record = decode_json(path.read_text(encoding="utf-8"))
        if (not isinstance(record, dict) or not isinstance(record.get("turns"), list)
                or not isinstance(record.get("scene_spec"), dict) or "oracle" not in record["scene_spec"]):
            raise ValueError(f"Expected a session with turns and scene_spec.oracle: {path}")
        entry = {"id": f"S{len(sessions) + 1}", "source": str(path),
                 **{k: record[k] for k in ("episode_id", "scene", "model", "tell", "budget", "status", "error",
                                          "termination_reason", "scene_spec", "turns", "report", "resource_usage",
                                          "build_reviews", "scoring_parameters") if k in record}}
        evaluation = path.with_name("eval.json")
        if evaluation.is_file():
            entry["evaluation"] = decode_json(evaluation.read_text(encoding="utf-8"))
        sessions.append(entry)
        seen.add(path)
    return sessions


def record_references(proposal, sessions):
    """保存实际参考来源，仅校验弱点证据的 session/turn 引用。"""
    provenance = proposal.setdefault("provenance", {})
    provenance["reference_sessions"] = [{k: s.get(k) for k in ("id", "source", "episode_id", "model")} for s in sessions]
    if not sessions:
        provenance["weaknesses"] = []
        provenance.pop("session_basis", None)
        return
    actual = {s["id"]: {t["turn"] for t in s["turns"]} for s in sessions}
    weaknesses = provenance.get("weaknesses")
    if not isinstance(weaknesses, list):
        raise ValueError("provenance.weaknesses must be a list")
    for weakness in weaknesses:
        cited = weakness.get("evidence", [])
        if (not isinstance(cited, list) or not cited
                or any(type(e["turn"]) is not int or e["turn"] not in actual.get(e["session_id"], ()) for e in cited)):
            raise ValueError("Each weakness needs real session_id/turn evidence")


def generate_scene(operation, sources, *, prompt="", model=None, reference_sessions=(), log_path=None, settings=None):
    """生成 → 物理检查 → 审核；草稿错误反馈修正，生成截断最多容许三次。"""
    settings = settings or Settings.from_env()
    model = model or settings.generator_model
    if operation == "mutate" and len(sources) != 1:
        raise ValueError("mutate needs exactly one input scene")
    if operation == "compose" and len(sources) < 2:
        raise ValueError("compose needs at least two input scenes")
    expected_rules = None
    if operation == "compose":
        counts = [source["oracle"]["rule_count"] for source in sources]
        if any(type(count) is not int or count < 0 for count in counts):
            raise ValueError("compose sources need nonnegative integer rule_count")
        expected_rules = sum(counts)

    task = {"operation": operation, "instructions": prompt, "sources": sources}
    system = SCENE_OPERATION_PROMPTS[operation] + "\n" + DESIGN_PROMPT
    if reference_sessions:
        task["reference_sessions"] = reference_sessions
        system += "\n" + SESSION_DESIGN_PROMPT
    original = [{"role": "system", "content": system},
                {"role": "user", "content": json.dumps(task, ensure_ascii=False, allow_nan=False, separators=(",", ":"))}]
    path = Path(log_path) if log_path is not None else None
    if path is not None:
        path.parent.mkdir(parents=True, exist_ok=True)

    def record(**event):
        if path is not None:
            with path.open("a", encoding="utf-8") as output:
                output.write(json.dumps({"attempt": attempt, **event}, ensure_ascii=False) + "\n")

    def record_abort(stage, error):
        record(stage=stage, status="interrupted" if isinstance(error, (KeyboardInterrupt, InterruptedError)) else "failed",
               error=f"{type(error).__name__}: {error}", raw_response=getattr(error, "raw_response", None), api_failure=getattr(error, "details", None))

    chat = (ResponsesConversation(model, settings.scene_compact_threshold, settings=settings)
            if settings.scene_compact_threshold else None)
    if chat is not None:
        chat.phase = 'scene_generation'
    messages, attempt, truncations = original, 0, 0
    label = str(path or operation)
    while settings.scene_attempts is None or attempt < settings.scene_attempts:
        attempt += 1
        print(f"Scene {label}: attempt {attempt}, generating", flush=True)
        try:
            request = messages
            if truncations:
                request = messages + [{"role": "user", "content": SCENE_REPAIR_PROMPT.format(
                    stage="generation", error="The previous response exhausted the output token budget. "
                    "Keep deliberation brief and return compact, complete scene JSON. Shorten prose and repetition; "
                    "retain every required law, parameter, callback and law/apparatus check.")}]
            if chat is None:
                raw = call_api(request, model=model, settings=settings)
            else:
                chat.turn = attempt
                before = len(chat.calls)
                try:
                    try:
                        raw = chat(request)
                    except PermanentAPIError as error:
                        description = str(error).lower()
                        opaque = any(item.get('encrypted_content') for item in chat._context)
                        recoverable = ('http 400:' in description and opaque and
                                       ('encrypted' in description or description.strip() == 'http 400: bad request'))
                        if not recoverable:
                            raise
                        for event in chat.calls[before:]:
                            record(stage='context', policy=chat.policy, context_call=event)
                        record(stage='context_recovery', error=str(error),
                               mode='fresh_responses_full_visible_transcript',
                               discarded_state='unverifiable_encrypted_items')
                        print(f'Scene {label}: encrypted state rejected; restarting once from the full visible transcript', flush=True)
                        chat = ResponsesConversation(model, settings.scene_compact_threshold, settings=settings)
                        chat.phase, chat.turn = 'scene_generation', attempt
                        before = 0
                        raw = chat(request)
                finally:
                    for event in chat.calls[before:]:
                        record(stage='context', policy=chat.policy, context_call=event)
        except BaseException as error:
            record_abort("generate", error)
            if isinstance(error, PermanentAPIError) and error.details.get("finish_reason") == "length":
                truncations += 1
                if truncations < 3 and (settings.scene_attempts is None or attempt < settings.scene_attempts):
                    print(f"Scene {label}: 第{truncations}/3次输出截断，保留原要求并请求精简重生成", flush=True)
                    continue
            raise
        record(stage="generate", raw=raw)
        stage = "parse"
        try:
            proposal = reply_json(raw)
            if not isinstance(proposal, dict):
                raise ValueError("Return one scene JSON object")
            record_references(proposal, reference_sessions)
            stage = "validate"
            if expected_rules is not None and proposal.get("oracle", {}).get("rule_count") != expected_rules:
                raise ValueError(f"compose must preserve all {expected_rules} source laws")
            scene = validate_scene(proposal, operation)
            scene["provenance"]["operation"] = operation
            metadata = scene.setdefault("metadata", {})
            if not metadata.get("task_policy"):
                metadata["task_policy"] = "multiple_rules" if scene["oracle"]["rule_count"] > 1 else "single_rule"
            stage = "review"
            review = review_scene(scene, operation, sources, prompt=prompt, model=model,
                                  reference_sessions=reference_sessions, settings=settings, log=partial(record, stage="review"))
        except (OSError, PermanentAPIError, KeyboardInterrupt) as error:
            record_abort(stage, error)
            raise  # 连接或文件系统故障不能靠改写场景解决。
        except (ValueError, TypeError, KeyError, AttributeError, SyntaxError, ArithmeticError, NameError, IndexError) as error:
            feedback = traceback.format_exc(limit=-4).strip()
            record(stage=stage, status="failed", error=feedback)
            if settings.scene_attempts is not None and attempt >= settings.scene_attempts:
                break
            reason = " ".join(str(error).split())[:240]
            print(f"Scene {label}: 第{attempt}次草稿未通过{stage}，"
                  f"正在自动修正（第{attempt + 1}次）；原因：{reason}", flush=True)
            # Chat keeps the latest draft; Responses retains its compactable conversation state.
            messages = (request if chat is not None else original) + [
                {"role": "assistant", "content": raw},
                {"role": "user", "content": SCENE_REPAIR_PROMPT.format(stage=stage, error=feedback)},
            ]
            continue
        record(stage="review", status="approved", review=review)
        scene["provenance"]["review"] = review
        print(f"Scene {label}: attempt {attempt}, approved", flush=True)
        return scene
    raise ValueError(f"Scene failed after {attempt} attempts; see {path}")


def review_projection(proposal):
    """Losslessly pack consecutive identical check readings for the model; preserve the saved raw scene."""
    projected = copy.deepcopy(proposal)
    checks = projected.get('provenance', {}).get('validation', {}).get('checks', [])
    for case in checks:
        measurements = case.get('measurements')
        if not isinstance(measurements, list) or not measurements:
            continue
        runs = []
        for measurement in measurements:
            if runs and measurement == runs[-1]['measurement']:
                runs[-1]['repeat'] += 1
            else:
                runs.append({'repeat': 1, 'measurement': measurement})
        packed = {'encoding': 'consecutive_repetitions_v1', 'count': len(measurements), 'runs': runs}
        if len(json.dumps(packed)) < len(json.dumps(measurements)):
            case['measurements'] = packed
    return projected


def review_scene(proposal, operation, sources, *, prompt="", model=None, reference_sessions=(), settings=None, log=None):
    """4. 调用 LLM 评审，核对程序、答案和实际检查结果。"""
    task = {"operation": operation, "instructions": prompt, "sources": sources}
    record_references(proposal, reference_sessions)
    system = REVIEW_PROMPT
    if reference_sessions:
        task["reference_sessions"] = reference_sessions
        system += "\n" + SESSION_REVIEW_PROMPT
    system += ('\nValidation measurements may use consecutive_repetitions_v1: expand each '
               'runs entry by repeating its measurement exactly repeat times, in order. '
               'count is the original number of measurements. No readings are omitted or rounded.')
    payload = {'task': task, 'proposal': review_projection(proposal)}
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":"))}]
    settings = settings or Settings.from_env()
    if settings.scene_compact_threshold:
        # Compaction cannot rescue a first request which already exceeds the input window.
        if len(json.dumps(messages, ensure_ascii=False).encode()) > 512000:
            raise ValueError('Packed scene review still exceeds 512000 input bytes; simplify redundant validation checks')
        chat = ResponsesConversation(model or settings.generator_model, settings.scene_compact_threshold,
                                     settings=settings)
        chat.phase = 'scene_review'
        try:
            raw = chat(messages)
        finally:
            if log is not None:
                for event in chat.calls:
                    log(policy=chat.policy, context_call=event)
    else:
        raw = call_api(messages, model=model or settings.generator_model, settings=settings)
    if log is not None:
        log(raw=raw)
    review = reply_json(raw)
    if (not isinstance(review, dict) or set(review) != {"approved", "reason"}
            or type(review["approved"]) is not bool
            or not isinstance(review["reason"], str) or not review["reason"].strip()):
        raise ValueError("Review must contain approved:boolean and a nonempty reason:string")
    if not review["approved"]:
        raise ValueError("LLM review rejected the proposal: " + review["reason"])
    return review


def validate_scene(proposal, operation):
    """3. 编译、试跑并执行逐规律检查；不将能运行等同于规律正确。"""
    runtime = load_scene(proposal)
    scene = runtime.scene_spec
    if operation == "generate" and not any(code.strip() for code in scene["program"].values()):
        raise ValueError("Generation requires a nonempty physical program")
    world = World(runtime)
    for _ in range(60):
        world.step()
    if not (np.isfinite(world.data.qpos).all() and np.isfinite(world.data.qvel).all()):
        raise ValueError("Scene produced non-finite motion")
    oracle = scene.get("oracle", {})
    if not isinstance(oracle, dict):
        raise ValueError("oracle must be an object")
    rules = oracle.get("rules", [])
    if (type(oracle.get("control")) is not bool or type(oracle.get("rule_count")) is not int
            or not isinstance(rules, list) or oracle["rule_count"] != len(rules)
            or oracle["control"] != (len(rules) == 0)
            or not isinstance(oracle.get("ground_truth"), str) or not oracle["ground_truth"].strip()):
        raise ValueError("oracle needs consistent control, rule_count, rules and ground_truth")
    if oracle["rule_count"] > 1 and scene.get("metadata", {}).get("task_policy") == "single_rule":
        raise ValueError("A multi-rule scene cannot declare task_policy=single_rule")
    rule_ids = [r.get("id", r.get("family")) for r in rules if isinstance(r, dict)]
    if (len(rule_ids) != len(rules) or any(not isinstance(r, str) or not r for r in rule_ids)
            or len(set(rule_ids)) != len(rule_ids)):
        raise ValueError("Each oracle rule needs a unique id")
    checks = scene.get("checks")
    if not isinstance(checks, list) or not checks:
        raise ValueError("Generated scenes need executable checks for laws and apparatus scope")
    expected = {(rule, kind) for rule in rule_ids or ["control"] for kind in ("law", "apparatus")}
    reports = []
    for case in checks:
        if (not isinstance(case, dict) or set(case) != {"rule", "kind", "code"}
                or not isinstance(case.get("rule"), str) or not isinstance(case.get("kind"), str)
                or (case["rule"], case["kind"]) not in expected
                or not isinstance(case["code"], str) or not case["code"].strip()):
            raise ValueError("Each check needs rule, kind (law/apparatus) and executable code")
        reports.append(run_scene_check(scene, case))
    if {(r["rule"], r["kind"]) for r in reports} != expected:
        raise ValueError("Every rule needs both law and apparatus checks")
    scene.setdefault("provenance", {})["validation"] = {
        "passed": True, "scope": "Compilation, 60 simulation steps and declared behavioral checks; not a proof of all behavior",
        "checks": reports}
    return scene


def run_scene_check(scene, case):
    """在独立世界执行受信任的检查代码；探针安装无模型调用，保存实测值。"""
    from tools import Instrument
    world = World(load_scene(scene))
    measurements, installed = [], []

    def check(actual, expected, atol=1e-6):
        actual, expected = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
        if (not actual.size or actual.shape != expected.shape or not np.isfinite(actual).all()
                or not np.isfinite(expected).all() or not math.isfinite(atol) or not 0 <= atol <= 1):
            raise ValueError("Checks need matching finite measurements and a tolerance in [0,1]")
        measurements.append({"actual": actual.tolist(), "expected": expected.tolist(), "atol": atol})
        if not np.allclose(actual, expected, rtol=0, atol=atol):
            raise ValueError(f"{case['rule']}/{case['kind']} check failed: {measurements[-1]}")

    def install(design):
        tool = Instrument(design)
        world.install(tool)
        installed.extend(tool.body_names)
        return tool.body_names

    namespace = {"__builtins__": BUILTINS, **API, "world": world, "check": check, "install": install}
    exec(compile(case["code"], f"<{scene['id']}.{case['rule']}.{case['kind']}>", "exec"), namespace)
    if not measurements or case["kind"] == "apparatus" and not installed:
        raise ValueError("Checks must measure behavior; apparatus checks must install new bodies")
    if not (np.isfinite(world.data.qpos).all() and np.isfinite(world.data.qvel).all()):
        raise ValueError("Check produced non-finite motion")
    return {"rule": case["rule"], "kind": case["kind"], "installed": installed, "measurements": measurements}


def save_json(filename, scene):
    """5. 保存为当前 JSON 题库格式，不覆盖已有文件。"""
    write_json_atomic(filename, {"format": FORMAT, "scenes": [scene]}, overwrite=False)


def main(operation, input_files, output, *, prompt="", model=None, reference_sessions=()):
    """读取来源，生成并修正到通过检查和审核，再保存场景。"""
    settings = Settings.from_env()
    model = model or settings.model or settings.generator_model
    if Path(output).exists():
        raise FileExistsError(f"Use a new output file: {output}")
    sources = read_json(input_files)
    references = prepare_references(read_sessions(reference_sessions), model=model,
                                    log_path=Path(output).with_suffix(".reference_preprocess.jsonl"), settings=settings)
    if references:
        write_json_atomic(Path(output).with_suffix(".references.json"), references, overwrite=False)
    scene = generate_scene(operation, sources, prompt=prompt, model=model, reference_sessions=references,
                           log_path=Path(output).with_suffix(".attempts.jsonl"), settings=settings)
    save_json(output, scene)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="场景生成：读 JSON → LLM 设计 → 程序检查 → LLM 评审 → 保存 JSON。", allow_abbrev=False)
    parser.add_argument("operation", choices=("generate", "mutate", "compose"))
    parser.add_argument("input_files", type=Path, nargs="*", help="当前格式的 JSON 题库；生成时可作参考")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prompt", default="", help="生成、改进或组合的具体要求")
    parser.add_argument("--reference-session", action="append", dest="reference_sessions", default=[],
                        type=Path, help="参考 session.json 或单局目录；可重复，不传则不引用")
    parser.add_argument("--model", help="模型名称；默认使用 engine.py 的配置")
    args = parser.parse_args()
    try:
        main(**vars(args))
    except KeyboardInterrupt:
        sys.exit(130)
    except (ValueError, KeyError, TypeError, SyntaxError, ArithmeticError, OSError, RuntimeError) as error:
        parser.exit(1, f"{error}\n")
    print(f"Saved {args.output}")
