"""BUILD 自定义 MJCF → 编译与 AI 审核 → 安装、操作和读数；记录建造用量。"""

import copy
import json
import math
import re
from functools import partial
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

from engine import PermanentAPIError, call_api, decode_json, reply_json, unwrap_fence, write_log, Settings
from prompts import BUILD_REVIEW_PROMPT, BUILD_REVIEW_REPAIR_PROMPT, WORKSHOP_HELP as HELP

__all__ = ["HELP", "Instrument", "Workshop"]

# 器材不设数量、部件数或材料质量额度；保留实际操作的物理限制。
FORCE_LIMIT, MOVE_SPEED, GRIP_K = 100.0, 2.0, 400.0
REACH_HEIGHT, GRIP_RADIUS, ACTION_TIMEOUT = 3.0, 0.8, 12.0
TORQUE_LIMIT, ANGULAR_SPEED, SLIDE_SPEED = 20.0, math.radians(30), 0.5
# 自定义模型：通用参数检查、MJCF 编译和读数。
def number(value, lo=-math.inf, hi=math.inf):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError("expected a finite number")
    value = float(value)
    if not math.isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"number outside [{lo}, {hi}]")
    return value


def vector(value, lo=-math.inf, hi=math.inf, length=3):
    if not isinstance(value, (list, tuple)) or len(value) != length:
        raise ValueError(f"expected {length} numbers")
    return [number(x, lo, hi) for x in value]


def ident(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,39}", value):
        raise ValueError("IDs must use lowercase letters, digits and underscores")
    return value


def fields(value, allowed):
    if not isinstance(value, dict) or set(value) - set(allowed.split()):
        raise ValueError(f"allowed fields: {allowed}")


def text(value, limit):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"expected nonempty text of at most {limit} characters")
    return value.strip()


def values(seq):
    return " ".join(f"{x:.12g}" for x in seq)


def _extent(model, data, geom):
    """几何体在世界坐标各轴上的实际半宽，包含旋转和胶囊端帽。"""
    rotation, size = data.geom_xmat[geom].reshape(3, 3), model.geom_size[geom]
    kind = model.geom_type[geom]
    if kind == mujoco.mjtGeom.mjGEOM_BOX:
        return np.abs(rotation) @ size
    if kind == mujoco.mjtGeom.mjGEOM_CAPSULE:
        return size[0] + size[1] * np.abs(rotation[:, 2])
    if kind == mujoco.mjtGeom.mjGEOM_CYLINDER:
        return size[0] * np.sqrt(rotation[:, 0] ** 2 + rotation[:, 1] ** 2) + size[1] * np.abs(rotation[:, 2])
    if kind == mujoco.mjtGeom.mjGEOM_ELLIPSOID:
        return np.sqrt(rotation ** 2 @ size ** 2)
    return np.full(3, size[0])


class Instrument:
    """一份自包含 MJCF；site 是连接点，hinge/slide 提供操作与读数。"""

    def __init__(self, request):
        fields(request, "id name purpose mjcf")
        self.request = copy.deepcopy(request)
        self.design = copy.deepcopy(request)
        self.id = self.design["id"] = ident(request.get("id"))
        self.design["name"] = text(request.get("name", self.id), 80)
        self.design["purpose"] = text(request.get("purpose"), 200)
        try:
            root = ET.fromstring(text(request.get("mjcf"), 32768))
        except ET.ParseError as error:
            raise ValueError(f"invalid MJCF: {error}") from None
        sections = [node.tag for node in root]
        if (root.tag != "mujoco" or set(sections) - {"compiler", "worldbody", "tendon"}
                or len(sections) != len(set(sections))):
            raise ValueError("MJCF supports one worldbody, optional compiler(angle) and tendon")
        allowed = {"mujoco", "compiler", "worldbody", "body", "inertial", "geom",
                   "joint", "freejoint", "site", "tendon", "spatial", "fixed", "pulley"}
        for node in root.iter():
            if node.tag not in allowed:
                raise ValueError(f"unsupported MJCF element: {node.tag}")
            if node.tag == "compiler" and set(node.attrib) - {"angle"}:
                raise ValueError("compiler supports angle only")
            if node.tag == "body" and {"mocap", "gravcomp"} & node.attrib.keys():
                raise ValueError("mocap and gravcomp are not apparatus components")
            if node.tag == "geom" and node.get("type", "sphere") not in {
                    "sphere", "box", "capsule", "cylinder", "ellipsoid"}:
                raise ValueError("geom supports sphere, box, capsule, cylinder and ellipsoid")
        wb = root.find("worldbody")
        if wb is None or not len(wb) or any(node.tag != "body" for node in wb):
            raise ValueError("worldbody must contain apparatus bodies")
        root.set("model", self.id)

        # 名称及绳索引用都限定在本器材内；未命名的实体自动编号。
        names = {kind: {} for kind in ("body", "geom", "joint", "site")}
        for node in wb.iter():
            kind = "joint" if node.tag == "freejoint" else node.tag
            if kind not in names:
                continue
            local = ident(node.get("name", f"{kind}_{len(names[kind])}"))
            if local in names[kind]:
                raise ValueError(f"duplicate {kind} name: {local}")
            names[kind][local] = self.prefix(local)
            node.set("name", names[kind][local])
        tendon = root.find("tendon")
        if tendon is not None:
            for index, node in enumerate(tendon):
                node.set("name", self.prefix(ident(node.get("name", f"tendon_{index}"))))
                for entry in node.iter():
                    for attribute, kind in (("site", "site"), ("sidesite", "site"),
                                            ("geom", "geom"), ("joint", "joint")):
                        if attribute in entry.attrib:
                            local = entry.get(attribute)
                            if local not in names[kind]:
                                raise ValueError(f"unknown local {kind}: {local}")
                            entry.set(attribute, names[kind][local])

        self.spec = mujoco.MjSpec.from_string(ET.tostring(root, encoding="unicode"))
        model = self.spec.compile()
        data = mujoco.MjData(model)
        mujoco.mj_forward(model, data)
        if not all(np.isfinite(array).all() for array in (
                model.body_mass, model.body_inertia, model.geom_size,
                data.qpos, data.qacc, data.geom_xpos, data.site_xpos)):
            raise ValueError("MJCF produced non-finite physical values")
        self.count = model.ngeom + model.njnt + model.ntendon
        if not model.ngeom:
            raise ValueError("a tool needs geometry")
        self.material_mass = float(model.body_mass.sum())
        if not math.isfinite(self.material_mass) or self.material_mass <= 0:
            raise ValueError("tool material mass must be finite and positive")
        if any(not model.tendon_limited[i] for i in range(model.ntendon)):
            raise ValueError("tendons need explicit finite limits")
        self.body_names = list(names["body"].values())
        self.weight_names = set()  # 保留 World 的角色接口；新器材没有预设标准砝码。
        self.ports = names["site"]
        kinds = {int(mujoco.mjtJoint.mjJNT_HINGE): "hinge", int(mujoco.mjtJoint.mjJNT_SLIDE): "slide"}
        self.joints = [(model.joint(i).name, kinds[model.jnt_type[i]])
                       for i in range(model.njnt) if model.jnt_type[i] in kinds]

        # 规范化角度和变换，并显式保留接触参数，避免装入后继承房间的不同默认值。
        normalized = ET.fromstring(self.spec.to_xml())
        for geom in normalized.find("worldbody").iter("geom"):
            g = model.geom(geom.get("name")).id
            geom.set("condim", str(int(model.geom_condim[g])))
            geom.set("friction", values(model.geom_friction[g]))
        self.xml = self.design["mjcf"] = ET.tostring(normalized, encoding="unicode")

    def prefix(self, name):
        return f"tool_{self.id}_{name}"

    def joint_options(self, model):
        return {name: {"kind": kind, "unit": "degrees" if kind == "hinge" else "bricks",
                       "range": [round(float(v), 3) for v in
                                 (np.degrees(model.jnt_range[model.joint(name).id]) if kind == "hinge"
                                  else model.jnt_range[model.joint(name).id])]
                                 if model.jnt_limited[model.joint(name).id] else None}
                for name, kind in self.joints}

    def readout(self, model, data):
        joints = {}
        for name, kind in self.joints:
            q = int(model.joint(name).qposadr[0])
            value = float(data.qpos[q])
            joints[name] = {"angle_degrees": round(math.degrees(value) / 2) * 2} if kind == "hinge" else {"travel": round(value, 1)}
        ports = {name: [round(float(v), 1) for v in data.site_xpos[model.site(site).id]]
                 for name, site in self.ports.items()}
        return {"joints": joints, "ports": ports}


def review_world(world):
    """仅供安装审核的当前几何；不提供隐藏质量、力场或时间标定。"""
    model, data = world.model, world.data
    return {
        "revision": world.revision,
        "apparatus": list(world.workshop.instruments),
        "bodies": [{"name": model.body(bid).name, "position": data.xpos[bid].tolist(),
                    "joint_types": [mujoco.mjtJoint(int(model.jnt_type[j])).name
                                    for j in range(model.body_jntadr[bid],
                                                   model.body_jntadr[bid] + model.body_jntnum[bid])]}
                   for bid in range(1, model.nbody)],
        "geoms": [{"name": model.geom(gid).name, "body": model.body(model.geom_bodyid[gid]).name,
                   "type": mujoco.mjtGeom(int(model.geom_type[gid])).name,
                   "position": data.geom_xpos[gid].tolist(), "size": model.geom_size[gid].tolist(),
                   "rotation": data.geom_xmat[gid].reshape(3, 3).tolist(),
                   "contype": int(model.geom_contype[gid]), "conaffinity": int(model.geom_conaffinity[gid])}
                  for gid in range(model.ngeom)],
    }


def review_design(tool, world, *, settings=None):
    """审核格式有限次补正；保存原文，公开反馈仅来自有效审核。"""
    recorder = world.recorder
    settings = settings or Settings.from_env()
    model = settings.review_model
    if not model:
        raise RuntimeError("BUILD review requires JUDGE_MODEL or BUILD_REVIEW_MODEL")
    if type(settings.judge_attempts) is not int or settings.judge_attempts < 1:
        raise ValueError("judge_attempts must be a positive integer")
    current_world = review_world(world)
    log = partial(write_log, directory=recorder.directory if recorder else None, label=f"BUILD/{tool.id}")
    messages = [{"role": "system", "content": BUILD_REVIEW_PROMPT},
                {"role": "user", "content": json.dumps({
                    "design": tool.request, "compiled_mjcf": tool.xml,
                    "current_world": current_world,
                    "room_bounds": [[-6, 6], [-6, 6], [0, 12]],
                }, ensure_ascii=False, allow_nan=False)}]
    log("开始物理审核")
    original, decision = messages, None
    for number in range(1, settings.judge_attempts + 1):
        event = {"turn": recorder.turn if recorder else None, "id": tool.id,
                 "attempt": world.workshop.build_attempts, "response_attempt": number, "model": model,
                 "current_world": current_world, "raw_response": None, "status": "requested"}
        if recorder is not None:
            recorder.session.setdefault("build_reviews", []).append(event)
        try:
            raw = call_api(messages, model=model, log=log, settings=settings)
            event.update(raw_response=raw, status="received")
            # 保留可明确读出的判定，包括相同 approved 值的重复字段；正式解析仍拒绝重复字段。
            try:
                pairs = json.loads(unwrap_fence(raw), object_pairs_hook=tuple)
            except ValueError:
                pairs = ()
            values = [v for k, v in pairs if k == "approved"] if isinstance(pairs, tuple) else []
            if decision is None and values and all(type(v) is bool and v == values[0] for v in values):
                decision = values[0]
            review = reply_json(raw)
            if (not isinstance(review, dict) or not {"approved", "reason", "feedback"} <= review.keys()
                    or type(review["approved"]) is not bool
                    or not isinstance(review["reason"], str) or not review["reason"].strip()
                    or not isinstance(review["feedback"], str)
                    or not review["approved"] and not review["feedback"].strip()):
                raise ValueError("BUILD review requires approved, reason and feedback; rejection feedback cannot be empty")
            if decision is not None and review["approved"] != decision:
                raise ValueError(f"Preserve the original approved={str(decision).lower()} decision")
            # 附加注释不改变判定，也不能进入公开反馈。
            review = {key: review[key] for key in ("approved", "reason", "feedback")}
            review["model"] = model
            event.update(status="valid", **review)
        except PermanentAPIError as error:
            truncated = error.details.get("finish_reason") == "length"
            event.update(status="incomplete" if truncated else "failed", error=str(error),
                         raw_response=error.raw_response, api_failure=error.details)
            if not truncated or number == settings.judge_attempts:
                raise
            log(f"审核第{number}次输出截断，正在请求精简补正")
            messages = messages + [{"role": "user", "content": BUILD_REVIEW_REPAIR_PROMPT.format(
                error="The response reached the output limit. Keep deliberation brief and return concise, complete JSON.")}]
            continue
        except ValueError as error:
            event.update(status="invalid", error=str(error))
            log(f"审核第{number}次格式校验未通过：{error}")
            if number == settings.judge_attempts:
                raise RuntimeError(f"BUILD review invalid after {number} responses: {error}") from error
            messages = original + [{"role": "assistant", "content": raw},
                {"role": "user", "content": BUILD_REVIEW_REPAIR_PROMPT.format(error=error)}]
            continue
        finally:
            if recorder is not None:
                recorder.checkpoint()
        log(json.dumps(review, ensure_ascii=False))
        return review


# 工坊：记录用量、接收动作并安装器材；World 调用 apply/sample 推进操作和记录。
class Workshop:
    """World 的器材接口：动作、用量、操作力和读数。"""

    name = "workshop"

    def __init__(self, *, review=None):
        self.review = review
        self.instruments = {}
        self.build_attempts = 0
        self.holds = {}
        self.hand = None
        self.adjustment = None
        self.events = []
        self.pending = {}
        self.traces = {}

    def usage(self):
        return {"tools": len(self.instruments), "build_attempts": self.build_attempts,
                "components": sum(t.count for t in self.instruments.values()),
                "material_mass": math.fsum(t.material_mass for t in self.instruments.values())}

    def inventory(self):
        return {**self.usage(),
                "component_unit": "geom + joint (including freejoint) + tendon",
                "handling": {"hand_capacity": 1, "max_grip_height": REACH_HEIGHT,
                             "max_object_radius": GRIP_RADIUS, "marks_limit": 16}}

    def act(self, cmd, world):
        tokens = cmd.split()
        if not tokens:
            return False
        op = tokens[0].upper()
        if op in ("GRASP", "MOVE", "ADJUST"):
            from world import _num
            expected = {"GRASP": 2, "MOVE": 5, "ADJUST": 4}[op]
            if len(tokens) != expected:
                raise ValueError(f"incorrect {op} arguments")
            if op == "GRASP":
                self.grasp(world, tokens[1])
            elif op == "MOVE":
                self.move(world, tokens[1], [_num(v) for v in tokens[2:]])
            else:
                self.adjust(world, tokens[1], tokens[2], _num(tokens[3]))
            return True
        if op == "BUILD":
            self.build(cmd.lstrip()[5:].strip(), world)
        elif op == "PLACE":
            if len(tokens) != 4:
                raise ValueError("PLACE <object> <tool> <port>")
            self.place(world, *tokens[1:])
        elif op == "RELEASE":
            if len(tokens) != 2 or tokens[1] not in self.holds:
                raise ValueError("RELEASE requires a currently held object")
            self._drop_hand(tokens[1])
            from world import SNAP
            self.pending["hand"] = {"released": tokens[1]}
            world._run(SNAP)
        else:
            return False
        return True

    def build(self, request, world):
        self.build_attempts += 1
        if isinstance(request, str):
            if len(request) > 32768:
                raise ValueError("BUILD definition is too large")
            request = decode_json(request)
        tool = Instrument(request)
        if tool.id in self.instruments or tool.id in world.bodies or tool.id in {t.name for t in world.tools}:
            raise ValueError("tool ID already exists")
        review = (self.review or review_design)(tool, world)
        if not review["approved"]:
            raise ValueError(f"BUILD {tool.id} rejected by physics review: {review['feedback'].strip()}")
        world.install(tool)
        self.instruments[tool.id] = tool
        event = {"type": "build", "id": tool.id, "name": tool.design["name"],
                 "purpose": tool.design["purpose"], "design": tool.request, "expanded": tool.design,
                 "turn": world.recorder.turn if world.recorder else 0,
                 "time": float(world.data.time), "validated": True, "material_mass": tool.material_mass,
                 "attempt": self.build_attempts, "review": review,
                 "validation": {"compiled": True, "components": tool.count,
                                "room_bounds": True, "initial_overlap": False}}
        self.events.append(event)
        self.pending[tool.id] = {"built": tool.design["name"], "ports": list(tool.ports)}
        if world.recorder is not None:
            world.recorder.created(tool, event)

    def port(self, world, tool_id, port):
        if tool_id not in self.instruments or port not in self.instruments[tool_id].ports:
            raise ValueError("unknown tool or port")
        sid = world.model.site(self.instruments[tool_id].ports[port]).id
        return sid, int(world.model.site_bodyid[sid])

    def apply(self, world):
        if self.adjustment is not None:
            a = self.adjustment
            q, d = a["q"], a["d"]
            speed = np.clip((a["target"] - world.data.qpos[q]) * 8, -a["speed"], a["speed"])
            force = np.clip(80 * (speed - world.data.qvel[d]) + world.data.qfrc_bias[d], -a["limit"], a["limit"])
            world.data.qfrc_applied[d] += force
            a["force"] = float(force)
        for name, hold in self.holds.items():
            bid = world.model.body(name).id
            d = world.bodies[name][1]
            if "port" in hold:
                sid, support = self.port(world, *hold["port"])
                target = world.data.site_xpos[sid] + np.array([0, 0, hold["radius"]])
            else:
                target, support = hold["target"], 0
            error = target - world.data.xpos[bid]
            velocity = world.data.qvel[d:d + 3]
            mass = float(world.model.body_mass[bid])
            desired = error * 8
            norm = float(np.linalg.norm(desired))
            if norm > MOVE_SPEED:
                desired *= MOVE_SPEED / norm
            force = 2 * math.sqrt(GRIP_K * mass) * (desired - velocity) - mass * world.model.opt.gravity
            norm = float(np.linalg.norm(force))
            if norm > FORCE_LIMIT:
                force *= FORCE_LIMIT / norm
            world.data.xfrc_applied[bid, :3] += force
            if support:
                world.data.xfrc_applied[support, :3] -= force
                world.data.xfrc_applied[support, 3:] += np.cross(
                    target - world.data.xipos[support], -force)

    def _radius(self, world, name):
        if name not in world.bodies:
            raise ValueError("handling requires an existing free object")
        bid = world.model.body(name).id
        root = int(world.model.body_rootid[bid])
        geoms = [g for g in range(world.model.ngeom)
                 if int(world.model.body_rootid[world.model.geom_bodyid[g]]) == root]
        radius = max(np.linalg.norm(world.data.geom_xpos[g] - world.data.xpos[bid])
                     + world.model.geom_rbound[g] for g in geoms)
        if radius > GRIP_RADIUS:
            raise ValueError("object is too large for the grip")
        return float(radius)

    def _target(self, world, point, radius, name=None):
        from world import BOUND, TOP
        point = np.array(vector(list(point)))
        lo, hi = point - radius, point + radius
        if name is not None:
            model, data = world.model, world.data
            bid = model.body(name).id
            root = model.body_rootid[bid]
            lows, highs = [], []
            for g in range(model.ngeom):
                if model.body_rootid[model.geom_bodyid[g]] != root:
                    continue
                extent = _extent(model, data, g)
                centre = point + data.geom_xpos[g] - data.xpos[bid]
                lows.append(centre - extent)
                highs.append(centre + extent)
            lo, hi = np.min(lows, axis=0), np.max(highs, axis=0)
        if (point[2] > REACH_HEIGHT or np.any(lo < [-BOUND - 0.003, -BOUND - 0.003, -0.003])
                or np.any(hi > [BOUND + 0.003, BOUND + 0.003, TOP + 0.003])):
            raise ValueError("grip target outside room or reachable height")
        return point

    def _free_hand(self, name=None):
        if self.hand is not None and self.hand != name:
            raise ValueError("hand occupied; RELEASE the held object first")

    def _drop_hand(self, name):
        self.holds.pop(name, None)
        if self.hand == name:
            self.hand = None

    def _carry(self, world, name, target):
        """夹持目标沿直线移动；到达判断只用平移速度，旋转不使搬运卡死。"""
        radius = self._radius(world, name)
        goal = self._target(world, target, radius, name)
        bid, d = world.model.body(name).id, world.bodies[name][1]
        start = self._target(world, world.data.xpos[bid].copy(), radius, name)
        distance = float(np.linalg.norm(goal - start))
        began = float(world.data.time)
        self.hand = name
        self.holds[name] = {"target": start.copy()}
        try:
            for _ in range(round(ACTION_TIMEOUT / world.model.opt.timestep)):
                fraction = min(1.0, (world.data.time - began + world.model.opt.timestep) * MOVE_SPEED / distance) if distance else 1.0
                self.holds[name]["target"] = start + (goal - start) * fraction
                world.step()
                self._target(world, world.data.xpos[bid], radius, name)
                if (fraction == 1 and np.linalg.norm(world.data.xpos[bid] - goal) < 0.04
                        and np.linalg.norm(world.data.qvel[d:d + 3]) < 0.2):
                    self.holds[name]["target"] = goal
                    return
            raise ValueError("handling blocked or load exceeds grip force; object released")
        except BaseException:
            self._drop_hand(name)
            raise

    def grasp(self, world, name):
        self._free_hand()
        if name in self.holds:
            raise ValueError("RELEASE the mounted object before GRASP")
        radius = self._radius(world, name)
        target = self._target(world, world.data.xpos[world.model.body(name).id], radius, name)
        self._carry(world, name, target)
        self.pending["hand"] = {"grasped": name}

    def move(self, world, name, point):
        if self.hand != name:
            raise ValueError("MOVE requires the currently hand-held object")
        self._carry(world, name, point)
        self.pending["hand"] = {"moved": name, "position": list(world._pos(name)), "holding": True}

    def adjust(self, world, tool_id, joint, target):
        self._free_hand()
        tool = self.instruments.get(tool_id)
        kinds = dict(tool.joints) if tool else {}
        if joint not in kinds:
            raise ValueError("ADJUST requires an advertised movable joint, not a fixed part")
        model, data = world.model, world.data
        jid = model.joint(joint).id
        kind = kinds[joint]
        target = number(target)
        target = math.radians(target) if kind == "hinge" else target
        lo, hi = model.jnt_range[jid]
        if model.jnt_limited[jid] and not lo <= target <= hi:
            raise ValueError("adjustment outside joint range")
        q, d = int(model.jnt_qposadr[jid]), int(model.jnt_dofadr[jid])
        bid = int(model.jnt_bodyid[jid])
        # 通过候选前向运动学检查整个扫掠范围，不改动当前世界。
        probe = copy.copy(data)
        for value in np.linspace(data.qpos[q], target, 33):
            probe.qpos[q] = value
            mujoco.mj_forward(model, probe)
            self._target(world, probe.xanchor[jid], 0)
            for body in range(bid, model.nbody):
                ancestor = body
                while ancestor and ancestor != bid:
                    ancestor = int(model.body_parentid[ancestor])
                if ancestor != bid:
                    continue
                for g in range(int(model.body_geomadr[body]), int(model.body_geomadr[body] + model.body_geomnum[body])):
                    extent = _extent(model, probe, g)
                    p = probe.geom_xpos[g]
                    if np.any(p - extent < [-6, -6, -0.003]) or np.any(p + extent > [6, 6, 12]):
                        raise ValueError("adjustment would put apparatus outside the room")
        speed = ANGULAR_SPEED if kind == "hinge" else SLIDE_SPEED
        tolerance = math.radians(1) if kind == "hinge" else 0.01
        self.adjustment = {"q": q, "d": d, "target": target, "speed": speed,
                           "limit": TORQUE_LIMIT if kind == "hinge" else FORCE_LIMIT, "force": 0.0}
        try:
            for _ in range(round(ACTION_TIMEOUT / model.opt.timestep)):
                world.step()
                self._target(world, data.xanchor[jid], 0)
                if abs(data.qpos[q] - target) <= tolerance and abs(data.qvel[d]) < speed * 0.1:
                    self.pending[tool_id] = {"adjusted": joint, "force_removed": True,
                                             "reading": tool.readout(model, data)}
                    return
            raise ValueError("adjustment blocked or load exceeds force limit; adjusting force removed")
        finally:
            data.qfrc_applied[d] -= self.adjustment["force"]
            self.adjustment = None

    def place(self, world, name, tool_id, port):
        self._free_hand(name)
        radius = self._radius(world, name)
        sid, support = self.port(world, tool_id, port)
        if any(n != name and h.get("port") == (tool_id, port) for n, h in self.holds.items()):
            raise ValueError("port is already holding an object")
        if int(world.model.body_rootid[support]) == int(world.model.body_rootid[world.model.body(name).id]):
            raise ValueError("an object cannot be mounted on itself")
        bid = world.model.body(name).id
        start = world.data.xpos[bid].copy()
        target = world.data.site_xpos[sid].copy() + [0, 0, radius + 0.03]
        height = max(start[2], target[2]) + 0.8
        if height + radius > 12:
            raise ValueError("not enough overhead clearance")
        points = [np.array([*start[:2], height]), np.array([*target[:2], height]), target]
        for point in points:
            self._target(world, point, radius, name)
        self.holds.pop(name, None)
        try:
            for point in points:
                self._carry(world, name, point)
            self.holds[name] = {"port": (tool_id, port), "radius": radius + 0.03}
            self.hand = None
            for _ in range(round(2 / world.model.opt.timestep)):
                world.step()
            target = world.data.site_xpos[sid] + [0, 0, radius + 0.03]
            if np.linalg.norm(world.data.xpos[bid] - target) > 0.15:
                raise ValueError("PLACE could not retain the load at the port; object released")
            self.pending[tool_id] = {"placed": name, "port": port, "grip": "holding; RELEASE to let go"}
        except BaseException:
            self._drop_hand(name)
            raise

    def sample(self, world):
        for name, tool in self.instruments.items():
            trace = self.traces.setdefault(name, [])
            trace.append(tool.readout(world.model, world.data))
            del trace[:-20]

    def readout(self):
        result, self.pending = self.pending, {}
        return result
