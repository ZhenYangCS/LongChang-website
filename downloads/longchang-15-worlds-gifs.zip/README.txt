LongChang — Fifteen physical-law illustrations

These are idealized illustrations of the laws described in the paper, not
recorded MuJoCo experiments or evidence of model discovery. Each GIF uses
the scene's default interactive setting and lasts eight seconds.

The site offers alternate experiment settings, full law descriptions,
recorded initial worlds, and separate verified model-exploration videos.
Ordinary physics is simplified or omitted as stated in each figure.
Playback time is not simulation time; timing rules are labelled in counts.

Source: project_page/assets/atlas.js and data/paper.js.
Regenerate: python scripts/export_motion.py
