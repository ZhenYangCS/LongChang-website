LongChang: the fifteen oracles, made visible.

Fresh scripted experiments with native scene physics. Glass materials and
studio lighting reuse the paper's Figure 1 rendering code. Each animation
shows one hidden rule, with a short caption and its trigger in motion.
Names follow the ACL scene-overview table exactly.

Ordinary references use identical geometry, masses and prescribed actions,
with only the altered physical program disabled. These demonstrations do
not contribute to the paper's model-discovery scores. The glass enclosures
and cropped plinths are presentation geometry, not added physical walls.

Playback uses steady retiming of dense native states, without artificial
holds. Color exchange and third-contact jumps use continuous runs without
repositioning. Separate trials in other scenes have explicit transitions.
The six redesigned causal demonstrations use simulation clocks; other
video clocks show playback time. Measurements retain simulation time. Full records,
editable signal figures and source hashes are available on the project page.
