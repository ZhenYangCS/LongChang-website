LongChang: the fifteen oracles, made visible.

Fresh scripted experiments with native scene physics. Glass materials and
studio lighting reuse the paper's Figure 1 rendering code. Each animation
shows one hidden rule, with a short caption and its trigger in motion.
Names follow the ACL scene-overview table exactly.

Ordinary references use identical geometry, masses and prescribed actions,
with only the altered physical program disabled. These demonstrations do
not contribute to the paper's model-discovery scores. The glass enclosures
and cropped plinths are presentation geometry, not added physical walls.

Playback slows down or holds exact sampled states around key events.
The displayed clock remains the original simulation time. Full records,
editable signal figures and source hashes are available on the project page.
