LongChang: scripted demonstrations of the original scene physics.

All 15 names match the current ACL scene-overview table. These prepared,
scripted demonstrations are not LLM explorations and do not contribute to
the paper's 540 evaluated runs. Original scene programs, object geometry,
mass, friction, gravity and contact laws are preserved. Setup positions and
interventions are explicit in each JSON record. Each video presents one
hidden rule in a short caption. Video playback is steadily retimed; the player
clock shows playback time, while measurements retain simulation time.

JSON files contain 500 Hz samples, interventions, rule events and source
hashes. Videos use nearest recorded simulation samples without pose
interpolation. Camera, lighting and trajectory overlays are presentation.

Close-ups use a crop of the same fixed room, cached Cycles spherical lighting
and projected soft shadows. Display contrast is enhanced; native RGBA values
remain in the records. No physical objects are enlarged for presentation.

Render using project_page/scripts/build_smooth_demos.py, followed by
project_page/scripts/build_detail_views.py and
project_page/scripts/publish_clear_media.py. The project-page README
documents the rendering workflow.
